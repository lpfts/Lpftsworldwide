import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { WagmiProvider } from 'wagmi';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { wagmiConfig } from '@/lib/wagmi';
import Index from "./pages/Index";
import Missions from "./pages/Missions";
import Gallery from "./pages/Gallery";
import Faucet from "./pages/Faucet";
import Leaderboard from "./pages/Leaderboard";
import Market from "./pages/Market";
import Merch from "./pages/Merch";
import Storyline from "./pages/Storyline";
import Privacy from "./pages/Privacy";
import Terms from "./pages/Terms";
import QREntry from "./pages/QREntry";
import Auth from "./pages/Auth";
import PaymentSuccess from "./pages/PaymentSuccess";
import VipSuccess from "./pages/VipSuccess";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <WagmiProvider config={wagmiConfig}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Index />} />
            <Route path="/missions" element={<Missions />} />
            <Route path="/gallery" element={<Gallery />} />
            <Route path="/faucet" element={<Faucet />} />
            <Route path="/leaderboard" element={<Leaderboard />} />
            <Route path="/market" element={<Market />} />
            <Route path="/merch" element={<Merch />} />
            <Route path="/storyline" element={<Storyline />} />
            <Route path="/privacy" element={<Privacy />} />
            <Route path="/terms" element={<Terms />} />
            <Route path="/qr" element={<QREntry />} />
            <Route path="/auth" element={<Auth />} />
            <Route path="/payment-success" element={<PaymentSuccess />} />
            <Route path="/vip-success" element={<VipSuccess />} />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </WagmiProvider>
  </QueryClientProvider>
);

export default App;
