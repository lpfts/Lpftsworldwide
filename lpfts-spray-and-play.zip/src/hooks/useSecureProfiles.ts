import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

// Hook for securely fetching public profile data
export const usePublicProfile = (profileId: string | null) => {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!profileId) return;

    setLoading(true);
    setError(null);

    const fetchPublicProfile = async () => {
      try {
        // Use the secure function to get only public profile data
        const { data, error } = await supabase
          .rpc('get_public_profile', { profile_id: profileId });

        if (error) throw error;

        setProfile(data?.[0] || null);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPublicProfile();
  }, [profileId]);

  return { profile, loading, error };
};

// Hook for fetching multiple public profiles
export const usePublicProfiles = (profileIds: string[]) => {
  const [profiles, setProfiles] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (profileIds.length === 0) return;

    setLoading(true);
    setError(null);

    const fetchPublicProfiles = async () => {
      try {
        // Fetch only public profile data for multiple users
        const { data, error } = await supabase
          .from('profiles')
          .select('id, handle, display_name, avatar_url, missions_completed, tokens_collected, created_at')
          .in('id', profileIds);

        if (error) throw error;

        setProfiles(data || []);
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchPublicProfiles();
  }, [profileIds.join(',')]);

  return { profiles, loading, error };
};

// Utility to get safe profile display data
export const getSafeProfileData = (profile: any) => {
  if (!profile) return null;

  return {
    id: profile.id,
    handle: profile.handle,
    displayName: profile.display_name,
    avatarUrl: profile.avatar_url,
    missionsCompleted: profile.missions_completed || 0,
    tokensCollected: profile.tokens_collected || 0,
    createdAt: profile.created_at,
    // Never expose wallet_address, bio, or auth_user_id in public contexts
  };
};

// Hook for checking if current user can view sensitive profile data
export const useCanViewSensitiveData = (profileId: string, currentUserId: string | null) => {
  return profileId === currentUserId;
};