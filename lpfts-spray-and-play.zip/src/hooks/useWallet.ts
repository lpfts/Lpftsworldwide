import { useState, useEffect } from 'react';
import { useAccount, useConnect, useDisconnect, useBalance } from 'wagmi';
import { metaMask } from 'wagmi/connectors';
import { polygon, sepolia } from 'wagmi/chains';
import { getNetworkAddresses, config } from '@/lib/config';
import { useToast } from '@/hooks/use-toast';

export const useWallet = () => {
  const [isConnecting, setIsConnecting] = useState(false);
  const { address, isConnected, chain } = useAccount();
  const { connect } = useConnect();
  const { disconnect } = useDisconnect();
  const { toast } = useToast();

  const targetChain = config.network === 'sepolia' ? sepolia : polygon;
  const addresses = getNetworkAddresses();

  // Get token balances (mock mode for now since contracts might not be deployed)
  const sprayBalance = useBalance({
    address,
    token: addresses.sprayToken as `0x${string}`,
    query: {
      enabled: isConnected && addresses.sprayToken !== '0x0000000000000000000000000000000000000000',
    }
  });

  const paintBalance = useBalance({
    address,
    token: addresses.paintToken as `0x${string}`,
    query: {
      enabled: isConnected && addresses.paintToken !== '0x0000000000000000000000000000000000000000',
    }
  });

  const lpftsBalance = useBalance({
    address,
    token: addresses.lpftsToken as `0x${string}`,
    query: {
      enabled: isConnected && addresses.lpftsToken !== '0x0000000000000000000000000000000000000000',
    }
  });

  const tagBalance = useBalance({
    address,
    token: addresses.tagToken as `0x${string}`,
    query: {
      enabled: isConnected && addresses.tagToken !== '0x0000000000000000000000000000000000000000',
    }
  });

  const connectWallet = async () => {
    try {
      setIsConnecting(true);
      await connect({ 
        connector: metaMask(),
        chainId: targetChain.id,
      });
      
      toast({
        title: "Wallet Connected",
        description: `Successfully connected to ${targetChain.name}`,
      });
    } catch (error: any) {
      toast({
        title: "Connection Failed",
        description: error.message || "Failed to connect wallet",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    disconnect();
    toast({
      title: "Wallet Disconnected",
      description: "Successfully disconnected from wallet",
    });
  };

  // Mock balances when in mock mode or no real contracts
  const getMockBalance = (tokenType: string) => {
    if (!config.mockMode) return null;
    
    const mockBalances = {
      SPRAY: 1250,
      PAINT: 85,
      LPFTS: 12,
      TAG: 340,
    };
    
    return mockBalances[tokenType as keyof typeof mockBalances] || 0;
  };

  const getTokenBalance = (tokenType: 'SPRAY' | 'PAINT' | 'LPFTS' | 'TAG') => {
    if (config.mockMode || !isConnected) {
      return getMockBalance(tokenType);
    }

    switch (tokenType) {
      case 'SPRAY':
        return sprayBalance.data ? Number(sprayBalance.data.formatted) : 0;
      case 'PAINT':
        return paintBalance.data ? Number(paintBalance.data.formatted) : 0;
      case 'LPFTS':
        return lpftsBalance.data ? Number(lpftsBalance.data.formatted) : 0;
      case 'TAG':
        return tagBalance.data ? Number(tagBalance.data.formatted) : 0;
      default:
        return 0;
    }
  };

  const isCorrectNetwork = () => {
    return !isConnected || chain?.id === targetChain.id;
  };

  const switchNetwork = async () => {
    try {
      await window.ethereum?.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: `0x${targetChain.id.toString(16)}` }],
      });
    } catch (error: any) {
      toast({
        title: "Network Switch Failed",
        description: `Please manually switch to ${targetChain.name}`,
        variant: "destructive",
      });
    }
  };

  return {
    address,
    isConnected,
    isConnecting,
    chain,
    targetChain,
    connectWallet,
    disconnectWallet,
    getTokenBalance,
    isCorrectNetwork,
    switchNetwork,
    balances: {
      spray: getTokenBalance('SPRAY'),
      paint: getTokenBalance('PAINT'),
      lpfts: getTokenBalance('LPFTS'),
      tag: getTokenBalance('TAG'),
    }
  };
};