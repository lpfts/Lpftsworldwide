import { useState } from 'react';
import { useAuth } from './useAuth';
import { useToast } from '@/hooks/use-toast';
import { config } from '@/lib/config';

export const useFaucet = () => {
  const [isClaimingFaucet, setIsClaimingFaucet] = useState(false);
  const [lastClaimTime, setLastClaimTime] = useState<Date | null>(null);
  const [totalClaims, setTotalClaims] = useState(0);
  const { profile } = useAuth();
  const { toast } = useToast();

  const checkCanClaim = async (tokenType = 'SPRAY') => {
    if (!profile) return false;

    // In mock mode, simulate 24-hour cooldown
    if (config.mockMode) {
      if (!lastClaimTime) return true; // First claim always allowed
      
      const now = new Date();
      const timeSinceLastClaim = now.getTime() - lastClaimTime.getTime();
      const hoursSinceLastClaim = timeSinceLastClaim / (1000 * 60 * 60);
      
      return hoursSinceLastClaim >= 24;
    }

    // In production, this would check the database
    return true;
  };

  const claimFaucet = async (tokenType = 'SPRAY') => {
    if (!profile) {
      toast({
        title: "Authentication Required",
        description: "Please sign in to claim faucet tokens",
        variant: "destructive",
      });
      return false;
    }

    setIsClaimingFaucet(true);

    try {
      // Check if user can claim
      const canClaim = await checkCanClaim(tokenType);
      if (!canClaim) {
        toast({
          title: "Claim Not Available",
          description: "You can only claim faucet tokens once per day",
          variant: "destructive",
        });
        return false;
      }

      // Determine claim amount (100 for first time, 25 for subsequent)
      const isFirstClaim = totalClaims === 0;
      const claimAmount = isFirstClaim ? 100 : 25;

      // In mock mode, just simulate the claim
      if (config.mockMode) {
        setLastClaimTime(new Date());
        setTotalClaims(prev => prev + 1);

        toast({
          title: "Faucet Claimed! 🎉",
          description: `Successfully claimed ${claimAmount} ${tokenType} tokens (Mock Mode)`,
        });

        return true;
      }

      // In live mode, would make actual blockchain transaction here
      toast({
        title: "Faucet Feature Coming Soon",
        description: "Blockchain faucet integration will be available soon!",
      });

      return false;
    } catch (error: any) {
      console.error('Faucet claim error:', error);
      toast({
        title: "Claim Failed",
        description: error.message || "Failed to claim faucet tokens",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsClaimingFaucet(false);
    }
  };

  const getTimeUntilNextClaim = () => {
    if (!lastClaimTime) return 0;
    
    const now = new Date();
    const nextClaimTime = new Date(lastClaimTime.getTime() + 24 * 60 * 60 * 1000); // 24 hours later
    
    return Math.max(0, nextClaimTime.getTime() - now.getTime());
  };

  const canClaimNow = async () => {
    return await checkCanClaim('SPRAY');
  };

  return {
    claimFaucet,
    checkCanClaim,
    canClaimNow,
    getTimeUntilNextClaim,
    isClaimingFaucet,
    lastClaimTime,
    totalClaims,
  };
};