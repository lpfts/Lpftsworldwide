import { useState, useEffect } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface AuthState {
  user: User | null;
  session: Session | null;
  loading: boolean;
  profile: any | null;
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    user: null,
    session: null,
    loading: true,
    profile: null,
  });
  const { toast } = useToast();

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setAuthState(prev => ({
          ...prev,
          session,
          user: session?.user ?? null,
        }));

        // Fetch profile if user is authenticated
        if (session?.user) {
          setTimeout(async () => {
            try {
              // Only fetch the user's own complete profile data
              const { data: profile, error } = await supabase
                .from('profiles')
                .select('id, handle, display_name, avatar_url, missions_completed, tokens_collected, wallet_address, bio, created_at, auth_user_id')
                .eq('auth_user_id', session.user.id)
                .maybeSingle();

              if (error && error.code !== 'PGRST116') {
                console.error('Error fetching profile:', error);
              }
              
              setAuthState(prev => ({
                ...prev,
                profile,
                loading: false,
              }));
            } catch (error) {
              console.error('Profile fetch error:', error);
              setAuthState(prev => ({ ...prev, loading: false }));
            }
          }, 0);
        } else {
          setAuthState(prev => ({
            ...prev,
            profile: null,
            loading: false,
          }));
        }
      }
    );

    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setAuthState(prev => ({
        ...prev,
        session,
        user: session?.user ?? null,
      }));
    });

    return () => subscription.unsubscribe();
  }, []);

  const signUp = async (email: string, password: string, username?: string) => {
    try {
      const redirectUrl = `${window.location.origin}/`;
      
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: username ? { username } : undefined,
        }
      });

      if (error) throw error;

      toast({
        title: "Sign Up Successful",
        description: "Please check your email to verify your account.",
      });

      return { data, error: null };
    } catch (error: any) {
      toast({
        title: "Sign Up Error",
        description: error.message,
        variant: "destructive",
      });
      return { data: null, error };
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      toast({
        title: "Welcome Back!",
        description: "Successfully signed in to LPFTS World Wide.",
      });

      return { data, error: null };
    } catch (error: any) {
      toast({
        title: "Sign In Error",
        description: error.message,
        variant: "destructive",
      });
      return { data: null, error };
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;

      toast({
        title: "Signed Out",
        description: "Successfully signed out of LPFTS World Wide.",
      });
    } catch (error: any) {
      toast({
        title: "Sign Out Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const createProfile = async (username: string, displayName?: string) => {
    if (!authState.user) return { error: 'No authenticated user' };

    try {
      // Validate inputs using our enhanced validation
      const { usernameSchema, displayNameSchema } = await import('@/lib/validation');
      
      const validatedUsername = usernameSchema.parse(username);
      const validatedDisplayName = displayNameSchema.parse(displayName || username);

      const { data, error } = await supabase
        .from('profiles')
        .insert({
          auth_user_id: authState.user.id,
          handle: validatedUsername,
          display_name: validatedDisplayName,
        })
        .select()
        .single();

      if (error) {
        // Handle unique constraint violations
        if (error.code === '23505' && error.message.includes('profiles_handle_unique')) {
          throw new Error('Username is already taken. Please choose a different one.');
        }
        throw error;
      }

      setAuthState(prev => ({ ...prev, profile: data }));
      return { data, error: null };
    } catch (error: any) {
      return { data: null, error };
    }
  };

  return {
    ...authState,
    signUp,
    signIn,
    signOut,
    createProfile,
    isAuthenticated: !!authState.user,
  };
};