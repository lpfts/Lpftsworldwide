// Environment configuration and address helpers for LPFTS World Wide

export const config = {
  // Supabase
  supabase: {
    url: import.meta.env.VITE_SUPABASE_URL || '',
    anonKey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY || '',
    serviceRole: import.meta.env.VITE_SUPABASE_SERVICE_ROLE || '',
  },

  // Discord
  discordInvite: import.meta.env.VITE_DISCORD_INVITE || 'https://discord.gg/RPCzbVsh?event=1415252001989591111',

  // Development
  mockMode: false, // Production ready - no more test mode
  network: import.meta.env.VITE_NETWORK || 'sepolia',

  // Contract Addresses - Mainnet
  mainnet: {
    lpftsToken: import.meta.env.VITE_LPFTS_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    sprayToken: import.meta.env.VITE_SPRAY_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    tagToken: import.meta.env.VITE_TAG_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    paintToken: import.meta.env.VITE_PAINT_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    lpftsNft: import.meta.env.VITE_LPFTS_NFT_ADDRESS || '0x0000000000000000000000000000000000000000',
    faucet: import.meta.env.VITE_FAUCET_ADDRESS || '0x0000000000000000000000000000000000000000',
  },

  // Contract Addresses - Sepolia Testnet
  sepolia: {
    lpftsToken: import.meta.env.VITE_SEPOLIA_LPFTS_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    sprayToken: import.meta.env.VITE_SEPOLIA_SPRAY_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    tagToken: import.meta.env.VITE_SEPOLIA_TAG_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    paintToken: import.meta.env.VITE_SEPOLIA_PAINT_TOKEN_ADDRESS || '0x0000000000000000000000000000000000000000',
    lpftsNft: import.meta.env.VITE_SEPOLIA_LPFTS_NFT_ADDRESS || '0x0000000000000000000000000000000000000000',
    faucet: import.meta.env.VITE_SEPOLIA_FAUCET_ADDRESS || '0x0000000000000000000000000000000000000000',
  },

  // Stripe
  stripe: {
    publishableKey: import.meta.env.VITE_STRIPE_PUBLISHABLE_KEY || '',
    secretKey: import.meta.env.VITE_STRIPE_SECRET_KEY || '',
    webhookSecret: import.meta.env.VITE_STRIPE_WEBHOOK_SECRET || '',
  },
};

// Helper function to check if an address is deployed (not zero address)
export const isDeployed = (address: string): boolean => {
  return address !== '0x0000000000000000000000000000000000000000' && address !== '';
};

// Get current network addresses
export const getNetworkAddresses = () => {
  return config.network === 'sepolia' ? config.sepolia : config.mainnet;
};

// Get current network name for display
export const getNetworkName = (): string => {
  return config.network === 'sepolia' ? 'Sepolia Testnet' : 'Polygon Mainnet';
};

// Check if a feature should be shown (has valid address or is in mock mode)
export const shouldShowFeature = (address: string): boolean => {
  return config.mockMode || isDeployed(address);
};

// Discord invite link
export const DISCORD_INVITE = config.discordInvite;

export default config;