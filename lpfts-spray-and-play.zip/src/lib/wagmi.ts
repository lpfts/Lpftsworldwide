import { createConfig, http } from 'wagmi';
import { polygon, sepolia } from 'wagmi/chains';
import { metaMask } from 'wagmi/connectors';
import { config } from './config';

// Ensure we always have at least one chain
const supportedChains = config.network === 'sepolia' ? [sepolia, polygon] as const : [polygon, sepolia] as const;

export const wagmiConfig = createConfig({
  chains: supportedChains,
  connectors: [
    metaMask({
      dappMetadata: {
        name: 'LPFTS World Wide',
        url: typeof window !== 'undefined' ? window.location.origin : '',
        iconUrl: typeof window !== 'undefined' ? `${window.location.origin}/favicon.ico` : 'https://lovable.dev/favicon.ico',
      },
    }),
  ],
  transports: {
    [polygon.id]: http(),
    [sepolia.id]: http(),
  },
});

declare module 'wagmi' {
  interface Register {
    config: typeof wagmiConfig;
  }
}