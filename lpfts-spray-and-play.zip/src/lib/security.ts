// Security utility functions and constants

// Content Security Policy configuration
export const getCSPHeader = () => {
  const isDev = import.meta.env.DEV;
  
  return [
    "default-src 'self'",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval'", // Relaxed for development
    "style-src 'self' 'unsafe-inline'", // Relaxed for Tailwind CSS
    "img-src 'self' data: https:",
    "font-src 'self' data:",
    "connect-src 'self' https://cwnnpqyzwrcrmtvfynaf.supabase.co wss://cwnnpqyzwrcrmtvfynaf.supabase.co",
    "media-src 'self'",
    "object-src 'none'",
    "frame-src 'none'",
    "worker-src 'self'",
    "frame-ancestors 'none'",
    "form-action 'self'",
    "base-uri 'self'",
    isDev ? "upgrade-insecure-requests" : ""
  ].filter(Boolean).join("; ");
};

// Security headers for edge functions
export const securityHeaders = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'X-XSS-Protection': '1; mode=block',
  'Referrer-Policy': 'strict-origin-when-cross-origin',
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
  'Content-Security-Policy': getCSPHeader()
};

// Rate limiting constants
export const RATE_LIMITS = {
  AUTH: {
    SIGNIN: { attempts: 5, windowMs: 300000 }, // 5 attempts per 5 minutes
    SIGNUP: { attempts: 3, windowMs: 3600000 }, // 3 attempts per hour
  },
  POSTS: {
    CREATE: { attempts: 3, windowMs: 300000 }, // 3 posts per 5 minutes
  },
  MISSIONS: {
    SUBMIT: { attempts: 10, windowMs: 3600000 }, // 10 missions per hour
  }
};

// Sanitization functions
export const sanitizeForDisplay = (text: string): string => {
  return text
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
};

// Log security events (client-side tracking)
export const logSecurityEvent = (event: string, details: any = {}) => {
  if (import.meta.env.DEV) {
    console.warn(`Security Event: ${event}`, details);
  }
  
  // In production, this could send to a monitoring service
  // Example: sendToSecurityMonitoring(event, details);
};

// Check if string contains potential XSS
export const containsPotentialXSS = (input: string): boolean => {
  const xssPatterns = [
    /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
    /<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /<object\b[^<]*(?:(?!<\/object>)<[^<]*)*<\/object>/gi,
    /<embed\b[^<]*(?:(?!<\/embed>)<[^<]*)*<\/embed>/gi,
  ];
  
  return xssPatterns.some(pattern => pattern.test(input));
};

// Enhanced input validation for file uploads
export const validateFileUpload = (file: File): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  const maxSize = 20 * 1024 * 1024; // 20MB
  const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
  
  if (file.size > maxSize) {
    errors.push('File size exceeds 20MB limit');
  }
  
  if (!allowedTypes.includes(file.type)) {
    errors.push('File type not allowed. Please use JPEG, PNG, GIF, or WebP');
  }
  
  // Check for malicious file extensions
  const maliciousExtensions = ['.exe', '.bat', '.cmd', '.scr', '.pif', '.com'];
  const fileName = file.name.toLowerCase();
  
  if (maliciousExtensions.some(ext => fileName.endsWith(ext))) {
    errors.push('File type not allowed for security reasons');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

// Password strength checker
export const checkPasswordStrength = (password: string): {
  score: number;
  feedback: string[];
} => {
  const feedback: string[] = [];
  let score = 0;
  
  if (password.length >= 8) score += 1;
  else feedback.push('Use at least 8 characters');
  
  if (/[a-z]/.test(password)) score += 1;
  else feedback.push('Include lowercase letters');
  
  if (/[A-Z]/.test(password)) score += 1;
  else feedback.push('Include uppercase letters');
  
  if (/\d/.test(password)) score += 1;
  else feedback.push('Include numbers');
  
  if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) score += 1;
  else feedback.push('Include special characters');
  
  if (password.length >= 12) score += 1;
  
  return { score, feedback };
};