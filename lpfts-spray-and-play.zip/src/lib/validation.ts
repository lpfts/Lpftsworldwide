import { z } from 'zod';

// Content moderation utilities
const profanityWords = [
  'fuck', 'shit', 'damn', 'bitch', 'asshole', 'crap', 'hell', 'piss',
  'cock', 'dick', 'pussy', 'tits', 'ass', 'bastard', 'slut', 'whore'
];

const spamPatterns = [
  /(.)\1{4,}/g, // Repeated characters (5+ times)
  /(https?:\/\/[^\s]+)/gi, // URLs
  /(\b\w+\b)(\s+\1){3,}/gi, // Repeated words (4+ times)
  /[A-Z]{10,}/g, // Excessive caps
  /\b(buy|sell|cheap|free|click|visit|www|com|org|net)\b/gi // Common spam words
];

export const validateContent = (content: string): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];
  const normalizedContent = content.toLowerCase().trim();

  // Check for profanity
  const containsProfanity = profanityWords.some(word => 
    normalizedContent.includes(word.toLowerCase())
  );
  
  if (containsProfanity) {
    errors.push('Content contains inappropriate language');
  }

  // Check for spam patterns
  const isSpam = spamPatterns.some(pattern => pattern.test(content));
  if (isSpam) {
    errors.push('Content appears to be spam or low-quality');
  }

  // Check length constraints
  if (content.length > 1000) {
    errors.push('Content exceeds maximum length of 1000 characters');
  }

  if (content.trim().length === 0) {
    errors.push('Content cannot be empty');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};

export const sanitizeInput = (input: string): string => {
  return input
    .trim()
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: URLs
    .replace(/on\w+=/gi, '') // Remove event handlers
    .slice(0, 1000); // Enforce max length
};

// Enhanced username validation
export const usernameSchema = z.string()
  .trim()
  .min(3, { message: "Username must be at least 3 characters" })
  .max(30, { message: "Username cannot exceed 30 characters" })
  .regex(/^[a-zA-Z0-9_-]+$/, { 
    message: "Username can only contain letters, numbers, underscores, and hyphens" 
  })
  .refine(val => !profanityWords.some(word => val.toLowerCase().includes(word)), {
    message: "Username contains inappropriate content"
  });

// Enhanced display name validation  
export const displayNameSchema = z.string()
  .trim()
  .min(1, { message: "Display name is required" })
  .max(50, { message: "Display name cannot exceed 50 characters" })
  .refine(val => !profanityWords.some(word => val.toLowerCase().includes(word)), {
    message: "Display name contains inappropriate content"
  });

// Enhanced email validation
export const emailSchema = z.string()
  .trim()
  .email({ message: "Invalid email address" })
  .max(255, { message: "Email cannot exceed 255 characters" })
  .refine(val => !val.includes('<') && !val.includes('>'), {
    message: "Email contains invalid characters"
  });

// Enhanced password validation
export const passwordSchema = z.string()
  .min(8, { message: "Password must be at least 8 characters" })
  .max(128, { message: "Password cannot exceed 128 characters" })
  .regex(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/, {
    message: "Password must contain at least one lowercase letter, one uppercase letter, and one number"
  });

// Post content validation
export const postContentSchema = z.string()
  .trim()
  .min(1, { message: "Post content cannot be empty" })
  .max(1000, { message: "Post content cannot exceed 1000 characters" })
  .refine(val => {
    const validation = validateContent(val);
    return validation.isValid;
  }, {
    message: "Post content contains inappropriate or spam content"
  });

// Rate limiting helper (client-side tracking)
export class RateLimiter {
  private static instance: RateLimiter;
  private attempts: Map<string, number[]> = new Map();

  static getInstance(): RateLimiter {
    if (!RateLimiter.instance) {
      RateLimiter.instance = new RateLimiter();
    }
    return RateLimiter.instance;
  }

  isAllowed(action: string, maxAttempts: number = 5, windowMs: number = 60000): boolean {
    const now = Date.now();
    const key = `${action}`;
    
    if (!this.attempts.has(key)) {
      this.attempts.set(key, []);
    }

    const actionAttempts = this.attempts.get(key)!;
    
    // Remove old attempts outside the time window
    const validAttempts = actionAttempts.filter(timestamp => now - timestamp < windowMs);
    this.attempts.set(key, validAttempts);

    if (validAttempts.length >= maxAttempts) {
      return false;
    }

    // Add current attempt
    validAttempts.push(now);
    this.attempts.set(key, validAttempts);
    
    return true;
  }

  getRemainingTime(action: string, windowMs: number = 60000): number {
    const now = Date.now();
    const key = `${action}`;
    const actionAttempts = this.attempts.get(key) || [];
    
    if (actionAttempts.length === 0) return 0;
    
    const oldestAttempt = Math.min(...actionAttempts);
    const timeLeft = (oldestAttempt + windowMs) - now;
    
    return Math.max(0, timeLeft);
  }
}