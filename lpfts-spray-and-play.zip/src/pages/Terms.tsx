import React from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Terms = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold neon-text mb-8 text-center">Terms & Conditions</h1>
          
          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text">Platform Usage</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>By using LPFTS (Legal Paint For The Streets), you agree to:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Only create artwork on designated legal walls</li>
                <li>Respect local laws and regulations regarding street art</li>
                <li>Submit original artwork and respect intellectual property rights</li>
                <li>Maintain the integrity of the graffiti community</li>
                <li>Use the platform responsibly and ethically</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text">Legal Wall Compliance</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>All missions must be completed on approved legal walls:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Verify wall legality before beginning any artwork</li>
                <li>Follow local council guidelines and permissions</li>
                <li>Respect property owners and community spaces</li>
                <li>Report any issues or concerns with wall listings</li>
                <li>Understand that illegal graffiti violates platform terms</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text">SPRAY Tokens & NFTs</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Token rewards and NFT minting are subject to:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Successful mission completion and verification</li>
                <li>Artwork quality and adherence to mission requirements</li>
                <li>Community voting and peer review processes</li>
                <li>Platform discretion for exceptional circumstances</li>
                <li>Blockchain network fees and transaction costs</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text">Community Standards</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>We maintain high standards for our community:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>No offensive, discriminatory, or harmful content</li>
                <li>Respect for other artists and community members</li>
                <li>Constructive feedback and positive engagement</li>
                <li>Protection of minors and vulnerable individuals</li>
                <li>Zero tolerance for illegal activities</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container">
            <CardHeader>
              <CardTitle className="turquoise-text">Liability & Disclaimers</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Users acknowledge and agree that:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Street art carries inherent risks and legal considerations</li>
                <li>LPFTS is not liable for personal injury or legal issues</li>
                <li>Token values may fluctuate based on market conditions</li>
                <li>Platform availability may be subject to maintenance</li>
                <li>Terms may be updated to reflect legal and operational changes</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Terms;