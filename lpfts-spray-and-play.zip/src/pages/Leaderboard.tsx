import React, { useState } from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Trophy, Medal, Award, TrendingUp } from 'lucide-react';

const Leaderboard = () => {
  const [activeTab, setActiveTab] = useState('all-time');

  const allTimeLeaders = [
    {
      rank: 1,
      username: 'NeonMaster',
      score: 15420,
      missions: 89,
      tokens: 12500,
      badge: 'Legend'
    },
    {
      rank: 2,
      username: 'GraffitiKing',
      score: 14280,
      missions: 76,
      tokens: 11200,
      badge: 'Master'
    },
    {
      rank: 3,
      username: 'StreetArtist',
      score: 13150,
      missions: 82,
      tokens: 10800,
      badge: 'Master'
    },
    {
      rank: 4,
      username: 'CyberVandal',
      score: 11950,
      missions: 68,
      tokens: 9800,
      badge: 'Expert'
    },
    {
      rank: 5,
      username: 'UrbanPainter',
      score: 10750,
      missions: 71,
      tokens: 8900,
      badge: 'Expert'
    }
  ];

  const weeklyLeaders = [
    {
      rank: 1,
      username: 'RisingArtist',
      score: 2420,
      missions: 12,
      tokens: 1500,
      badge: 'Hot Streak'
    },
    {
      rank: 2,
      username: 'NeonMaster',
      score: 2180,
      missions: 9,
      tokens: 1200,
      badge: 'Legend'
    },
    {
      rank: 3,
      username: 'NewWriter',
      score: 1950,
      missions: 15,
      tokens: 1100,
      badge: 'Rising Star'
    },
    {
      rank: 4,
      username: 'QuickSpray',
      score: 1750,
      missions: 8,
      tokens: 900,
      badge: 'Speed Run'
    },
    {
      rank: 5,
      username: 'StreetArtist',
      score: 1650,
      missions: 11,
      tokens: 850,
      badge: 'Master'
    }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-neon-orange" />;
      case 2:
        return <Medal className="w-6 h-6 text-muted-foreground" />;
      case 3:
        return <Award className="w-6 h-6 text-amber-600" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-sm font-bold text-muted-foreground">{rank}</span>;
    }
  };

  const getBadgeColor = (badge: string) => {
    const colors: { [key: string]: string } = {
      'Legend': 'bg-neon-orange text-black',
      'Master': 'bg-neon-pink text-black',
      'Expert': 'bg-neon-blue text-black',
      'Hot Streak': 'bg-neon-green text-black',
      'Rising Star': 'bg-neon-purple text-black',
      'Speed Run': 'bg-gradient-neon text-black'
    };
    return colors[badge] || 'bg-muted text-muted-foreground';
  };

  const LeaderboardTable = ({ leaders }: { leaders: typeof allTimeLeaders }) => (
    <div className="space-y-3">
      {leaders.map((leader) => (
        <Card key={leader.rank} className="graffiti-container hover:shadow-neon transition-all duration-300">
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              {/* Rank */}
              <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center">
                {getRankIcon(leader.rank)}
              </div>

              {/* Avatar */}
              <Avatar className="w-12 h-12 border-2 border-neon-blue">
                <AvatarFallback className="bg-gradient-dark text-neon-blue font-bold">
                  {leader.username.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>

              {/* User Info */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <h3 className="font-bold text-lg truncate">{leader.username}</h3>
                  <Badge className={`text-xs ${getBadgeColor(leader.badge)}`}>
                    {leader.badge}
                  </Badge>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                  <span>{leader.missions} missions</span>
                  <span>{leader.tokens.toLocaleString()} tokens</span>
                </div>
              </div>

              {/* Score */}
              <div className="text-right">
                <div className="text-2xl font-bold neon-text">
                  {leader.score.toLocaleString()}
                </div>
                <div className="text-xs text-muted-foreground">points</div>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold neon-text mb-4">Leaderboard</h1>
          <p className="text-muted-foreground text-lg">
            See how you stack up against the best graffiti artists in LPFTS World Wide
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Stats Cards */}
          <div className="lg:col-span-1 space-y-4">
            <Card className="graffiti-container border-neon-blue">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-neon-blue">Total Artists</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">2,847</div>
                <p className="text-xs text-muted-foreground">
                  <TrendingUp className="w-3 h-3 inline mr-1" />
                  +12% this week
                </p>
              </CardContent>
            </Card>

            <Card className="graffiti-container border-neon-pink">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-neon-pink">Active Missions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">156</div>
                <p className="text-xs text-muted-foreground">
                  Across all difficulty levels
                </p>
              </CardContent>
            </Card>

            <Card className="graffiti-container border-neon-green">
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-neon-green">Tokens Earned</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1.2M</div>
                <p className="text-xs text-muted-foreground">
                  SPRAY tokens distributed
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Leaderboard */}
          <div className="lg:col-span-3">
            <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
              <TabsList className="grid w-full grid-cols-2 mb-6">
                <TabsTrigger value="all-time" className="data-[state=active]:bg-neon-blue data-[state=active]:text-black">
                  All Time
                </TabsTrigger>
                <TabsTrigger value="weekly" className="data-[state=active]:bg-neon-pink data-[state=active]:text-black">
                  This Week
                </TabsTrigger>
              </TabsList>

              <TabsContent value="all-time">
                <Card className="graffiti-container">
                  <CardHeader>
                    <CardTitle>All-Time Champions</CardTitle>
                    <CardDescription>
                      The legendary artists who've made their mark on LPFTS history
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <LeaderboardTable leaders={allTimeLeaders} />
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="weekly">
                <Card className="graffiti-container">
                  <CardHeader>
                    <CardTitle>Weekly Rising Stars</CardTitle>
                    <CardDescription>
                      This week's most active and successful artists
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <LeaderboardTable leaders={weeklyLeaders} />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Leaderboard;