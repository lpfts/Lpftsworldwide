import React from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Crown, CheckCircle, Zap, Gift, Users, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const VipSuccess = () => {
  const navigate = useNavigate();

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-lg mx-auto">
          <Card className="graffiti-container border-gradient-to-r from-yellow-400 to-orange-500 shadow-lg shadow-yellow-500/20">
            <CardHeader className="text-center">
              <div className="w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r from-yellow-400/20 to-orange-500/20 flex items-center justify-center">
                <Crown className="w-10 h-10 text-yellow-400" />
              </div>
              <div className="flex items-center justify-center mb-2">
                <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-bold px-4 py-1">
                  VIP MEMBER
                </Badge>
              </div>
              <CardTitle className="text-2xl bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent">
                Welcome to VIP!
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center space-y-2">
                <div className="flex items-center justify-center space-x-2 text-green-500">
                  <CheckCircle className="w-5 h-5" />
                  <span className="font-semibold">Subscription Active</span>
                </div>
                <p className="text-muted-foreground">
                  Your VIP membership is now active! Enjoy exclusive access to premium features.
                </p>
              </div>

              <div className="space-y-4">
                <h3 className="font-semibold text-center text-yellow-400">Your VIP Benefits:</h3>
                
                <div className="grid gap-3">
                  <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-yellow-400/10 to-orange-500/10 rounded-lg border border-yellow-400/20">
                    <Zap className="w-5 h-5 text-yellow-400" />
                    <div>
                      <p className="font-medium">Exclusive Premium Missions</p>
                      <p className="text-xs text-muted-foreground">Access high-reward missions unavailable to standard users</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-pink-500/10 to-purple-500/10 rounded-lg border border-pink-500/20">
                    <Gift className="w-5 h-5 text-pink-500" />
                    <div>
                      <p className="font-medium">Early NFT Drop Access</p>
                      <p className="text-xs text-muted-foreground">Get first access to limited edition NFT releases</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-lg border border-blue-500/20">
                    <Users className="w-5 h-5 text-blue-500" />
                    <div>
                      <p className="font-medium">VIP Community Discord</p>
                      <p className="text-xs text-muted-foreground">Join exclusive VIP channels and connect with top artists</p>
                    </div>
                  </div>

                  <div className="flex items-center space-x-3 p-3 bg-gradient-to-r from-turquoise-base/10 to-green-500/10 rounded-lg border border-turquoise-base/20">
                    <div className="w-5 h-5 rounded-full bg-turquoise-base"></div>
                    <div>
                      <p className="font-medium">Monthly Bonus Tokens</p>
                      <p className="text-xs text-muted-foreground">Receive 500 SPRAY tokens every month automatically</p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-muted/20 rounded-lg p-4 text-center">
                <p className="text-sm text-muted-foreground mb-2">
                  Your VIP status will renew automatically each month.
                </p>
                <p className="text-xs text-muted-foreground">
                  You can manage your subscription anytime in your account settings.
                </p>
              </div>

              <div className="space-y-3">
                <Button 
                  className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-black font-bold"
                  onClick={() => navigate('/missions')}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Explore VIP Missions
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full border-yellow-400 text-yellow-400 hover:bg-yellow-400 hover:text-black"
                  onClick={() => navigate('/gallery')}
                >
                  <ArrowRight className="w-4 h-4 mr-2" />
                  Continue to Gallery
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default VipSuccess;