import React from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';

const Privacy = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold neon-text mb-8 text-center">Privacy Policy</h1>
          
          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text">Information We Collect</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>We collect information you provide directly to us, such as when you create an account, participate in missions, or communicate with us.</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Account information (email, username, wallet address)</li>
                <li>Mission submissions and artwork uploads</li>
                <li>Usage data and interaction with our platform</li>
                <li>Location data for legal wall verification (when permitted)</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text">How We Use Your Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>We use the information we collect to provide, maintain, and improve our services:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Process mission submissions and verify artwork authenticity</li>
                <li>Manage SPRAY token rewards and NFT distributions</li>
                <li>Ensure compliance with legal wall regulations</li>
                <li>Improve user experience and platform functionality</li>
                <li>Communicate updates about missions and events</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text">Data Security & Blockchain</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Your privacy and security are paramount in our Web3 ecosystem:</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>All transactions are secured through blockchain technology</li>
                <li>Personal data is encrypted and stored securely</li>
                <li>We never store private keys or seed phrases</li>
                <li>Mission submissions are verified through decentralized protocols</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container">
            <CardHeader>
              <CardTitle className="turquoise-text">Contact Us</CardTitle>
            </CardHeader>
            <CardContent>
              <p>If you have any questions about this Privacy Policy, please contact us through our Discord community or email support.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Privacy;