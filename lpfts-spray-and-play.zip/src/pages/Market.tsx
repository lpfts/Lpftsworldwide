import React, { useState } from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Search, Filter, ShoppingCart, Zap, Coins, Crown, Shirt } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

const Market = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();

  // VIP Membership Tiers
  const vipTiers = [
    {
      id: 'vip-basic',
      name: 'LPFTS Basic VIP',
      description: 'Essential VIP features - Monthly bonus tokens, exclusive missions, and community access',
      category: 'vip',
      priceSpray: 0,
      pricePaint: 0,
      priceUsd: 19.99,
      stripePrice: 'price_basic_vip',
      stock: 999,
      image: null,
      isNft: false,
      isMerch: false,
      isSubscription: true,
      tier: 'Basic'
    },
    {
      id: 'vip-premium',
      name: 'LPFTS Premium VIP',
      description: 'Advanced VIP access - Early NFT drops, premium missions, Discord VIP channel, and bonus rewards',
      category: 'vip',
      priceSpray: 0,
      pricePaint: 0,
      priceUsd: 49.99,
      stripePrice: 'price_1SBwq8C31PTeCDOoWtdZLaVW',
      stock: 999,
      image: null,
      isNft: false,
      isMerch: false,
      isSubscription: true,
      tier: 'Premium'
    },
    {
      id: 'vip-elite',
      name: 'LPFTS Elite VIP',
      description: 'Ultimate VIP experience - All Premium benefits plus exclusive NFT airdrops, private events, and direct developer access',
      category: 'vip',
      priceSpray: 0,
      pricePaint: 0,
      priceUsd: 99.99,
      stripePrice: 'price_elite_vip',
      stock: 999,
      image: null,
      isNft: false,
      isMerch: false,
      isSubscription: true,
      tier: 'Elite'
    }
  ];

  // Merchandise
  const merchandise = [
    {
      id: 'merch-tshirt',
      name: 'LPFTS Gaming T-Shirt',
      description: 'Official LPFTS World Wide Gaming T-Shirt - Premium cotton blend with exclusive design',
      category: 'merch',
      priceSpray: 0,
      pricePaint: 0,
      priceUsd: 29.99,
      stripePrice: 'price_1SBwpxC31PTeCDOoB3J6QMJb',
      stock: 100,
      image: null,
      isNft: false,
      isMerch: true,
      isSubscription: false
    },
    {
      id: 'merch-hoodie',
      name: 'LPFTS Wolf Hoodie',
      description: 'Premium heavyweight hoodie with embroidered wolf logo and graffiti-style LPFTS branding',
      category: 'merch',
      priceSpray: 0,
      pricePaint: 0,
      priceUsd: 59.99,
      stripePrice: 'price_hoodie',
      stock: 75,
      image: null,
      isNft: false,
      isMerch: true,
      isSubscription: false
    },
    {
      id: 'merch-cap',
      name: 'LPFTS Snapback Cap',
      description: 'Streetwear snapback with 3D embroidered logo and premium materials',
      category: 'merch',
      priceSpray: 0,
      pricePaint: 0,
      priceUsd: 34.99,
      stripePrice: 'price_cap',
      stock: 120,
      image: null,
      isNft: false,
      isMerch: true,
      isSubscription: false
    }
  ];

  // Helper function to get price based on rarity
  const getRarityPrice = (rarity: string) => {
    switch (rarity.toLowerCase()) {
      case 'mythic': return 2000;
      case 'legendary': return 1000;
      case 'epic': return 500;
      case 'rare': return 250;
      case 'uncommon': return 100;
      case 'common': return 50;
      case 'founder og': case 'collectible og': return 1500;
      case 'flame tribe gloves': case 'light tribe gloves': case 'echo tribe gloves': return 300;
      case 'legacy graffiti style': case 'artist tribute': return 400;
      case 'cult disguise': case 'faction identity': return 200;
      case 'utility': case 'og set': return 75;
      default: return 100;
    }
  };

  // Helper function to categorize items
  const getCodexType = (name: string) => {
    if (name.includes('Zine') || name.includes('Chronicle') || name.includes('Manifesto') || name.includes('Journal') || name.includes('Blackbook') || name.includes('Bestiary') || name.includes('Codex')) return 'Magazine';
    if (name.includes('Can') || name.includes('Spray')) return 'Spray Can';
    if (name.includes('Key') || name.includes('Card')) return 'Key/Tool';
    if (name.includes('Jammer') || name.includes('Snips') || name.includes('Popper') || name.includes('Dulu') || name.includes('Taper') || name.includes('Graffite')) return 'Tool';
    if (name.includes('Gloves') || name.includes('Mask') || name.includes('Gauntlets') || name.includes('Wraps')) return 'Wearable';
    if (name.includes('Camera') || name.includes('Lens') || name.includes('Cam') || name.includes('Box')) return 'Camera';
    if (name.includes('Visor') || name.includes('Goggles') || name.includes('Headset') || name.includes('Glasses') || name.includes('Specs') || name.includes('Viewfinder') || name.includes('Compass')) return 'AR/VR';
    if (name.includes('Drone')) return 'Drone';
    return 'Misc';
  };

  // Complete LPFTS Codex Collection (100 NFTs) - Using exact names from lore book
  const generateLPFTSCodexCollection = () => {
    const codexItems = [
      // MAGAZINES
      { name: "Legacy Codex", rarity: "Legendary", description: "A sacred tome with original prophecies.", trait: "Ancient Knowledge: Reduces buff bot patrol time by 5%." },
      { name: "Street Glyph Zine", rarity: "Common", description: "A basic guide to common tags.", trait: "Beginner's Luck: 1% chance for a perfect spray line." },
      { name: "Celestial Zine", rarity: "Rare", description: "Blueprints for space-themed burners.", trait: "Star-Woven: Burner glows faintly at night." },
      { name: "Dreamtime Chronicles", rarity: "Epic", description: "A mythical magazine of future missions.", trait: "Prophetic Vision: Reveals hidden QR codes for 5 mins." },
      { name: "Vintage AdVision Mag", rarity: "Collectible OG", description: "A relic of old-school graff.", trait: "Nostalgia Aura: Reduces detection by legacy-system AI cameras." },
      { name: "The Midnight Chronicle", rarity: "Epic", description: "Tales of legendary heavenspot pieces.", trait: "Vertigo-Proof: Reduces fall damage by 50%." },
      { name: "The Buff-Proof Manifesto", rarity: "Rare", description: "A collection of anti-buffing techniques.", trait: "Stainmaker: Pieces require two buff cycles to remove." },
      { name: "The Ghost Ink Journal", rarity: "Legendary", description: "A sketchbook for invisible tags.", trait: "Ethereal Touch: Tags fade in and out of view." },
      { name: "The King's Blackbook", rarity: "Mythic", description: "A founder's journal for the elite.", trait: "Royal Authority: Place a crew tag in a difficult-to-reach spot." },
      { name: "The Urban Bestiary", rarity: "Uncommon", description: "A guide to mythical characters for fills.", trait: "Creature Feature: Characters come to life in AR for others." },
      
      // SPRAY CANS
      { name: "Origin Can (Purple)", rarity: "Founder OG", description: "A can that never runs out of paint.", trait: "Infinite Supply: No need to re-stock paint." },
      { name: "Origin Can (Red)", rarity: "Founder OG", description: "Provides an infinite supply of vibrant red paint.", trait: "Everlasting Hue: Colour never fades, regardless of weather." },
      { name: "Spectral Can", rarity: "Epic", description: "Invisible paint, visible under a blacklight.", trait: "Blacklight Reveal: Activates a mini-game to find hidden tags." },
      { name: "Chrome Fade Can", rarity: "Uncommon", description: "Creates a shimmering metallic effect.", trait: "Shiny Object: Distracts a single NPC for a brief moment." },
      { name: "9495's Spray", rarity: "Rare", description: "A tribute can with an authentic vintage rattle.", trait: "Echoes of the Past: Gives a 10% reputation bonus in old-school missions." },
      { name: "Ghost Ink Can", rarity: "Epic", description: "Creates a translucent, ghost-like fill.", trait: "Phasing Pigment: 50% less likely to be detected by drones." },
      { name: "Crimson Fury Can", rarity: "Legendary", description: "Intense, blood-red paint that never drips.", trait: "Perfect Line: All lines drawn are perfectly straight." },
      { name: "Neon Storm Can", rarity: "Rare", description: "A can that cycles through neon colours.", trait: "Color Cascade: Automatically blends colours for a perfect gradient." },
      { name: "Aura Can", rarity: "Uncommon", description: "Creates a faint, glowing outline.", trait: "Theatrical Glow: Attracts spectators, increasing $SPRAY tokens." },
      { name: "Shadow Can", rarity: "Uncommon", description: "Paints in deep, non-reflective black.", trait: "Void-Drawn: Absorbs light, making the burner stand out in the dark." },
      
      // KEYS
      { name: "Glyph Key", rarity: "Rare", description: "Unlocks missions with symbolic puzzles.", trait: "Rosetta's Blessing: Provides a hint for the first glyph puzzle." },
      { name: "Shadow Key", rarity: "Epic", description: "Opens up night-time stealth missions.", trait: "Night Walker: Reduces your sound footprint by 30%." },
      { name: "Resonance Key", rarity: "Epic", description: "Allows for crew-specific missions.", trait: "Hive Mind: Highlights a nearby crew member's location on the mini-map." },
      { name: "Legacy Key", rarity: "Legendary", description: "Unlocks Mythic-level missions.", trait: "Grand Unlocking: Single-use trait to unlock an un-buffable legacy wall." },
      { name: "Council Bypass Card", rarity: "Uncommon", description: "A one-time use card to skip a pre-mission requirement.", trait: "Backroom Deal: Instantly earns a small amount of $GRAFF tokens." },
      { name: "Beacon Key", rarity: "Rare", description: "Glows brighter the closer you are to a mission objective.", trait: "Guiding Light: Gives a visual indicator of the most efficient path." },
      { name: "Dream Key", rarity: "Legendary", description: "Unlocks missions that take place in a dream-like state.", trait: "Dream Weaver: Temporarily allows you to walk through certain walls." },
      { name: "Turf War Key", rarity: "Epic", description: "Required to enter a Turf War event.", trait: "King of the Hill: Grants a 5% spray speed bonus inside the Turf War zone." },
      { name: "Conduit Key", rarity: "Mythic", description: "Opens portals to other cities.", trait: "Teleporting Tag: Instantly place a tag in any unlocked city once per month." },
      { name: "Cipher Key", rarity: "Uncommon", description: "Unlocks missions requiring you to decode a message.", trait: "Cryptographer: Adds a Solve button to puzzle missions for a hint." },
      
      // TOOLS
      { name: "Buff Jammer", rarity: "Epic", description: "Emits a frequency to delay AI buff bots.", trait: "Glitch Protocol: Causes a buff bot to malfunction and paint over itself." },
      { name: "Ghost Snips", rarity: "Rare", description: "Silences the sound of wire-cutting.", trait: "Silent Steel: Reduces the chance of nearby NPCs being alerted by 90%." },
      { name: "Wire Snips", rarity: "Utility", description: "Cuts the power to AI cameras.", trait: "Noisy but Useful: Grants a 15-second bonus to your next burner timer." },
      { name: "Street Snips AK", rarity: "OG set", description: "A heavy-duty, loud model of snips.", trait: "Brute Force: Can cut through reinforced wire with a single use." },
      { name: "Street Snips Belta", rarity: "OG set", description: "A smaller, faster version of the OG snips.", trait: "Quick Fix: Reduces the time needed to cut a wire by 2 seconds." },
      { name: "Door Popper", rarity: "Rare", description: "A tool for quickly opening locked doors.", trait: "Locksmith: Guarantees a clean, silent door open with no alerts." },
      { name: "Dulu", rarity: "Utility", description: "A simple roller.", trait: "Broad Strokes: Fill large sections of a burner quickly." },
      { name: "Dulujulu", rarity: "Utility", description: "A roller with an extended handle.", trait: "Reach Advantage: Paint higher up on walls without climbing." },
      { name: "Midnight Taper", rarity: "Uncommon", description: "A roll of dark tape for marking out lines.", trait: "Invisible Blueprint: Tape is only visible to the player and crew." },
      { name: "Fatcap Graffite", rarity: "Rare", description: "A special cap that creates thick, bold lines.", trait: "Wide Load: Increases the width of your spray by 50%." },
      
      // WEARABLES
      { name: "Ashgrip Gauntlets", rarity: "Flame tribe gloves", description: "Fire-resistant gloves.", trait: "Heatproof Hands: Spray faster without the risk of can burn." },
      { name: "Prismhands", rarity: "Light tribe gloves", description: "Create iridescent effects in your burners.", trait: "Rainbow Glow: Automatically adds a subtle prismatic shimmer to fills." },
      { name: "Resonance Wraps", rarity: "Echo tribe gloves", description: "Emit a glow that matches other players' wraps.", trait: "Synchronized Spray: Crew members gain a 5% speed bonus when painting together." },
      { name: "NY Throw Gloves", rarity: "Legacy graffiti style", description: "Old-school gloves with a special hand style.", trait: "Classic Drip: Adds a deliberate, stylised drip effect for reputation bonus." },
      { name: "Delux Drip Gloves", rarity: "Artist tribute", description: "Prevents paint drips.", trait: "Perfectionist: All lines are clean and crisp, increasing aesthetic score." },
      { name: "Null Array Mask", rarity: "Cult disguise", description: "Scrambles your face when viewed through an AI camera.", trait: "Identity Theft: AI camera registers a random NPC's face." },
      { name: "Street Glyph Mask", rarity: "Common", description: "A basic mask for minimal stealth.", trait: "Anonymous: Grants a small reputation bonus for a well-placed tag." },
      { name: "Ghost Mask", rarity: "Rare", description: "Blends wearer into the shadows.", trait: "Shadow Walker: Visibility to NPCs reduced by 75% in dark areas." },
      { name: "Tribe Mask", rarity: "Faction identity", description: "Changes its design to match your tribe.", trait: "Faction Loyalty: Unlocks access to special faction-only missions." },
      { name: "Phantom Ink Mask", rarity: "Epic", description: "Makes you an inky silhouette to AI drones.", trait: "Veil of Smoke: Obscures you from drones for 10 seconds." },
      
      // CAMERAS
      { name: "The Lens of Truth", rarity: "Legendary", description: "A vintage film camera that captures the soul of a burner.", trait: "Buff-Proof Capture: Captured burner becomes 100% immune to being buffed for 24 hours." },
      { name: "The Snapshot", rarity: "Common", description: "A simple, digital point-and-shoot camera.", trait: "Daily Grind: Earns 50 $SPRAY tokens for every photo of a mission wall." },
      { name: "The Ghost Capture", rarity: "Rare", description: "An instant camera that develops photos in a ghostly style.", trait: "Ethereal Exposure: Reveals a hidden, unique AR element in a photo of a Ghost Ink piece." },
      { name: "The Sentinel Lens", rarity: "Epic", description: "A tactical camera with a fast shutter speed.", trait: "Quick Reflex: Grants a 15-second slow-motion effect when you're about to be detected." },
      { name: "The Aura Lens", rarity: "Uncommon", description: "Captures the energy of a piece.", trait: "Energy Scan: Reveals the rarity of a nearby NFT item or mission for 30 seconds." },
      { name: "The Glitch-Cam", rarity: "Rare", description: "A camera with a warped, pixelated lens filter.", trait: "Digital Corruption: Temporarily disrupts the signal of a nearby surveillance camera." }
    ];

    // Add remaining items to reach 100
    const additionalItems = [
      { name: "The Chrono-Lens", rarity: "Epic", description: "Captures a flashback image of a wall's past.", trait: "Temporal Echo: Reveals a faint outline of a previous, legendary burner on the wall." },
      { name: "The Rogue's Camera", rarity: "Uncommon", description: "A small, covert body camera.", trait: "Unseen Eye: Live footage can be viewed by other crew members for scouting." },
      { name: "The Dream-Time Lens", rarity: "Legendary", description: "Captures the mythical spirit of the land.", trait: "Mythical Connection: Triggers a small, AR spirit animal to appear in the game." },
      { name: "The King's Camera", rarity: "Mythic", description: "An ornate, high-end camera.", trait: "Royal Flush: Rewards the user and crew with a massive token bonus for a completed Turf War piece." },
      { name: "The Street-Vlogger Cam", rarity: "Common", description: "A basic vlogging camera with a wide lens.", trait: "Community Feed: Photos/videos get a 10% boost in likes and comments on the news feed." },
      { name: "The Drone Pilot's Camera", rarity: "Uncommon", description: "A camera with advanced zoom and a remote trigger.", trait: "Bird's Eye View: Syncs with any explorer drone to capture high-altitude photos." },
      { name: "The Shadow Box", rarity: "Rare", description: "A camera that only takes photos in low light, with a powerful flash.", trait: "Flash Bomb: The flash temporarily blinds and stuns a nearby NPC or camera." },
      { name: "The Scout Cam", rarity: "Utility", description: "A small, lightweight camera for scouting missions.", trait: "Quick Mark: Place a temporary, on-screen marker for your crew to see a potential target." },
      { name: "The Eye of the Storm", rarity: "Epic", description: "A camera that specialises in capturing motion.", trait: "Kinetic Focus: All photos taken during a high-speed chase or while running are perfectly sharp." },
      
      // AR/VR WEARABLES
      { name: "The Holo-Visor", rarity: "Uncommon", description: "A basic visor that overlays a digital image.", trait: "AR Overlay: See the QR code on a mission wall from a distance." },
      { name: "The Pixel Goggles", rarity: "Common", description: "A simple pair of digital glasses.", trait: "Sketch Assistant: Projects a faint, transparent grid onto the mission wall." },
      { name: "The Ghost Vision Headset", rarity: "Rare", description: "Specialises in seeing invisible AR elements.", trait: "Ethereal Sight: Reveals hidden clues left by other players." },
      { name: "The Chromatic Lens", rarity: "Epic", description: "Can change your vision's colour palette.", trait: "Color Shift: Changes your in-game palette to a legendary artist's colours for the next mission." },
      { name: "The Sentinel Visor", rarity: "Epic", description: "A military-grade visor that highlights threats.", trait: "Threat Detection: NPCs and cameras are highlighted with a red outline." },
      { name: "The Phantom Sight", rarity: "Legendary", description: "Allows you to see the ghosts of buffed burners.", trait: "Unbuffable Memory: Temporarily restores a buffed piece's appearance." },
      { name: "The Dream-Catcher", rarity: "Mythic", description: "A VR headset for practising burners in a virtual space.", trait: "Infinite Canvas: Teleports you to an endless virtual wall with an infinite supply of paint." },
      { name: "The Guild-Visor", rarity: "Rare", description: "Displays the rank and reputation of nearby players.", trait: "Rank Aura: Your own reputation is broadcasted to nearby players." },
      { name: "The Echo-Lens", rarity: "Uncommon", description: "Shows you the past footsteps of other players on the map.", trait: "Trail Blazer: Follow the footsteps of a legend to discover a high-value drop." },
      { name: "The Visionary Glasses", rarity: "Legendary", description: "Projects a 3D AR model of your burner onto the wall.", trait: "Perfect Plan: Allows you to refine your piece in AR, earning a perfect aesthetic score." },
      { name: "The Scryer's Goggles", rarity: "Epic", description: "Goggles that can scry for hidden items.", trait: "Drop Seeker: A subtle glowing effect appears, guiding you to a mission drop." },
      { name: "The Neon-Ray Specs", rarity: "Common", description: "Makes all in-game neon lights glow brighter.", trait: "Light-Sensitive: Reveals hidden $SPRAY and $GRAFF tokens in the glow of streetlights." },
      { name: "The Ghost-Ember Glasses", rarity: "Rare", description: "Makes the embers of your piece appear to be glowing.", trait: "Ember-Glow: Pieces with a fire or ash theme become more visible and earn an extra reputation bonus." },
      { name: "The Architect's Viewfinder", rarity: "Uncommon", description: "Displays the structural lines of a wall.", trait: "Perfect Angles: Helps you create a piece with perfect symmetry and balance." },
      { name: "The Memento Goggles", rarity: "Rare", description: "Lets you replay a burner's creation in fast-forward.", trait: "Artist's Memory: Re-watch the entire process to find areas for improvement." },
      { name: "The Graffiti Compass", rarity: "Utility", description: "Points you to the nearest legal wall.", trait: "Path Finder: Guides you to the next mission or a high-traffic area for an event." },
      { name: "The Sentry-Visor", rarity: "Uncommon", description: "Gives you a limited, night-vision view.", trait: "Night Owl: Increases your stealth by 20% during night-time missions." },
      { name: "The Community-Visor", rarity: "Common", description: "Displays real-time comments from other players on walls.", trait: "Public Opinion: Gives a bonus to your social score for interacting with others." },
      { name: "The Hyper-Reality Goggles", rarity: "Epic", description: "Makes all your AR creations look hyper-realistic.", trait: "Super-Saturated: The colours in your AR burner briefly disorient NPCs." },
      { name: "The Code-Breaker Lens", rarity: "Legendary", description: "Can visually decode a QR mission.", trait: "Cipher: Reveals all the objectives of a mission before you scan the QR code." },
      { name: "The Echo-Pulse Goggles", rarity: "Rare", description: "Creates a visual echo of your spray patterns.", trait: "Visual Rhythm: Helps you match your spray speed to the beat for a consistency bonus." },
      { name: "The Aura Spectacles", rarity: "Uncommon", description: "Highlights all nearby cans and tools with a faint colour aura.", trait: "Resourceful: Makes it easier to find dropped or hidden items." },
      { name: "The Architect's Goggles", rarity: "Rare", description: "Lets you see the virtual blueprint of a wall.", trait: "Golden Ratio: Placing a piece in a highlighted zone earns a bonus on your aesthetic score." },
      { name: "The Data-Stream Goggles", rarity: "Epic", description: "Streams real-time data from the LPFTS news feed.", trait: "Information Overload: Gives you a heads-up on incoming Turf Wars or events before they are announced." },
      { name: "The Pixel-Perfect View", rarity: "Legendary", description: "Makes all your spray lines appear perfectly smooth.", trait: "Virtual Stability: Grants a 100% perfection bonus to all your lines and fills." },
      
      // DRONES
      { name: "The Scout Drone", rarity: "Common", description: "A small, quiet drone for basic reconnaissance.", trait: "Silent Flyer: Can scout without alerting NPCs or cameras." },
      { name: "The Sentinel Drone", rarity: "Rare", description: "A drone equipped with a spotlight.", trait: "Searchlight: Can illuminate a hard-to-reach area or briefly blind a surveillance camera." },
      { name: "The Phantom Drone", rarity: "Epic", description: "A drone with an invisibility cloaking device.", trait: "Ghost in the Machine: Becomes completely invisible to NPCs and other players for 60 seconds." },
      { name: "The Courier Drone", rarity: "Uncommon", description: "A drone designed to carry small items.", trait: "Item Transfer: Can transport a single can or tool to a crew member." },
      { name: "The Eye in the Sky Drone", rarity: "Epic", description: "A drone with a high-resolution camera and powerful zoom.", trait: "Aerial Recon: Provides a full, real-time map of the area, revealing patrol routes and cameras." },
      { name: "The Shadow Drone", rarity: "Rare", description: "A drone that blends into its surroundings.", trait: "Camouflage: Becomes invisible to AI surveillance drones and cameras, but can still be seen by NPCs." },
      { name: "The Turf War Drone", rarity: "Legendary", description: "A heavy-duty drone for large-scale documentation.", trait: "King's View: Captures a stunning panoramic view of a completed Turf War piece, earning a massive community reputation boost." },
      { name: "The Mythic Drone", rarity: "Mythic", description: "A drone powered by a mythical core.", trait: "Unstoppable: Cannot be shot down or disrupted; camera also captures mythical AR spirits." },
      { name: "The Graffiti Drone", rarity: "Uncommon", description: "A drone with a simple spray nozzle attachment.", trait: "Remote Tag: Spray a single tag on a hard-to-reach spot from a safe distance." },
      { name: "The Spy Drone", rarity: "Rare", description: "A tiny, insect-like drone.", trait: "Infiltrator: Can be sent inside buildings to scout and find hidden mission objectives." }
    ];

    const allItems = [...codexItems, ...additionalItems];
    
    return allItems.map((item, index) => {
      const basePrice = getRarityPrice(item.rarity.toLowerCase());
      return {
        id: `codex-${(index + 1).toString().padStart(3, '0')}`,
        name: item.name,
        description: item.description,
        category: 'nft',
        priceSpray: 0,
        pricePaint: basePrice,
        priceUsd: basePrice * 0.12,
        stock: 1,
        image: null,
        isNft: true,
        stripePrice: '',
        isSubscription: false,
        isMerch: false,
        rarity: item.rarity,
        trait: item.trait,
        codexType: getCodexType(item.name)
      };
    });
  };

  // Game Items & Tools
  const gameItems = [
    {
      id: 'spray-premium',
      name: 'Premium Spray Can',
      description: 'High-quality spray paint for detailed work',
      category: 'spray',
      priceSpray: 50,
      pricePaint: 0,
      priceUsd: 2.99,
      stock: 100,
      image: null,
      isNft: false,
      stripePrice: '',
      isSubscription: false
    },
    {
      id: 'marker-neon',
      name: 'Neon Marker Set',
      description: 'Set of 6 neon markers for fine details',
      category: 'spray',
      priceSpray: 75,
      pricePaint: 0,
      priceUsd: 4.99,
      stock: 50,
      image: null,
      isNft: false,
      stripePrice: '',
      isSubscription: false
    },
    {
      id: 'gloves-grip',
      name: 'Graffiti Gloves',
      description: 'Professional grip gloves for artists',
      category: 'gear',
      priceSpray: 25,
      pricePaint: 0,
      priceUsd: 1.99,
      stock: 75,
      image: null,
      isNft: false,
      stripePrice: '',
      isSubscription: false
    },
    {
      id: 'paint-led',
      name: 'LED Paint',
      description: 'Special glow-in-the-dark paint',
      category: 'spray',
      priceSpray: 150,
      pricePaint: 50,
      priceUsd: 12.99,
      stock: 20,
      image: null,
      isNft: false,
      stripePrice: '',
      isSubscription: false
    }
  ];

  const marketItems = [
    ...vipTiers,
    ...merchandise,
    ...generateLPFTSCodexCollection(),
    ...gameItems
  ];

  const categories = [
    { id: 'all', name: 'All Items', count: marketItems.length },
    { id: 'vip', name: 'VIP Memberships', count: marketItems.filter(item => item.category === 'vip').length },
    { id: 'merch', name: 'Official Merch', count: marketItems.filter(item => item.category === 'merch').length },
    { id: 'nft', name: 'NFT Collection', count: marketItems.filter(item => item.category === 'nft').length },
    { id: 'spray', name: 'Game Items', count: marketItems.filter(item => item.category === 'spray').length },
    { id: 'gear', name: 'Equipment', count: marketItems.filter(item => item.category === 'gear').length },
  ];

  const filteredItems = marketItems.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         item.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'merch': return 'bg-purple-500 text-white';
      case 'vip': return 'bg-gradient-to-r from-yellow-400 to-orange-500 text-black';
      case 'spray': return 'bg-turquoise-base text-black';
      case 'nft': return 'bg-gradient-to-r from-pink-500 to-purple-600 text-white';
      case 'gear': return 'bg-green-500 text-black';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'Mythic': return 'bg-gradient-to-r from-orange-500 to-red-600 text-white';
      case 'Legendary': return 'bg-gradient-to-r from-yellow-500 to-orange-500 text-black';
      case 'Epic': return 'bg-gradient-to-r from-purple-500 to-pink-500 text-white';
      case 'Rare': return 'bg-gradient-to-r from-blue-500 to-purple-500 text-white';
      case 'Uncommon': return 'bg-gradient-to-r from-green-500 to-blue-500 text-white';
      case 'Common': return 'bg-gray-500 text-white';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const handlePurchase = async (item: any, paymentMethod: string) => {
    if (!isAuthenticated) {
      toast({
        title: "Sign in required",
        description: "Please sign in to make purchases",
        variant: "destructive",
      });
      return;
    }

    if (paymentMethod === 'usd' && (item.stripePrice || item.isSubscription)) {
      // For now, show success message - Stripe integration will be completed later
      toast({
        title: "Stripe Integration",
        description: "Stripe checkout will be implemented soon! For now, enjoy the app features.",
      });
    } else {
      // Mock purchase for token-based items
      toast({
        title: "Purchase successful! 🎉",
        description: `Successfully purchased ${item.name} with ${paymentMethod}`,
      });
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold turquoise-text mb-4">LPFTS Marketplace</h1>
          <p className="text-muted-foreground text-lg">
            Trade tokens, buy gear, collect NFTs, and get exclusive merch & VIP access
          </p>
        </div>

        {/* Search and Filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            {categories.map((category) => (
              <Button
                key={category.id}
                variant={selectedCategory === category.id ? "default" : "outline"}
                onClick={() => setSelectedCategory(category.id)}
                className={selectedCategory === category.id ? "bg-turquoise-base text-black" : ""}
              >
                {category.name} ({category.count})
              </Button>
            ))}
          </div>
        </div>

        {/* Items Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item) => (
            <Card key={item.id} className="graffiti-container hover:shadow-turquoise transition-all duration-300">
              {/* Item Image Placeholder */}
              <div className="aspect-square bg-gradient-dark rounded-t-lg flex items-center justify-center">
                <div className="text-center">
                  <div className="text-4xl mb-2">
                    {item.category === 'merch' ? <Shirt className="w-16 h-16 mx-auto text-purple-400" /> :
                     item.category === 'vip' ? <Crown className="w-16 h-16 mx-auto text-yellow-400" /> :
                     item.isNft ? '🖼️' : 
                     item.category === 'spray' ? '🎨' : '🧤'}
                  </div>
                  <p className="text-turquoise-bright font-bold text-sm">{item.name}</p>
                </div>
              </div>

              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex gap-1 flex-wrap">
                    <Badge className={`text-xs ${getCategoryColor(item.category)}`}>
                      {item.category === 'merch' ? 'OFFICIAL MERCH' :
                       item.category === 'vip' ? `VIP ${(item as any).tier?.toUpperCase() || 'MEMBERSHIP'}` :
                       item.category.toUpperCase()}
                      {item.isNft && ' NFT'}
                      {item.isSubscription && ' MONTHLY'}
                    </Badge>
                    {(item as any).rarity && (
                      <Badge className={`text-xs ${getRarityColor((item as any).rarity)}`}>
                        {(item as any).rarity}
                      </Badge>
                    )}
                  </div>
                  <span className="text-xs text-muted-foreground">
                    Stock: {item.stock}
                  </span>
                </div>
                <CardTitle className="text-lg">{item.name}</CardTitle>
                <CardDescription className="text-sm">
                  {item.description}
                </CardDescription>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* Special VIP/Merch Features */}
                {item.category === 'vip' && (
                  <div className="p-3 bg-gradient-to-r from-yellow-400/10 to-orange-500/10 rounded-lg border border-yellow-400/20">
                    <h4 className="font-semibold text-yellow-400 mb-2">{(item as any).tier} VIP Benefits:</h4>
                    <ul className="text-xs space-y-1 text-muted-foreground">
                      {(item as any).tier === 'Basic' && (
                        <>
                          <li>• Monthly bonus SPRAY tokens</li>
                          <li>• Exclusive missions access</li>
                          <li>• Community Discord access</li>
                        </>
                      )}
                      {(item as any).tier === 'Premium' && (
                        <>
                          <li>• All Basic benefits</li>
                          <li>• Early NFT drop access</li>
                          <li>• VIP Discord channels</li>
                          <li>• 2x bonus mission rewards</li>
                        </>
                      )}
                      {(item as any).tier === 'Elite' && (
                        <>
                          <li>• All Premium benefits</li>
                          <li>• Exclusive NFT airdrops</li>
                          <li>• Private events access</li>
                          <li>• Direct developer access</li>
                          <li>• 5x bonus mission rewards</li>
                        </>
                      )}
                    </ul>
                  </div>
                )}

                {/* NFT Features */}
                {item.isNft && (
                  <div className="p-3 bg-gradient-to-r from-pink-500/10 to-purple-600/10 rounded-lg border border-pink-500/20">
                    <h4 className="font-semibold text-pink-400 mb-2">NFT Properties:</h4>
                    <ul className="text-xs space-y-1 text-muted-foreground">
                      <li>• Rarity: {(item as any).rarity}</li>
                      <li>• Type: {(item as any).nftType}</li>
                      <li>• Unique traits & abilities</li>
                      <li>• Tradeable on marketplace</li>
                    </ul>
                  </div>
                )}

                {/* Pricing Options */}
                <Tabs defaultValue={item.stripePrice ? "usd" : "tokens"} className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="tokens" disabled={!item.priceSpray && !item.pricePaint}>Tokens</TabsTrigger>
                    <TabsTrigger value="usd">USD</TabsTrigger>
                  </TabsList>

                  <TabsContent value="tokens" className="space-y-3">
                    {item.priceSpray > 0 && (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Zap className="w-4 h-4 text-turquoise-base" />
                          <span className="text-sm">SPRAY</span>
                        </div>
                        <span className="font-bold">{item.priceSpray}</span>
                      </div>
                    )}
                    {item.pricePaint > 0 && (
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <div className="w-4 h-4 rounded-full bg-pink-500"></div>
                          <span className="text-sm">PAINT</span>
                        </div>
                        <span className="font-bold">{item.pricePaint}</span>
                      </div>
                    )}
                    <Button 
                      className="w-full bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
                      onClick={() => handlePurchase(item, 'tokens')}
                      disabled={item.stock === 0 || (!item.priceSpray && !item.pricePaint)}
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      {item.stock === 0 ? 'Out of Stock' : 'Buy with Tokens'}
                    </Button>
                  </TabsContent>

                  <TabsContent value="usd" className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Coins className="w-4 h-4 text-green-500" />
                        <span className="text-sm">Price</span>
                      </div>
                      <span className="font-bold text-lg">${item.priceUsd}</span>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full border-green-500 text-green-500 hover:bg-green-500 hover:text-black"
                      onClick={() => handlePurchase(item, 'usd')}
                      disabled={item.stock === 0}
                    >
                      <ShoppingCart className="w-4 h-4 mr-2" />
                      {item.stock === 0 ? 'Out of Stock' : 
                       item.isSubscription ? 'Subscribe Monthly' : 
                       'Buy with USD'}
                    </Button>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">🛒</div>
            <h3 className="text-xl font-bold mb-2">No items found</h3>
            <p className="text-muted-foreground">
              Try adjusting your search or category filter
            </p>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default Market;