import React from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ExternalLink, FileText, Paintbrush, Download, Shirt, Crown } from 'lucide-react';

const Merch = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold neon-text mb-4">LPFTS Official Merch</h1>
            <p className="text-muted-foreground text-lg">
              Design templates, official merchandise, and exclusive content for the LPFTS community
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
            {/* Figma Design Template */}
            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="turquoise-text flex items-center">
                  <Paintbrush className="w-6 h-6 mr-2" />
                  Graffiti Design Template
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-video bg-muted/20 rounded-lg flex items-center justify-center mb-4">
                  <div className="text-center">
                    <Paintbrush className="w-16 h-16 mx-auto text-turquoise-base mb-2" />
                    <p className="text-sm text-muted-foreground">Interactive Figma Template</p>
                  </div>
                </div>
                <p>
                  Create your own graffiti masterpieces with our official Figma template. Includes different brush strokes, 
                  color palettes, and design elements inspired by the LPFTS aesthetic.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge className="bg-turquoise-base text-black">Free to Use</Badge>
                  <Badge className="bg-purple-500 text-white">Figma Template</Badge>
                  <Badge className="bg-neon-blue text-black">Community Resource</Badge>
                </div>
                <Button 
                  className="w-full bg-gradient-turquoise hover:shadow-turquoise font-semibold"
                  onClick={() => window.open('https://www.figma.com/design/graffiti-template', '_blank')}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Open Figma Template
                </Button>
              </CardContent>
            </Card>

            {/* Full Codex PDF */}
            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="turquoise-text flex items-center">
                  <FileText className="w-6 h-6 mr-2" />
                  LPFTS Worldwide Codex
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-video bg-muted/20 rounded-lg flex items-center justify-center mb-4">
                  <div className="text-center">
                    <FileText className="w-16 h-16 mx-auto text-turquoise-base mb-2" />
                    <p className="text-sm text-muted-foreground">Complete Story & Guide</p>
                  </div>
                </div>
                <p>
                  Download the complete LPFTS Worldwide Codex featuring the full storyline of Saul and Blaze, 
                  all 100 NFT items, mission guides, and the rich lore of the League of Wolves.
                </p>
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge className="bg-turquoise-base text-black">Complete Edition</Badge>
                  <Badge className="bg-orange-500 text-white">PDF Format</Badge>
                  <Badge className="bg-green-500 text-white">Free Download</Badge>
                </div>
                <Button 
                  className="w-full bg-gradient-turquoise hover:shadow-turquoise font-semibold"
                  onClick={() => window.open('/lpfts-worldwide-codex.pdf', '_blank')}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Download Full Codex
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Official Merchandise */}
          <Card className="graffiti-container">
            <CardHeader>
              <CardTitle className="turquoise-text flex items-center">
                <Shirt className="w-6 h-6 mr-2" />
                Official Merchandise
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 bg-muted/10 rounded-lg">
                  <Shirt className="w-12 h-12 mx-auto text-purple-400 mb-3" />
                  <h3 className="font-semibold mb-2">LPFTS Gaming T-Shirt</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Premium cotton blend with exclusive design
                  </p>
                  <Badge className="bg-purple-500 text-white">$25.00</Badge>
                </div>
                
                <div className="text-center p-6 bg-muted/10 rounded-lg">
                  <Crown className="w-12 h-12 mx-auto text-yellow-400 mb-3" />
                  <h3 className="font-semibold mb-2">LPFTS Wolf Hoodie</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Heavyweight hoodie with embroidered wolf logo
                  </p>
                  <Badge className="bg-purple-500 text-white">$45.00</Badge>
                </div>
                
                <div className="text-center p-6 bg-muted/10 rounded-lg">
                  <Shirt className="w-12 h-12 mx-auto text-blue-400 mb-3" />
                  <h3 className="font-semibold mb-2">LPFTS Snapback Cap</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    Streetwear snapback with 3D embroidered logo
                  </p>
                  <Badge className="bg-purple-500 text-white">$20.00</Badge>
                </div>
              </div>
              
              <div className="text-center mt-8">
                <Button 
                  className="bg-gradient-turquoise hover:shadow-turquoise font-semibold"
                  onClick={() => window.location.href = '/market'}
                >
                  Shop All Merchandise
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Merch;