import React, { useState } from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MapPin, Clock, Trophy, Star, Palette, Upload, ExternalLink, ChevronDown } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import ColorPalette from '@/components/ColorPalette';
import MissionSubmissionWidget from '@/components/MissionSubmissionWidget';
import { supabase } from '@/integrations/supabase/client';

const Missions = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const [selectedMission, setSelectedMission] = useState<any>(null);
  const [showPaletteDialog, setShowPaletteDialog] = useState(false);
  const [showSubmissionWidget, setShowSubmissionWidget] = useState(false);
  const missions = [
    {
      id: 1,
      title: 'Gold Coast Waves',
      description: 'Create an ocean-inspired piece at Southport Legal Wall using aquatic color palettes',
      difficulty: 'Beginner',
      location: 'Southport Legal Wall, QLD',
      reward: '100 SPRAY',
      status: 'available',
      timeLimit: '24 hours',
      palette: {
        name: 'Ocean Breeze',
        colors: ['#00CED1', '#20B2AA', '#4682B4', '#87CEEB', '#B0E0E6', '#E0F6FF'],
        theme: 'Cool aquatic tones perfect for beginners'
      }
    },
    {
      id: 2,
      title: 'Melbourne Lane Legends',
      description: 'Master the iconic Hosier Lane with a cyberpunk masterpiece',
      difficulty: 'Advanced',
      location: 'Hosier Lane, Melbourne VIC',
      reward: '250 SPRAY + NFT',
      status: 'available',
      timeLimit: '48 hours',
      palette: {
        name: 'Cyberpunk Dreams',
        colors: [
          '#0D1B2A', '#1B263B', '#415A77', '#778DA9', '#E0E1DD',
          '#00FFFF', '#FF00FF', '#FFFF00', '#FF6B35', '#7209B7',
          '#A663CC', '#4EA5D9', '#006BA6', '#003F5C', '#2F1B69',
          '#8E44AD', '#E74C3C', '#F39C12', '#27AE60', '#3498DB'
        ],
        theme: 'Complex cyberpunk aesthetic with multiple accent colors'
      }
    },
    {
      id: 3,
      title: 'Brisbane West End Vibes',
      description: 'Capture the urban energy of West End with vibrant street art',
      difficulty: 'Intermediate',
      location: 'West End Wall, Brisbane QLD',
      reward: '175 SPRAY',
      status: 'available',
      timeLimit: '36 hours',
      palette: {
        name: 'Urban Night',
        colors: ['#1C1C1C', '#4A4A4A', '#00FFFF', '#FF00FF', '#FFFF00', '#00FF00', '#FF4500', '#8A2BE2'],
        theme: 'City nightlife with neon accents'
      }
    },
    {
      id: 4,
      title: 'Perth Underground',
      description: 'Transform The Walls in Northbridge with your artistic vision',
      difficulty: 'Intermediate',
      location: 'The Walls, Northbridge Perth WA',
      reward: '175 SPRAY',
      status: 'available',
      timeLimit: '36 hours',
      palette: {
        name: 'Forest Mystery',
        colors: ['#013220', '#228B22', '#32CD32', '#90EE90', '#8FBC8F', '#F0FFF0', '#FFD700', '#FF6347'],
        theme: 'Deep forest greens with natural highlights'
      }
    },
    {
      id: 5,
      title: 'Valley Street Culture',
      description: 'Show off your skills at Fortitude Valley\'s premier legal wall',
      difficulty: 'Beginner',
      location: 'Fortitude Valley Legal Wall, Brisbane QLD',
      reward: '100 SPRAY',
      status: 'available',
      timeLimit: '24 hours',
      palette: {
        name: 'Sunset Glow',
        colors: ['#FF6B35', '#F7931E', '#FFD23F', '#EE4B2B', '#FF69B4', '#FFA07A'],
        theme: 'Warm sunset hues for vibrant pieces'
      }
    },
    {
      id: 6,
      title: 'AC/DC Lane Rock',
      description: 'Pay homage to rock legends with an advanced piece in AC/DC Lane',
      difficulty: 'Advanced',
      location: 'AC/DC Lane, Melbourne VIC',
      reward: '250 SPRAY + NFT',
      status: 'completed',
      timeLimit: '48 hours',
      palette: {
        name: 'Rainbow Riot',
        colors: [
          '#FF0000', '#FF4500', '#FF8C00', '#FFD700', '#FFFF00', '#ADFF2F',
          '#00FF00', '#00FA9A', '#00FFFF', '#0080FF', '#0000FF', '#4169E1',
          '#8A2BE2', '#9400D3', '#FF00FF', '#FF1493', '#FF69B4', '#FFB6C1',
          '#FFFFFF', '#000000'
        ],
        theme: 'Full spectrum rainbow with professional gradients'
      }
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-turquoise-base';
      case 'Intermediate': return 'bg-turquoise-light';
      case 'Advanced': return 'bg-turquoise-bright';
      default: return 'bg-muted';
    }
  };

  const handleStartMission = (mission: any) => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    setSelectedMission(mission);
    setShowPaletteDialog(true);
  };

  const handlePaletteSelect = async (palette: any) => {
    if (!user || !selectedMission) return;

    try {
      const { error } = await supabase
        .from('mission_submissions')
        .insert({
          user_id: user.id,
          mission_title: selectedMission.title,
          difficulty: selectedMission.difficulty,
          palette: palette,
          legal_wall_location: selectedMission.location
        });

      if (error) throw error;

      setShowPaletteDialog(false);
      setSelectedMission(null);
      // Navigate to a mission detail page or show success
      alert(`Mission started with ${palette.name} palette! Find a legal wall and start creating.`);
    } catch (error) {
      console.error('Error starting mission:', error);
      alert('Failed to start mission. Please try again.');
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold neon-text mb-4">Active Missions</h1>
              <p className="text-muted-foreground text-lg">
                Complete missions to earn SPRAY tokens and unlock exclusive content
              </p>
              <div className="flex gap-2 mt-4">
                <Button 
                  onClick={() => window.open('https://www.figma.com/design/3od8reDyuQGaVBcYeVd49j/Untitled?node-id=3-110&p=f&m=draw', '_blank')}
                  variant="outline"
                  className="border-turquoise-base/50 text-turquoise-base hover:bg-turquoise-base/10"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Design Reference
                </Button>
              </div>
            </div>
            <div className="flex gap-2">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="border-turquoise-base/50">
                    Quick Actions <ChevronDown className="w-4 h-4 ml-2" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent>
                  <DropdownMenuItem onClick={() => setShowSubmissionWidget(true)}>
                    <Upload className="w-4 h-4 mr-2" />
                    Submit Mission
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => window.location.href = '/market?category=nft'}>
                    <Star className="w-4 h-4 mr-2" />
                    Browse NFTs
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => window.location.href = '/gallery'}>
                    <Trophy className="w-4 h-4 mr-2" />
                    View Gallery
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
              <Button 
                onClick={() => setShowSubmissionWidget(true)}
                className="bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
              >
                <Upload className="w-4 h-4 mr-2" />
                Quick Submit
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {missions.map((mission) => (
            <Card key={mission.id} className="graffiti-container hover:shadow-neon transition-all duration-300">
              <CardHeader>
                <div className="flex items-center justify-between mb-2">
                  <Badge className={`${getDifficultyColor(mission.difficulty)} text-black font-semibold`}>
                    {mission.difficulty}
                  </Badge>
                  <Badge variant={mission.status === 'completed' ? 'secondary' : 'outline'} className="text-xs">
                    {mission.status}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{mission.title}</CardTitle>
                <CardDescription className="text-sm">
                  {mission.description}
                </CardDescription>
                {mission.palette && (
                  <div className="mt-2 space-y-2">
                    <Badge variant="outline" className="text-xs border-turquoise-base/50 text-turquoise-base">
                      <Palette className="w-3 h-3 mr-1" />
                      {mission.palette.name}
                    </Badge>
                    {/* Color palette preview */}
                    <div className="flex flex-wrap gap-1">
                      {mission.palette.colors.slice(0, 6).map((color: string, colorIndex: number) => (
                        <div
                          key={colorIndex}
                          className="w-4 h-4 rounded-sm border border-border/20"
                          style={{ backgroundColor: color }}
                          title={color}
                        />
                      ))}
                      {mission.palette.colors.length > 6 && (
                        <div className="w-4 h-4 rounded-sm bg-muted border border-border/20 flex items-center justify-center text-xs">
                          +{mission.palette.colors.length - 6}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2 text-sm">
                  <div className="flex items-center text-muted-foreground">
                    <MapPin className="w-4 h-4 mr-2 text-neon-blue" />
                    {mission.location}
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Clock className="w-4 h-4 mr-2 text-neon-orange" />
                    {mission.timeLimit}
                  </div>
                  <div className="flex items-center text-muted-foreground">
                    <Trophy className="w-4 h-4 mr-2 text-neon-green" />
                    {mission.reward}
                  </div>
                </div>
                
                {mission.status === 'available' ? (
                  <Button 
                    className="w-full bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
                    onClick={() => handleStartMission(mission)}
                  >
                    <Palette className="w-4 h-4 mr-2" />
                    Start Mission
                  </Button>
                ) : (
                  <Button variant="outline" className="w-full" disabled>
                    <Star className="w-4 h-4 mr-2" />
                    Completed
                  </Button>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Color Palette Dialog */}
        <Dialog open={showPaletteDialog} onOpenChange={setShowPaletteDialog}>
          <DialogContent className="max-w-4xl graffiti-container">
            <DialogHeader>
              <DialogTitle className="turquoise-text text-center">
                Choose Your Color Palette
              </DialogTitle>
            </DialogHeader>
            {selectedMission && (
              <ColorPalette 
                difficulty={selectedMission.difficulty as 'Beginner' | 'Intermediate' | 'Advanced'}
                onSelectPalette={handlePaletteSelect}
              />
            )}
          </DialogContent>
        </Dialog>

        {/* Mission Submission Widget */}
        <Dialog open={showSubmissionWidget} onOpenChange={setShowSubmissionWidget}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <MissionSubmissionWidget 
              isOpen={showSubmissionWidget}
              onClose={() => setShowSubmissionWidget(false)}
            />
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default Missions;