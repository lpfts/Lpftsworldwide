import React, { useState, useEffect } from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { UserPlus, LogIn, Mail, Lock, User, AlertCircle, Shield } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useNavigate } from 'react-router-dom';
import { z } from 'zod';
import { 
  usernameSchema, 
  emailSchema, 
  passwordSchema, 
  RateLimiter 
} from '@/lib/validation';

const signUpSchema = z.object({
  email: emailSchema,
  password: passwordSchema,
  username: usernameSchema
});

const signInSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, { message: "Password is required" })
});

const Auth = () => {
  const navigate = useNavigate();
  const { isAuthenticated, signUp, signIn } = useAuth();
  const [activeTab, setActiveTab] = useState('signin');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Form states
  const [signInData, setSignInData] = useState({
    email: '',
    password: ''
  });

  const [signUpData, setSignUpData] = useState({
    email: '',
    password: '',
    username: ''
  });

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      navigate('/');
    }
  }, [isAuthenticated, navigate]);

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Rate limiting check
    const rateLimiter = RateLimiter.getInstance();
    if (!rateLimiter.isAllowed('auth_signin', 5, 300000)) { // 5 attempts per 5 minutes
      const remainingTime = Math.ceil(rateLimiter.getRemainingTime('auth_signin', 300000) / 1000 / 60);
      setError(`Too many sign in attempts. Please wait ${remainingTime} minutes.`);
      setLoading(false);
      return;
    }

    try {
      const validation = signInSchema.parse(signInData);
      const { error } = await signIn(validation.email, validation.password);
      
      if (!error) {
        navigate('/');
      }
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        setError(err.issues[0].message);
      } else {
        setError('Sign in failed. Please check your credentials.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSignUp = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // Rate limiting check
    const rateLimiter = RateLimiter.getInstance();
    if (!rateLimiter.isAllowed('auth_signup', 3, 3600000)) { // 3 attempts per hour
      const remainingTime = Math.ceil(rateLimiter.getRemainingTime('auth_signup', 3600000) / 1000 / 60);
      setError(`Too many sign up attempts. Please wait ${remainingTime} minutes.`);
      setLoading(false);
      return;
    }

    try {
      const validation = signUpSchema.parse(signUpData);
      const { error } = await signUp(validation.email, validation.password, validation.username);
      
      if (!error) {
        setActiveTab('signin');
        setError('');
        // Success toast is handled by useAuth hook
      }
    } catch (err: any) {
      if (err instanceof z.ZodError) {
        setError(err.issues[0].message);
      } else {
        setError('Sign up failed. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold turquoise-text mb-4">Join LPFTS</h1>
            <p className="text-muted-foreground">
              Access missions, earn tokens, and showcase your art
            </p>
          </div>

          <Card className="graffiti-container border-turquoise-base">
            <CardContent className="p-0">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid w-full grid-cols-2 mb-6">
                  <TabsTrigger value="signin" className="data-[state=active]:bg-turquoise-base data-[state=active]:text-black">
                    Sign In
                  </TabsTrigger>
                  <TabsTrigger value="signup" className="data-[state=active]:bg-turquoise-light data-[state=active]:text-black">
                    Sign Up
                  </TabsTrigger>
                </TabsList>

                {error && (
                  <Alert className="border-destructive mb-6 mx-6">
                    <AlertCircle className="w-4 h-4" />
                    <AlertDescription>{error}</AlertDescription>
                  </Alert>
                )}

                <Alert className="border-turquoise-base/20 bg-turquoise-base/5 mb-6 mx-6">
                  <Shield className="w-4 h-4 text-turquoise-base" />
                  <AlertDescription className="text-turquoise-base">
                    Your data is protected with enterprise-grade security and encryption.
                  </AlertDescription>
                </Alert>

                <TabsContent value="signin" className="px-6 pb-6">
                  <form onSubmit={handleSignIn} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signin-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signin-email"
                          type="email"
                          placeholder="Enter your email"
                          value={signInData.email}
                          onChange={(e) => setSignInData(prev => ({ ...prev, email: e.target.value }))}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signin-password">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signin-password"
                          type="password"
                          placeholder="Enter your password"
                          value={signInData.password}
                          onChange={(e) => setSignInData(prev => ({ ...prev, password: e.target.value }))}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-turquoise hover:shadow-turquoise font-semibold"
                      disabled={loading}
                    >
                      <LogIn className="w-4 h-4 mr-2" />
                      {loading ? 'Signing In...' : 'Sign In'}
                    </Button>
                  </form>
                </TabsContent>

                <TabsContent value="signup" className="px-6 pb-6">
                  <form onSubmit={handleSignUp} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="signup-username">Username</Label>
                      <div className="relative">
                        <User className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signup-username"
                          type="text"
                          placeholder="Choose a username"
                          value={signUpData.username}
                          onChange={(e) => setSignUpData(prev => ({ ...prev, username: e.target.value }))}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-email">Email</Label>
                      <div className="relative">
                        <Mail className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signup-email"
                          type="email"
                          placeholder="Enter your email"
                          value={signUpData.email}
                          onChange={(e) => setSignUpData(prev => ({ ...prev, email: e.target.value }))}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="signup-password">Password</Label>
                      <div className="relative">
                        <Lock className="absolute left-3 top-3 w-4 h-4 text-muted-foreground" />
                        <Input
                          id="signup-password"
                          type="password"
                          placeholder="Create a password"
                          value={signUpData.password}
                          onChange={(e) => setSignUpData(prev => ({ ...prev, password: e.target.value }))}
                          className="pl-10"
                          required
                        />
                      </div>
                    </div>

                    <Button 
                      type="submit" 
                      className="w-full bg-gradient-turquoise hover:shadow-turquoise font-semibold"
                      disabled={loading}
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      {loading ? 'Creating Account...' : 'Create Account'}
                    </Button>
                  </form>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <div className="text-center mt-6">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-muted-foreground hover:text-turquoise-base"
            >
              Return to Home
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Auth;