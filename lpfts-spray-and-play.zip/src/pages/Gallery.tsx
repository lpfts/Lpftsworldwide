import React from 'react';
import { Layout } from '@/components/Layout';
import { SocialGallery } from '@/components/SocialGallery';

const Gallery = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold turquoise-text mb-4">Community Gallery</h1>
          <p className="text-muted-foreground text-lg">
            Discover amazing graffiti art from LPFTS artists worldwide. Share your art and connect with the community!
          </p>
        </div>

        <SocialGallery />
      </div>
    </Layout>
  );
};

export default Gallery;