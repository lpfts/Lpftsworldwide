import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { QrCode, Gamepad2, Wallet, AlertCircle } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useWallet } from '@/hooks/useWallet';

const QREntry = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { isAuthenticated, signIn } = useAuth();
  const { isConnected, connectWallet } = useWallet();
  const [missionSlug, setMissionSlug] = useState<string | null>(null);
  const [step, setStep] = useState(1); // 1: Auth, 2: Wallet, 3: Redirect

  useEffect(() => {
    const slug = searchParams.get('slug');
    setMissionSlug(slug);

    if (!slug) {
      // No slug provided, redirect to missions
      navigate('/missions');
      return;
    }

    // Check authentication status and move to appropriate step
    if (isAuthenticated) {
      if (isConnected) {
        setStep(3); // Ready to redirect
        // Simulate mission lookup and redirect
        setTimeout(() => {
          navigate(`/missions`); // Would redirect to specific mission based on slug
        }, 2000);
      } else {
        setStep(2); // Need wallet connection
      }
    } else {
      setStep(1); // Need authentication
    }
  }, [searchParams, isAuthenticated, isConnected, navigate]);

  const handleAuth = () => {
    // In a real app, this would open a sign-in modal
    // For now, just redirect to a sign-in page (not created yet)
    alert('Authentication flow would open here. For demo, proceeding to next step.');
    setStep(2);
  };

  const handleWalletConnect = async () => {
    try {
      await connectWallet();
      setStep(3);
      // After wallet connection, redirect to mission
      setTimeout(() => {
        navigate(`/missions`);
      }, 1500);
    } catch (error) {
      console.error('Wallet connection failed:', error);
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-md mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 rounded-full bg-neon-blue/20 flex items-center justify-center mx-auto mb-4">
              <QrCode className="w-8 h-8 text-neon-blue" />
            </div>
            <h1 className="text-3xl font-bold neon-text mb-4">QR Mission Entry</h1>
            <p className="text-muted-foreground">
              {missionSlug ? (
                <>Preparing to start mission: <span className="text-neon-blue font-semibold">{missionSlug}</span></>
              ) : (
                'No mission code detected'
              )}
            </p>
          </div>

          {!missionSlug ? (
            <Alert className="border-destructive">
              <AlertCircle className="w-4 h-4" />
              <AlertDescription>
                Invalid QR code. Please scan a valid LPFTS mission QR code.
              </AlertDescription>
            </Alert>
          ) : (
            <div className="space-y-6">
              {/* Step 1: Authentication */}
              {step === 1 && (
                <Card className="graffiti-container border-neon-orange">
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 rounded-full bg-neon-orange/20 flex items-center justify-center mx-auto mb-3">
                      <span className="text-neon-orange font-bold">1</span>
                    </div>
                    <CardTitle>Sign In Required</CardTitle>
                    <CardDescription>
                      You need to be signed in to start missions
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      onClick={handleAuth}
                      className="w-full bg-neon-orange hover:bg-neon-orange/80 text-black font-semibold"
                    >
                      <Gamepad2 className="w-4 h-4 mr-2" />
                      Sign In to LPFTS
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* Step 2: Wallet Connection */}
              {step === 2 && (
                <Card className="graffiti-container border-neon-pink">
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 rounded-full bg-neon-pink/20 flex items-center justify-center mx-auto mb-3">
                      <span className="text-neon-pink font-bold">2</span>
                    </div>
                    <CardTitle>Connect Wallet</CardTitle>
                    <CardDescription>
                      Connect your wallet to participate in missions and earn rewards
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Button 
                      onClick={handleWalletConnect}
                      className="w-full bg-neon-pink hover:bg-neon-pink/80 text-black font-semibold"
                    >
                      <Wallet className="w-4 h-4 mr-2" />
                      Connect MetaMask
                    </Button>
                  </CardContent>
                </Card>
              )}

              {/* Step 3: Redirecting */}
              {step === 3 && (
                <Card className="graffiti-container border-neon-green">
                  <CardHeader className="text-center">
                    <div className="w-12 h-12 rounded-full bg-neon-green/20 flex items-center justify-center mx-auto mb-3 animate-pulse">
                      <span className="text-neon-green font-bold">✓</span>
                    </div>
                    <CardTitle>Ready to Start!</CardTitle>
                    <CardDescription>
                      Taking you to your mission...
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="text-center">
                    <div className="animate-pulse text-neon-green">
                      Loading mission details...
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Progress indicator */}
              <div className="flex justify-center space-x-2">
                {[1, 2, 3].map((i) => (
                  <div
                    key={i}
                    className={`w-3 h-3 rounded-full transition-colors ${
                      i <= step ? 'bg-neon-blue' : 'bg-muted'
                    }`}
                  />
                ))}
              </div>
            </div>
          )}

          <div className="mt-8 text-center">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-muted-foreground hover:text-neon-blue"
            >
              Return to Home
            </Button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default QREntry;