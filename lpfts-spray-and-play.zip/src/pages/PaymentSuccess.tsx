import React from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { CheckCircle, Package, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

const PaymentSuccess = () => {
  const navigate = useNavigate();

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="max-w-md mx-auto">
          <Card className="graffiti-container border-green-500 shadow-lg shadow-green-500/20">
            <CardHeader className="text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-green-500/20 flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-500" />
              </div>
              <CardTitle className="text-2xl text-green-500">Payment Successful!</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="space-y-2">
                <p className="text-lg font-semibold">Thank you for your purchase!</p>
                <p className="text-muted-foreground">
                  Your order has been confirmed and you'll receive an email confirmation shortly.
                </p>
              </div>

              <div className="bg-muted/20 rounded-lg p-4">
                <div className="flex items-center justify-center space-x-2 mb-2">
                  <Package className="w-5 h-5 text-turquoise-base" />
                  <span className="font-semibold">What's Next?</span>
                </div>
                <p className="text-sm text-muted-foreground">
                  For physical items, we'll process your order and send tracking information.
                  Digital items and NFTs will be available in your account soon.
                </p>
              </div>

              <div className="space-y-3">
                <Button 
                  className="w-full bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
                  onClick={() => navigate('/gallery')}
                >
                  <ArrowRight className="w-4 h-4 mr-2" />
                  Continue to Gallery
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => navigate('/market')}
                >
                  Back to Market
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default PaymentSuccess;