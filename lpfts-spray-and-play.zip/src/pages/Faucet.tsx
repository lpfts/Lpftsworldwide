import React, { useState } from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Zap, Coins, Clock, Gift, Wallet, TrendingUp } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { useFaucet } from '@/hooks/useFaucet';
import CryptoTradingPlatform from '@/components/CryptoTradingPlatform';

const Faucet = () => {
  const { toast } = useToast();
  const { isAuthenticated } = useAuth();
  const { claimFaucet, getTimeUntilNextClaim, canClaimNow } = useFaucet();
  const [canClaim, setCanClaim] = React.useState(false);

  React.useEffect(() => {
    const checkClaimStatus = async () => {
      const canClaimStatus = await canClaimNow();
      setCanClaim(canClaimStatus);
    };
    checkClaimStatus();
  }, [canClaimNow]);

  const handleClaim = async () => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication required",
        description: "Please sign in to claim tokens",
        variant: "destructive",
      });
      return;
    }

    try {
      const success = await claimFaucet();
      if (success) {
        toast({
          title: "Tokens claimed! 🎉",
          description: "100 SPRAY tokens have been added to your wallet",
        });
      }
    } catch (error) {
      toast({
        title: "Claim failed",
        description: "Please try again later",
        variant: "destructive",
      });
    }
  };

  const formatTimeRemaining = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold turquoise-text mb-4">LPFTS Crypto Hub</h1>
          <p className="text-muted-foreground text-lg">
            Complete crypto platform - Claim tokens, trade, stake, and earn rewards
          </p>
        </div>

        {/* Crypto Trading Platform */}
        <div className="mb-8">
          <CryptoTradingPlatform />
        </div>

        {/* Stats Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="graffiti-container border-turquoise-base/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Claimed</p>
                  <p className="text-2xl font-bold turquoise-text">2,450</p>
                  <p className="text-xs text-muted-foreground">SPRAY tokens</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-turquoise-base/20 flex items-center justify-center">
                  <Coins className="w-6 h-6 text-turquoise-base" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="graffiti-container border-turquoise-base/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Portfolio Value</p>
                  <p className="text-2xl font-bold turquoise-text">$4,567</p>
                  <p className="text-xs text-green-400">+12.4% today</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-orange-500/20 flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="graffiti-container border-turquoise-base/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Staking Rewards</p>
                  <p className="text-2xl font-bold turquoise-text">289.45</p>
                  <p className="text-xs text-muted-foreground">SPRAY earned</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-green-500/20 flex items-center justify-center">
                  <Wallet className="w-6 h-6 text-green-400" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="graffiti-container border-turquoise-base/50">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Trading Volume</p>
                  <p className="text-2xl font-bold turquoise-text">$12.8K</p>
                  <p className="text-xs text-muted-foreground">24h volume</p>
                </div>
                <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center">
                  <Clock className="w-6 h-6 text-blue-400" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Token Faucet Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <Card className="graffiti-container hover:shadow-turquoise transition-all duration-300">
            <CardHeader>
              <div className="w-16 h-16 rounded-full bg-turquoise-base/20 flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-turquoise-base" />
              </div>
              <CardTitle className="text-center text-2xl">Daily Faucet</CardTitle>
              <CardDescription className="text-center">
                Claim your daily SPRAY tokens to fuel your graffiti journey
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div className="text-4xl font-bold turquoise-text mb-2">100 SPRAY</div>
                <Badge className="bg-turquoise-base text-black">
                  <Gift className="w-3 h-3 mr-1" />
                  Daily Reward
                </Badge>
              </div>

              <Button 
                onClick={handleClaim}
                disabled={!canClaim}
                className="w-full bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold text-lg py-3"
              >
                {canClaim ? (
                  <>
                    <Zap className="w-5 h-5 mr-2" />
                    Claim 100 SPRAY
                  </>
                ) : (
                  <>
                    <Clock className="w-5 h-5 mr-2" />
                    Next claim in {formatTimeRemaining(getTimeUntilNextClaim())}
                  </>
                )}
              </Button>

              <div className="text-xs text-muted-foreground text-center space-y-1">
                <p>• Daily faucet provides 100 SPRAY tokens</p>
                <p>• 24-hour cooldown between claims</p>
                <p>• Connect wallet to claim rewards</p>
              </div>
            </CardContent>
          </Card>

          {/* Wallet Connect */}
          <Card className="graffiti-container hover:shadow-turquoise transition-all duration-300">
            <CardHeader>
              <div className="w-16 h-16 rounded-full bg-purple-500/20 flex items-center justify-center mx-auto mb-4">
                <Wallet className="w-8 h-8 text-purple-400" />
              </div>
              <CardTitle className="text-center text-2xl">Web3 Wallet</CardTitle>
              <CardDescription className="text-center">
                Connect your wallet to access all crypto features
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {!isAuthenticated ? (
                <Button className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold">
                  <Wallet className="w-4 h-4 mr-2" />
                  Connect Wallet
                </Button>
              ) : (
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <span className="text-sm">Status</span>
                    <Badge className="bg-green-500 text-white">Connected</Badge>
                  </div>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="text-center p-3 bg-muted/30 rounded-lg">
                      <div className="text-lg font-bold">2,450</div>
                      <div className="text-xs text-muted-foreground">SPRAY</div>
                    </div>
                    <div className="text-center p-3 bg-muted/30 rounded-lg">
                      <div className="text-lg font-bold">890</div>
                      <div className="text-xs text-muted-foreground">GRAFF</div>
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="graffiti-container hover:shadow-turquoise transition-all">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 rounded-lg bg-green-500/20 flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-6 h-6 text-green-400" />
              </div>
              <h3 className="font-semibold mb-2">Start Trading</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Swap tokens and trade on DEX platforms
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Open Trading
              </Button>
            </CardContent>
          </Card>

          <Card className="graffiti-container hover:shadow-turquoise transition-all">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 rounded-lg bg-blue-500/20 flex items-center justify-center mx-auto mb-4">
                <Coins className="w-6 h-6 text-blue-400" />
              </div>
              <h3 className="font-semibold mb-2">Stake & Earn</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Earn rewards by staking your tokens
              </p>
              <Button variant="outline" size="sm" className="w-full">
                View Pools
              </Button>
            </CardContent>
          </Card>

          <Card className="graffiti-container hover:shadow-turquoise transition-all">
            <CardContent className="p-6 text-center">
              <div className="w-12 h-12 rounded-lg bg-yellow-500/20 flex items-center justify-center mx-auto mb-4">
                <Gift className="w-6 h-6 text-yellow-400" />
              </div>
              <h3 className="font-semibold mb-2">Buy Crypto</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Purchase crypto with fiat currency
              </p>
              <Button variant="outline" size="sm" className="w-full">
                Buy Now
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Faucet;