import React from 'react';
import { Layout } from '@/components/Layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Palette, MapPin, Users, Zap } from 'lucide-react';

const Storyline = () => {
  return (
    <Layout>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-4xl font-bold neon-text mb-8 text-center">The LPFTS Storyline</h1>
          
          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text flex items-center">
                <Users className="w-6 h-6 mr-2" />
                The Origin Story
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>In the neon-lit streets of Australia's urban landscapes, a revolutionary movement was born. LPFTS (Legal Paint For The Streets) emerged from the underground graffiti scene, transforming illegal street art into a legitimate, blockchain-powered ecosystem.</p>
              <p className="text-muted-foreground">The year is 2024, and street artists across Brisbane, Melbourne, Perth, and Sydney have united under a common cause: to legitimize their craft while preserving the raw energy and authenticity of graffiti culture.</p>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text flex items-center">
                <MapPin className="w-6 h-6 mr-2" />
                The Legal Wall Revolution
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>What started as secret spots and hidden alleyways has evolved into a network of approved legal walls spanning the continent:</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="p-4 bg-muted/20 rounded-lg">
                  <Badge className="bg-turquoise-base text-black mb-2">Queensland</Badge>
                  <p className="text-sm">Southport Legal Wall becomes the epicenter of Gold Coast street art, while Brisbane's West End and Fortitude Valley walls showcase urban creativity.</p>
                </div>
                <div className="p-4 bg-muted/20 rounded-lg">
                  <Badge className="bg-turquoise-light text-black mb-2">Victoria</Badge>
                  <p className="text-sm">Melbourne's legendary Hosier Lane, AC/DC Lane, and Blender Lane transform into digital galleries where art meets blockchain.</p>
                </div>
                <div className="p-4 bg-muted/20 rounded-lg">
                  <Badge className="bg-turquoise-bright text-black mb-2">Western Australia</Badge>
                  <p className="text-sm">Perth's Northbridge walls become a canvas for the western frontier of street art innovation.</p>
                </div>
                <div className="p-4 bg-muted/20 rounded-lg">
                  <Badge className="bg-neon-blue text-black mb-2">Other States</Badge>
                  <p className="text-sm">Sydney, Adelaide, and Hobart join the movement, creating a nationwide network of legal expression.</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text flex items-center">
                <Palette className="w-6 h-6 mr-2" />
                The Mission System
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Every artist's journey begins with choosing their path:</p>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Badge className="bg-turquoise-base text-black">Beginner</Badge>
                  <span>6-color palettes for newcomers learning the basics of legal street art</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge className="bg-turquoise-light text-black">Intermediate</Badge>
                  <span>8-color challenges for developing artists expanding their skills</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Badge className="bg-turquoise-bright text-black">Advanced</Badge>
                  <span>20+ color masterpieces for veteran artists pushing creative boundaries</span>
                </div>
              </div>
              <p className="text-muted-foreground">Each mission tells a story, from cyberpunk dreams in the urban nightlife to ocean breezes on coastal walls. Artists don't just paint—they become part of an evolving narrative.</p>
            </CardContent>
          </Card>

          <Card className="graffiti-container mb-6">
            <CardHeader>
              <CardTitle className="turquoise-text flex items-center">
                <Zap className="w-6 h-6 mr-2" />
                The SPRAY Token Economy
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>In this new world, creativity has tangible value. The SPRAY token represents more than currency—it's a symbol of artistic achievement and community recognition.</p>
              <ul className="list-disc list-inside space-y-2 text-muted-foreground">
                <li>Complete missions to earn SPRAY tokens based on difficulty and quality</li>
                <li>Exceptional works are immortalized as NFTs on the blockchain</li>
                <li>Artists build reputations that unlock exclusive opportunities</li>
                <li>The community votes on outstanding pieces, rewarding innovation</li>
                <li>Legal walls become galleries where digital and physical art converge</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="graffiti-container">
            <CardHeader>
              <CardTitle className="turquoise-text">The Future Awaits</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>This is more than a platform—it's a movement. Every spray can shake, every color blend, every wall transformed contributes to a larger story of artistic evolution.</p>
              <p className="text-muted-foreground">Artists are no longer outlaws hiding in shadows. They are pioneers in a new frontier where street art meets Web3 technology, where legal walls become launchpads for global recognition, and where the spray can is mightier than the sword.</p>
              <p className="text-center font-bold turquoise-text mt-6">Welcome to LPFTS. Your story starts now.</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
};

export default Storyline;