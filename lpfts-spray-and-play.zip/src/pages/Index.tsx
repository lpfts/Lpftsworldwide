import React, { useState } from 'react';
import { Layout } from '@/components/Layout';
import { AgeGate } from '@/components/AgeGate';

import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Users, Zap, Trophy, Gamepad2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { DISCORD_INVITE } from '@/lib/config';
import { useAuth } from '@/hooks/useAuth';
import FeedComposer from '@/components/FeedComposer';
import CryptoTradingPlatform from '@/components/CryptoTradingPlatform';

const Index = () => {
  const navigate = useNavigate();
  const [showAgeGate, setShowAgeGate] = useState(() => localStorage.getItem('ageVerified') !== 'true');
  const { isAuthenticated } = useAuth();


  const handleAgeGateConfirm = () => {
    setShowAgeGate(false);
  };

  const feedPosts = [
    {
      id: 1,
      user: 'NeonArtist',
      content: 'Just dropped my latest piece on the MetroLine! Check it out 🎨',
      timestamp: '2 hours ago',
      likes: 42,
      image: null
    },
    {
      id: 2,
      user: 'GraffitiKing',
      content: 'Mission completed! Earned 150 SPRAY tokens for the underground tunnel piece ⚡',
      timestamp: '4 hours ago',
      likes: 28,
      image: null
    },
    {
      id: 3,
      user: 'StreetCanvas',
      content: 'New palette unlocked: Cyberpunk Dreams 💜✨',
      timestamp: '6 hours ago',
      likes: 67,
      image: null
    }
  ];

  return (
    <>
      {showAgeGate && <AgeGate onConfirm={handleAgeGateConfirm} />}
      <Layout>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
          
          
          {/* Hero Section */}
          <div className="text-center mb-12">
            <h1 className="text-5xl md:text-7xl font-bold mb-6">
              <span className="turquoise-text animate-turquoise-flicker">LPFTS</span>
              <br />
              <span className="text-3xl md:text-5xl text-turquoise-bright">WORLD WIDE</span>
            </h1>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
              The ultimate Web3 graffiti gaming experience. Create, compete, and collect in the digital streets.
            </p>
            
            {!isAuthenticated && (
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  size="lg" 
                  className="bg-gradient-turquoise hover:shadow-turquoise font-semibold text-lg px-8 py-3"
                  onClick={() => navigate('/auth')}
                >
                  <Gamepad2 className="w-5 h-5 mr-2" />
                  Start Gaming
                </Button>
                <Button 
                  variant="outline" 
                  size="lg" 
                  className="border-accent text-accent hover:bg-accent hover:text-accent-foreground text-lg px-8 py-3"
                  onClick={() => window.open('https://discord.gg/lpfts', '_blank')}
                >
                  <Users className="w-5 h-5 mr-2" />
                  Join Community
                </Button>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* CTA Cards */}
            <div className="lg:col-span-1 space-y-6">
              <Card className="graffiti-container border-turquoise-base hover:shadow-turquoise transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-turquoise-base/20 flex items-center justify-center mb-3">
                    <Zap className="w-6 h-6 text-turquoise-base" />
                  </div>
                  <CardTitle className="text-turquoise-base">Claim Faucet</CardTitle>
                  <CardDescription>Get your daily SPRAY tokens to start creating</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full"
                    onClick={() => navigate('/faucet')}
                  >
                    Claim 100 SPRAY
                  </Button>
                </CardContent>
              </Card>

              <Card className="graffiti-container border-turquoise-base hover:shadow-turquoise transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-turquoise-base/20 flex items-center justify-center mb-3">
                    <Users className="w-6 h-6 text-turquoise-base" />
                  </div>
                  <CardTitle className="text-turquoise-base">Join Discord</CardTitle>
                  <CardDescription>Connect with artists worldwide</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="outline" 
                    className="w-full border-accent text-accent hover:bg-accent hover:text-accent-foreground"
                    onClick={() => window.open('https://discord.gg/lpfts', '_blank')}
                  >
                    Join Community
                  </Button>
                </CardContent>
              </Card>

              <Card className="graffiti-container border-turquoise-base hover:shadow-turquoise transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 rounded-lg bg-turquoise-base/20 flex items-center justify-center mb-3">
                    <Trophy className="w-6 h-6 text-turquoise-base" />
                  </div>
                  <CardTitle className="text-turquoise-base">VIP Membership</CardTitle>
                  <CardDescription>Unlock exclusive features and premium benefits</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 text-black font-semibold hover:shadow-lg"
                    onClick={() => navigate('/market?category=vip')}
                  >
                    Join VIP
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Feed */}
            <div className="lg:col-span-2 space-y-6">
              {/* Crypto Trading Platform */}
              <Card className="graffiti-container">
                <CardHeader>
                  <CardTitle className="text-xl font-bold turquoise-text">LPFTS Trading Hub</CardTitle>
                  <CardDescription>Complete crypto platform with staking, trading & DeFi</CardDescription>
                </CardHeader>
                <CardContent>
                  <CryptoTradingPlatform />
                </CardContent>
              </Card>
              
              {/* Feed Composer */}
              <FeedComposer />
              
              <Card className="graffiti-container">
                <CardHeader>
                  <CardTitle className="text-xl font-bold">Community Feed</CardTitle>
                  <CardDescription>Latest creations from LPFTS artists worldwide</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {feedPosts.map((post) => (
                    <div key={post.id} className="glass-panel p-4 rounded-lg border border-border/10">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-full bg-gradient-turquoise"></div>
                          <div>
                            <p className="font-semibold text-sm">{post.user}</p>
                            <p className="text-xs text-muted-foreground">{post.timestamp}</p>
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-foreground mb-3">{post.content}</p>
                      <div className="flex items-center space-x-4 text-xs text-muted-foreground">
                        <button className="hover:text-turquoise-bright transition-colors">
                          ♥ {post.likes}
                        </button>
                        <button className="hover:text-turquoise-bright transition-colors">
                          Comment
                        </button>
                        <button className="hover:text-turquoise-bright transition-colors">
                          Share
                        </button>
                      </div>
                    </div>
                  ))}
                  
                  <div className="text-center py-4">
                    <Button variant="ghost" className="text-turquoise-base hover:text-turquoise-bright">
                      Load More Posts
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};

export default Index;
