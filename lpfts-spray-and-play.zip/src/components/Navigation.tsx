import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Menu, Wallet, User, LogOut, X } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useWallet } from '@/hooks/useWallet';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export const Navigation = () => {
  const navigate = useNavigate();
  const { isAuthenticated, user, signOut } = useAuth();
  const { isConnected, connectWallet, disconnectWallet, address } = useWallet();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/missions', label: 'Missions' },
    { to: '/gallery', label: 'Gallery' },
    { to: '/faucet', label: 'Faucet' },
    { to: '/leaderboard', label: 'Leaderboard' },
    { to: '/market', label: 'Market' },
    { to: '/merch', label: 'Merch' },
    { to: '/storyline', label: 'Storyline' },
    { to: '/privacy', label: 'Privacy' },
    { to: '/terms', label: 'Terms' },
  ];

  return (
    <nav className="sticky top-0 z-50 w-full glass-panel border-b border-border/20">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link to="/" className="text-2xl font-bold neon-text animate-neon-flicker hover:opacity-80 transition-opacity">
              LPFTS
            </Link>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="text-foreground">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side="left" className="w-64 bg-background/95 backdrop-blur-sm">
                <div className="flex flex-col space-y-4 mt-8">
                  {navLinks.map((link) => (
                    <Button
                      key={link.to}
                      variant="ghost"
                      className="justify-start text-foreground hover:text-turquoise-base hover:bg-muted/20"
                      asChild
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      <Link to={link.to}>{link.label}</Link>
                    </Button>
                  ))}
                </div>
              </SheetContent>
            </Sheet>
          </div>

          {/* Desktop Navigation Links */}
          <div className="hidden md:block">
            <div className="ml-10 flex items-baseline space-x-4">
              {navLinks.map((link) => (
                <Button
                  key={link.to}
                  variant="ghost"
                  className="text-foreground hover:text-neon-blue hover:bg-muted/20"
                  asChild
                >
                  <Link to={link.to}>{link.label}</Link>
                </Button>
              ))}
            </div>
          </div>

          {/* Right Side Actions */}
          <div className="flex items-center space-x-4">
            {/* MetaMask Connect Button */}
            <Button 
              variant="outline" 
              size="sm" 
              className="turquoise-glow border-turquoise-base text-turquoise-base hover:bg-turquoise-base hover:text-black"
              onClick={isConnected ? disconnectWallet : connectWallet}
            >
              <Wallet className="w-4 h-4 mr-2" />
              {isConnected ? `${address?.slice(0, 6)}...${address?.slice(-4)}` : 'Connect MetaMask'}
            </Button>

            {/* Authentication & Wallet */}
            {!isAuthenticated ? (
              <Button 
                variant="default" 
                className="bg-gradient-turquoise hover:shadow-turquoise font-semibold"
                onClick={() => navigate('/auth')}
              >
                <User className="w-4 h-4 mr-2" />
                Sign In
              </Button>
            ) : (
              <div className="flex items-center space-x-2">
                {/* User Menu */}
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={signOut}
                  className="text-muted-foreground hover:text-turquoise-base"
                >
                  <LogOut className="w-4 h-4" />
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};