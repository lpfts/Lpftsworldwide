import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Upload, Zap, Star, Trophy, Image } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';

interface MintingInterfaceProps {
  onClose: () => void;
}

const MintingInterface = ({ onClose }: MintingInterfaceProps) => {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    rarity: 'Common',
    sprayRequired: 100,
    image: null as File | null
  });

  const rarityOptions = [
    { name: 'Common', cost: 100, color: 'bg-gray-500' },
    { name: 'Uncommon', cost: 250, color: 'bg-green-500' },
    { name: 'Rare', cost: 500, color: 'bg-blue-500' },
    { name: 'Epic', cost: 1000, color: 'bg-purple-500' },
    { name: 'Legendary', cost: 2500, color: 'bg-orange-500' },
    { name: 'Mythic', cost: 5000, color: 'bg-red-500' }
  ];

  const handleRarityChange = (rarity: string) => {
    const selected = rarityOptions.find(r => r.name === rarity);
    setFormData(prev => ({
      ...prev,
      rarity,
      sprayRequired: selected?.cost || 100
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFormData(prev => ({ ...prev, image: file }));
    }
  };

  const handleMint = async () => {
    if (!isAuthenticated) {
      toast({
        title: "Authentication required",
        description: "Please sign in to mint NFTs",
        variant: "destructive"
      });
      return;
    }

    if (!formData.title || !formData.description || !formData.image) {
      toast({
        title: "Missing information",
        description: "Please fill in all fields and upload an image",
        variant: "destructive"
      });
      return;
    }

    // Simulate minting process
    toast({
      title: "Minting in progress...",
      description: "Your NFT is being created on the blockchain",
    });

    setTimeout(() => {
      toast({
        title: "🎉 NFT Minted Successfully!",
        description: `Your ${formData.rarity} NFT "${formData.title}" has been minted for ${formData.sprayRequired} SPRAY tokens`,
      });
      onClose();
    }, 3000);
  };

  return (
    <Card className="graffiti-container">
      <CardHeader>
        <CardTitle className="turquoise-text text-center flex items-center justify-center">
          <Star className="w-6 h-6 mr-2" />
          Mint Your Mission NFT
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="p-4 rounded-lg bg-gradient-to-r from-turquoise-base/10 to-turquoise-bright/10 border border-turquoise-base/20">
          <h4 className="font-semibold text-turquoise-base mb-2">How Minting Works</h4>
          <ul className="text-sm text-muted-foreground space-y-1">
            <li>• Upload your graffiti artwork or mission submission</li>
            <li>• Choose rarity level (affects SPRAY cost)</li>
            <li>• Pay SPRAY tokens to mint as NFT</li>
            <li>• NFT becomes tradeable on marketplace</li>
          </ul>
        </div>

        <div className="space-y-4">
          <div>
            <Label htmlFor="title">NFT Title</Label>
            <Input 
              id="title"
              placeholder="Enter your NFT title..."
              value={formData.title}
              onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea 
              id="description"
              placeholder="Describe your artwork, mission, or creation story..."
              value={formData.description}
              onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="image">Upload Artwork</Label>
            <div className="mt-2">
              <label htmlFor="image" className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-turquoise-base/50 rounded-lg cursor-pointer hover:border-turquoise-base transition-colors">
                <div className="flex flex-col items-center justify-center pt-5 pb-6">
                  <Image className="w-8 h-8 mb-2 text-turquoise-base" />
                  <p className="text-sm text-muted-foreground">
                    {formData.image ? formData.image.name : "Click to upload image"}
                  </p>
                </div>
                <input id="image" type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
              </label>
            </div>
          </div>

          <div>
            <Label>Rarity Level</Label>
            <div className="grid grid-cols-2 gap-2 mt-2">
              {rarityOptions.map((rarity) => (
                <Button
                  key={rarity.name}
                  variant={formData.rarity === rarity.name ? "default" : "outline"}
                  onClick={() => handleRarityChange(rarity.name)}
                  className={`justify-between ${formData.rarity === rarity.name ? 'bg-turquoise-base text-black' : ''}`}
                >
                  <span>{rarity.name}</span>
                  <Badge variant="secondary">{rarity.cost} SPRAY</Badge>
                </Button>
              ))}
            </div>
          </div>

          <div className="p-4 rounded-lg bg-gradient-dark/50 border border-border/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Zap className="w-5 h-5 text-turquoise-base" />
                <span className="font-semibold">Total Cost:</span>
              </div>
              <Badge className="bg-turquoise-base text-black text-lg px-3 py-1">
                {formData.sprayRequired} SPRAY
              </Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Minting cost varies by rarity. Higher rarity = more valuable NFT
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <Button 
            variant="outline" 
            onClick={onClose}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button 
            onClick={handleMint}
            className="flex-1 bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
            disabled={!formData.title || !formData.description || !formData.image}
          >
            <Trophy className="w-4 h-4 mr-2" />
            Mint NFT
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default MintingInterface;