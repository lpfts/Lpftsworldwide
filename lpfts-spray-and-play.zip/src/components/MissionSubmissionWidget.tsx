import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Upload, 
  Camera, 
  MapPin, 
  Palette, 
  Zap, 
  Trophy,
  CheckCircle,
  AlertCircle,
  Coins
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

interface MissionSubmissionWidgetProps {
  mission?: {
    id: string;
    title: string;
    difficulty: string;
    requirements: string[];
    rewards: {
      spray: number;
      paint: number;
      reputation: number;
    };
  };
  isOpen?: boolean;
  onClose?: () => void;
}

const MissionSubmissionWidget = ({ mission, isOpen = true, onClose }: MissionSubmissionWidgetProps) => {
  const [submissionData, setSubmissionData] = useState({
    title: '',
    description: '',
    location: '',
    colors: [] as string[],
    imageFile: null as File | null,
    imagePreview: null as string | null
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();

  // Default mission if none provided
  const defaultMission = {
    id: 'daily-challenge',
    title: 'Daily Street Challenge',
    difficulty: 'Medium',
    requirements: ['Use 7+ colors', 'Street legal wall', 'Include signature'],
    rewards: {
      spray: 100,
      paint: 25,
      reputation: 50
    }
  };

  const currentMission = mission || defaultMission;

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({
          title: "File too large",
          description: "Please select an image under 5MB",
          variant: "destructive",
        });
        return;
      }

      setSubmissionData(prev => ({ ...prev, imageFile: file }));
      
      const reader = new FileReader();
      reader.onload = (e) => {
        setSubmissionData(prev => ({ 
          ...prev, 
          imagePreview: e.target?.result as string 
        }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCameraCapture = () => {
    // Trigger camera input
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.capture = 'environment';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        handleImageUpload({ target: { files: [file] } } as any);
      }
    };
    input.click();
  };

  const addColor = (color: string) => {
    if (!submissionData.colors.includes(color) && submissionData.colors.length < 20) {
      setSubmissionData(prev => ({
        ...prev,
        colors: [...prev.colors, color]
      }));
    }
  };

  const removeColor = (color: string) => {
    setSubmissionData(prev => ({
      ...prev,
      colors: prev.colors.filter(c => c !== color)
    }));
  };

  const handleSubmit = async () => {
    if (!isAuthenticated) {
      toast({
        title: "Sign in required",
        description: "Please sign in to submit missions",
        variant: "destructive",
      });
      return;
    }

    if (!submissionData.title || !submissionData.imageFile) {
      toast({
        title: "Missing required fields",
        description: "Please provide a title and upload an image",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);
    setUploadProgress(0);

    try {
      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setUploadProgress(prev => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      // Upload image to Supabase storage
      const fileExt = submissionData.imageFile.name.split('.').pop();
      const fileName = `${user?.id}_${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('art_collective')
        .upload(fileName, submissionData.imageFile);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('art_collective')
        .getPublicUrl(fileName);

      // Submit mission data
      const { error: insertError } = await supabase
        .from('mission_submissions')
        .insert({
          user_id: user?.id,
          mission_title: currentMission.title,
          difficulty: currentMission.difficulty,
          palette: submissionData.colors,
          legal_wall_location: submissionData.location || null,
          status: 'submitted'
        });

      if (insertError) throw insertError;

      // Create post for community
      const { error: postError } = await supabase
        .from('posts')
        .insert({
          user_id: user?.id,
          author: user?.id,
          title: `Mission: ${submissionData.title}`,
          body: submissionData.description || `Completed mission: ${currentMission.title}`,
          image_url: urlData.publicUrl,
          author_handle: user?.user_metadata?.handle || 'Unknown'
        });

      if (postError) throw postError;

      setUploadProgress(100);
      
      toast({
        title: "Mission submitted! 🎉",
        description: `Earned ${currentMission.rewards.spray} SPRAY tokens and ${currentMission.rewards.reputation} reputation`,
      });

      // Reset form
      setSubmissionData({
        title: '',
        description: '',
        location: '',
        colors: [],
        imageFile: null,
        imagePreview: null
      });

      if (onClose) onClose();

    } catch (error: any) {
      toast({
        title: "Submission failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
      setUploadProgress(0);
    }
  };

  if (!isOpen) return null;

  return (
    <Card className="w-full max-w-2xl mx-auto graffiti-container">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              <span>Submit Mission</span>
            </CardTitle>
            <CardDescription>
              Upload your artwork and earn SPRAY tokens
            </CardDescription>
          </div>
          {onClose && (
            <Button variant="ghost" onClick={onClose}>×</Button>
          )}
        </div>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Mission Info */}
        <div className="p-4 bg-gradient-dark rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-turquoise-bright">{currentMission.title}</h3>
            <Badge variant={currentMission.difficulty === 'Easy' ? 'secondary' : 
                           currentMission.difficulty === 'Medium' ? 'default' : 'destructive'}>
              {currentMission.difficulty}
            </Badge>
          </div>
          
          <div className="space-y-2 mb-4">
            <h4 className="text-sm font-medium">Requirements:</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {currentMission.requirements.map((req, index) => (
                <li key={index} className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <span>{req}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex items-center space-x-4 text-sm">
            <div className="flex items-center space-x-1">
              <Zap className="w-4 h-4 text-turquoise-base" />
              <span>{currentMission.rewards.spray} SPRAY</span>
            </div>
            <div className="flex items-center space-x-1">
              <Palette className="w-4 h-4 text-pink-500" />
              <span>{currentMission.rewards.paint} PAINT</span>
            </div>
            <div className="flex items-center space-x-1">
              <Trophy className="w-4 h-4 text-yellow-500" />
              <span>+{currentMission.rewards.reputation} Rep</span>
            </div>
          </div>
        </div>

        {/* Submission Form */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="title">Artwork Title *</Label>
            <Input
              id="title"
              placeholder="Give your piece a name..."
              value={submissionData.title}
              onChange={(e) => setSubmissionData(prev => ({ ...prev, title: e.target.value }))}
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              placeholder="Describe your artwork, inspiration, or technique..."
              value={submissionData.description}
              onChange={(e) => setSubmissionData(prev => ({ ...prev, description: e.target.value }))}
            />
          </div>

          <div>
            <Label htmlFor="location">Legal Wall Location</Label>
            <Input
              id="location"
              placeholder="Where did you create this piece?"
              value={submissionData.location}
              onChange={(e) => setSubmissionData(prev => ({ ...prev, location: e.target.value }))}
            />
          </div>

          {/* Color Palette */}
          <div>
            <Label>Colors Used ({submissionData.colors.length}/20)</Label>
            <div className="flex flex-wrap gap-2 mt-2">
              {['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#000000', '#FFFFFF'].map(color => (
                <button
                  key={color}
                  type="button"
                  onClick={() => addColor(color)}
                  className="w-8 h-8 rounded-full border-2 border-gray-300 hover:border-turquoise-base transition-colors"
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            <div className="flex flex-wrap gap-1 mt-2">
              {submissionData.colors.map(color => (
                <Badge
                  key={color}
                  variant="outline"
                  className="cursor-pointer hover:bg-destructive"
                  onClick={() => removeColor(color)}
                >
                  <div 
                    className="w-3 h-3 rounded-full mr-1" 
                    style={{ backgroundColor: color }}
                  />
                  ×
                </Badge>
              ))}
            </div>
          </div>

          {/* Image Upload */}
          <div>
            <Label>Artwork Image *</Label>
            <div className="mt-2">
              {submissionData.imagePreview ? (
                <div className="space-y-3">
                  <img
                    src={submissionData.imagePreview}
                    alt="Preview"
                    className="w-full max-h-64 object-cover rounded-lg"
                  />
                  <div className="flex space-x-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setSubmissionData(prev => ({ 
                        ...prev, 
                        imageFile: null, 
                        imagePreview: null 
                      }))}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => document.getElementById('file-upload')?.click()}
                    className="h-24 flex-col"
                  >
                    <Upload className="w-6 h-6 mb-2" />
                    Upload Photo
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handleCameraCapture}
                    className="h-24 flex-col"
                  >
                    <Camera className="w-6 h-6 mb-2" />
                    Take Photo
                  </Button>
                </div>
              )}
            </div>
            <input
              id="file-upload"
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
          </div>

          {/* Upload Progress */}
          {isSubmitting && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span>Uploading submission...</span>
                <span>{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="w-full" />
            </div>
          )}

          {/* Submit Button */}
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting || !submissionData.title || !submissionData.imageFile}
            className="w-full bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
          >
            {isSubmitting ? (
              <>
                <Upload className="w-4 h-4 mr-2 animate-spin" />
                Submitting...
              </>
            ) : (
              <>
                <Trophy className="w-4 h-4 mr-2" />
                Submit Mission
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default MissionSubmissionWidget;