import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Heart, MessageCircle, Share, MoreHorizontal, Camera, User } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import CommentBox from '@/components/CommentBox';
import FeedComposer from '@/components/FeedComposer';

interface Post {
  id: number;
  user_id: string;
  title: string;
  body: string;
  image_url?: string;
  created_at: string;
  author_handle: string;
  user?: {
    handle: string;
    display_name: string;
    avatar_url?: string;
    missions_completed?: number;
    tokens_collected?: number;
  };
}

interface SocialGalleryProps {
  showComposer?: boolean;
}

export const SocialGallery: React.FC<SocialGalleryProps> = ({ showComposer = true }) => {
  const { isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [posts, setPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPost, setSelectedPost] = useState<number | null>(null);
  const [comments, setComments] = useState<Record<number, any[]>>({});

  const fetchPosts = async () => {
    try {
      const { data, error } = await supabase
        .from('posts')
        .select(`
          id,
          user_id,
          title,
          body,
          image_url,
          created_at,
          author_handle
        `)
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;

      // Fetch user profiles for each post
      const userIds = [...new Set(data?.map(post => post.user_id).filter(Boolean))];
      
      if (userIds.length > 0) {
        const { data: profiles, error: profileError } = await supabase
          .from('profiles')
          .select('id, handle, display_name, avatar_url, missions_completed, tokens_collected')
          .in('id', userIds);

        if (!profileError && profiles) {
          const profileMap = profiles.reduce((acc, profile) => {
            acc[profile.id] = profile;
            return acc;
          }, {} as Record<string, any>);

          const postsWithProfiles = data?.map(post => ({
            ...post,
            user: profileMap[post.user_id] || {
              handle: post.author_handle || 'anonymous',
              display_name: post.author_handle || 'Anonymous'
            }
          })) || [];

          setPosts(postsWithProfiles);
        } else {
          setPosts(data || []);
        }
      } else {
        setPosts(data || []);
      }
    } catch (error: any) {
      toast({
        title: "Failed to load posts",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchComments = async (postId: number) => {
    try {
      const { data, error } = await supabase
        .from('post_comments')
        .select(`
          id,
          user_id,
          content,
          image_url,
          created_at
        `)
        .eq('post_id', postId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Fetch user profiles for comments
      const userIds = [...new Set(data?.map(comment => comment.user_id).filter(Boolean))];
      
      if (userIds.length > 0) {
        const { data: profiles, error: profileError } = await supabase
          .from('profiles')
          .select('id, handle, display_name, avatar_url')
          .in('id', userIds);

        if (!profileError && profiles) {
          const profileMap = profiles.reduce((acc, profile) => {
            acc[profile.id] = profile;
            return acc;
          }, {} as Record<string, any>);

          const commentsWithProfiles = data?.map(comment => ({
            ...comment,
            user: profileMap[comment.user_id] || {
              handle: 'anonymous',
              display_name: 'Anonymous'
            }
          })) || [];

          setComments(prev => ({
            ...prev,
            [postId]: commentsWithProfiles
          }));
        }
      }
    } catch (error: any) {
      console.error('Failed to load comments:', error);
    }
  };

  useEffect(() => {
    fetchPosts();
  }, []);

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  const handleShowComments = (postId: number) => {
    if (selectedPost === postId) {
      setSelectedPost(null);
    } else {
      setSelectedPost(postId);
      if (!comments[postId]) {
        fetchComments(postId);
      }
    }
  };

  const handleCommentAdded = (postId: number) => {
    fetchComments(postId);
  };

  const handlePostCreated = () => {
    fetchPosts();
  };

  const handleProfileClick = (userId: string) => {
    // Navigate to user profile - implement routing later
    toast({
      title: "Profile View",
      description: "Profile viewing coming soon!",
    });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="graffiti-container animate-pulse">
            <CardContent className="p-6">
              <div className="flex space-x-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-muted"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded w-1/4"></div>
                  <div className="h-3 bg-muted rounded w-1/6"></div>
                </div>
              </div>
              <div className="space-y-2">
                <div className="h-4 bg-muted rounded w-3/4"></div>
                <div className="h-20 bg-muted rounded"></div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Feed Composer */}
      {showComposer && (
        <FeedComposer onPostCreated={handlePostCreated} />
      )}

      {/* Posts Feed */}
      <div className="space-y-6">
        {posts.map((post) => (
          <Card key={post.id} className="graffiti-container hover:shadow-turquoise transition-all duration-300">
            <CardContent className="p-6">
              {/* Post Header */}
              <div className="flex items-center space-x-3 mb-4">
                <button 
                  onClick={() => handleProfileClick(post.user_id)}
                  className="flex items-center space-x-3 hover:opacity-80 transition-opacity"
                >
                  <Avatar className="w-10 h-10">
                    <AvatarFallback className="bg-gradient-turquoise text-black">
                      {post.user?.handle?.[0]?.toUpperCase() || 'A'}
                    </AvatarFallback>
                  </Avatar>
                  <div className="text-left">
                    <div className="flex items-center space-x-2">
                      <p className="font-semibold text-turquoise-bright">
                        {post.user?.display_name || post.author_handle}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        @{post.user?.handle || post.author_handle}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                      <span>{formatTimeAgo(post.created_at)}</span>
                      {post.user?.missions_completed && (
                        <Badge variant="outline" className="text-xs">
                          {post.user.missions_completed} missions
                        </Badge>
                      )}
                    </div>
                  </div>
                </button>
                <div className="flex-1"></div>
                <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </div>

              {/* Post Content */}
              <div className="space-y-3">
                {post.title && post.title !== post.body && (
                  <h3 className="font-semibold text-lg">{post.title}</h3>
                )}
                {post.body && (
                  <p className="text-foreground whitespace-pre-wrap">{post.body}</p>
                )}
                {post.image_url && (
                  <div className="rounded-lg overflow-hidden">
                    <img 
                      src={post.image_url} 
                      alt="Post image" 
                      className="w-full h-auto max-h-96 object-cover"
                    />
                  </div>
                )}
              </div>

              {/* Post Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-border/20 mt-4">
                <div className="flex items-center space-x-6">
                  <button className="flex items-center space-x-1 text-muted-foreground hover:text-red-500 transition-colors">
                    <Heart className="w-5 h-5" />
                    <span className="text-sm">Like</span>
                  </button>
                  <button 
                    onClick={() => handleShowComments(post.id)}
                    className="flex items-center space-x-1 text-muted-foreground hover:text-turquoise-bright transition-colors"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span className="text-sm">Comment</span>
                  </button>
                  <button className="flex items-center space-x-1 text-muted-foreground hover:text-blue-500 transition-colors">
                    <Share className="w-5 h-5" />
                    <span className="text-sm">Share</span>
                  </button>
                </div>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => handleProfileClick(post.user_id)}
                  className="text-turquoise-base hover:text-turquoise-bright"
                >
                  <User className="w-4 h-4 mr-1" />
                  View Profile
                </Button>
              </div>

              {/* Comments Section */}
              {selectedPost === post.id && (
                <div className="mt-6 pt-4 border-t border-border/20">
                  <CommentBox 
                    postId={post.id}
                    comments={comments[post.id] || []}
                    onCommentAdded={() => handleCommentAdded(post.id)}
                  />
                </div>
              )}
            </CardContent>
          </Card>
        ))}

        {posts.length === 0 && (
          <Card className="graffiti-container">
            <CardContent className="p-12 text-center">
              <Camera className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-xl font-bold mb-2">No posts yet</h3>
              <p className="text-muted-foreground mb-6">
                Be the first to share your art with the community!
              </p>
              {isAuthenticated && showComposer && (
                <p className="text-sm text-muted-foreground">
                  Use the composer above to create your first post.
                </p>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};

export default SocialGallery;