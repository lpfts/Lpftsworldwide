import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  TrendingUp, 
  TrendingDown, 
  ArrowUpDown, 
  Wallet, 
  CreditCard, 
  DollarSign,
  Coins,
  Target,
  Zap,
  Lock,
  Unlock,
  ExternalLink,
  RefreshCw
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface TokenData {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume: number;
  supply: number;
  marketCap: number;
  apy?: number;
  stakingRewards?: number;
}

interface StakingPool {
  id: string;
  name: string;
  token: string;
  apy: number;
  totalStaked: number;
  userStaked: number;
  lockPeriod: string;
  rewards: number;
}

const CryptoTradingPlatform = () => {
  const { toast } = useToast();
  const [tokens, setTokens] = useState<TokenData[]>([
    { 
      symbol: 'SPRAY', 
      name: 'LPFTS Spray', 
      price: 0.125, 
      change24h: 15.2, 
      volume: 1250000, 
      supply: 10000000,
      marketCap: 1250000,
      apy: 45.5,
      stakingRewards: 125
    },
    { 
      symbol: 'GRAFF', 
      name: 'LPFTS Graff', 
      price: 0.85, 
      change24h: -3.1, 
      volume: 890000, 
      supply: 5000000,
      marketCap: 4250000,
      apy: 32.8,
      stakingRewards: 67
    },
    { 
      symbol: 'PAINT', 
      name: 'LPFTS Paint', 
      price: 2.45, 
      change24h: 8.7, 
      volume: 2100000, 
      supply: 2000000,
      marketCap: 4900000,
      apy: 28.9,
      stakingRewards: 89
    },
    { 
      symbol: 'ETH', 
      name: 'Ethereum', 
      price: 3245.67, 
      change24h: 2.4, 
      volume: 12450000000, 
      supply: 120280000,
      marketCap: 390240000000,
      apy: 4.2,
      stakingRewards: 0.156
    },
    { 
      symbol: 'BTC', 
      name: 'Bitcoin', 
      price: 67890.12, 
      change24h: 1.8, 
      volume: 23450000000, 
      supply: 19750000,
      marketCap: 1340000000000,
      apy: 0,
      stakingRewards: 0
    }
  ]);

  const [stakingPools] = useState<StakingPool[]>([
    {
      id: 'spray-pool',
      name: 'SPRAY Staking Pool',
      token: 'SPRAY',
      apy: 45.5,
      totalStaked: 5200000,
      userStaked: 1250,
      lockPeriod: '30 days',
      rewards: 125.67
    },
    {
      id: 'graff-pool',
      name: 'GRAFF Rewards Pool',
      token: 'GRAFF',
      apy: 32.8,
      totalStaked: 2100000,
      userStaked: 890,
      lockPeriod: '90 days',
      rewards: 67.34
    },
    {
      id: 'paint-pool',
      name: 'PAINT Liquidity Pool',
      token: 'PAINT',
      apy: 28.9,
      totalStaked: 890000,
      userStaked: 345,
      lockPeriod: '60 days',
      rewards: 89.12
    },
    {
      id: 'eth-pool',
      name: 'ETH 2.0 Staking',
      token: 'ETH',
      apy: 4.2,
      totalStaked: 28500000,
      userStaked: 5.67,
      lockPeriod: 'Flexible',
      rewards: 0.156
    }
  ]);

  const [swapFrom, setSwapFrom] = useState('ETH');
  const [swapTo, setSwapTo] = useState('SPRAY');
  const [swapAmount, setSwapAmount] = useState('');
  const [buyAmount, setBuyAmount] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  const refreshPrices = async () => {
    setRefreshing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    setTokens(prev => prev.map(token => ({
      ...token,
      price: token.price * (1 + (Math.random() - 0.5) * 0.1),
      change24h: (Math.random() - 0.5) * 20,
      volume: token.volume * (1 + (Math.random() - 0.5) * 0.2)
    })));
    
    setRefreshing(false);
    toast({
      title: "Prices Updated",
      description: "Live market data refreshed successfully"
    });
  };

  const formatPrice = (price: number) => {
    if (price < 1) return `$${price.toFixed(4)}`;
    if (price < 100) return `$${price.toFixed(2)}`;
    return `$${price.toLocaleString()}`;
  };

  const formatVolume = (volume: number) => {
    if (volume > 1000000000) return `$${(volume / 1000000000).toFixed(2)}B`;
    if (volume > 1000000) return `$${(volume / 1000000).toFixed(2)}M`;
    if (volume > 1000) return `$${(volume / 1000).toFixed(2)}K`;
    return `$${volume.toFixed(2)}`;
  };

  const handleSwap = () => {
    if (!swapAmount) {
      toast({
        title: "Invalid Amount",
        description: "Please enter an amount to swap",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Swap Initiated via Uniswap",
      description: `Swapping ${swapAmount} ${swapFrom} for ${swapTo}`,
    });
  };

  const handleBuyCrypto = () => {
    if (!buyAmount) {
      toast({
        title: "Invalid Amount",
        description: "Please enter an amount to buy",
        variant: "destructive"
      });
      return;
    }

    toast({
      title: "Buy Order Placed",
      description: `Purchasing $${buyAmount} worth of crypto via on-ramp`,
    });
  };

  const handleStake = (poolId: string, amount: string) => {
    const pool = stakingPools.find(p => p.id === poolId);
    if (!pool) return;

    toast({
      title: "Staking Successful",
      description: `Staked ${amount} ${pool.token} at ${pool.apy}% APY`,
    });
  };

  const handleUnstake = (poolId: string) => {
    const pool = stakingPools.find(p => p.id === poolId);
    if (!pool) return;

    toast({
      title: "Unstaking Initiated",
      description: `Unstaking ${pool.userStaked} ${pool.token} with rewards`,
    });
  };

  return (
    <div className="w-full space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold turquoise-text">LPFTS Trading Platform</h2>
          <p className="text-muted-foreground">Complete crypto trading, staking & DeFi platform</p>
        </div>
        <Button 
          onClick={refreshPrices}
          variant="outline"
          disabled={refreshing}
          className="border-turquoise-base/50 text-turquoise-base hover:bg-turquoise-base/10"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Updating...' : 'Refresh Prices'}
        </Button>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trading">Trading</TabsTrigger>
          <TabsTrigger value="staking">Staking</TabsTrigger>
          <TabsTrigger value="onramp">Buy/Sell</TabsTrigger>
          <TabsTrigger value="defi">DeFi</TabsTrigger>
        </TabsList>

        {/* Market Overview */}
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {tokens.map((token) => (
              <Card key={token.symbol} className="graffiti-container hover:shadow-turquoise transition-all">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 rounded-full bg-turquoise-base/20 flex items-center justify-center">
                        <span className="text-xs font-bold">{token.symbol.slice(0, 2)}</span>
                      </div>
                      <div>
                        <CardTitle className="text-sm">{token.symbol}</CardTitle>
                        <CardDescription className="text-xs">{token.name}</CardDescription>
                      </div>
                    </div>
                    <Badge className={token.change24h > 0 ? 'bg-green-500' : 'bg-red-500'}>
                      {token.change24h > 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                      {token.change24h.toFixed(1)}%
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Price</span>
                      <span className="font-bold">{formatPrice(token.price)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Volume</span>
                      <span className="text-sm">{formatVolume(token.volume)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-muted-foreground">Market Cap</span>
                      <span className="text-sm">{formatVolume(token.marketCap)}</span>
                    </div>
                    {token.apy && token.apy > 0 && (
                      <div className="flex justify-between">
                        <span className="text-sm text-muted-foreground">Staking APY</span>
                        <span className="text-sm font-semibold text-green-400">{token.apy}%</span>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Trading */}
        <TabsContent value="trading" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Uniswap Integration */}
            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <ArrowUpDown className="w-5 h-5 mr-2 text-turquoise-base" />
                  Uniswap DEX
                </CardTitle>
                <CardDescription>Decentralized token swapping via Uniswap V3</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium">From</label>
                    <div className="flex space-x-2">
                      <Select value={swapFrom} onValueChange={setSwapFrom}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {tokens.map(token => (
                            <SelectItem key={token.symbol} value={token.symbol}>
                              {token.symbol}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input 
                        placeholder="0.0"
                        value={swapAmount}
                        onChange={(e) => setSwapAmount(e.target.value)}
                        type="number"
                      />
                    </div>
                  </div>
                  
                  <div className="flex justify-center">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => {
                        setSwapFrom(swapTo);
                        setSwapTo(swapFrom);
                      }}
                    >
                      <ArrowUpDown className="w-4 h-4" />
                    </Button>
                  </div>

                  <div>
                    <label className="text-sm font-medium">To</label>
                    <div className="flex space-x-2">
                      <Select value={swapTo} onValueChange={setSwapTo}>
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {tokens.map(token => (
                            <SelectItem key={token.symbol} value={token.symbol}>
                              {token.symbol}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <Input 
                        placeholder="0.0"
                        readOnly
                        value={swapAmount ? (parseFloat(swapAmount) * 1.2).toFixed(4) : ''}
                      />
                    </div>
                  </div>
                </div>

                <Button 
                  className="w-full bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
                  onClick={handleSwap}
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Swap via Uniswap
                </Button>
              </CardContent>
            </Card>

            {/* Quick Trade */}
            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Zap className="w-5 h-5 mr-2 text-yellow-400" />
                  Quick Trade
                </CardTitle>
                <CardDescription>Instant buy/sell LPFTS tokens</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  {tokens.slice(0, 3).map(token => (
                    <Button
                      key={token.symbol}
                      variant="outline"
                      className="flex flex-col p-4 h-auto"
                      onClick={() => toast({
                        title: "Quick Trade",
                        description: `Trading ${token.symbol} at ${formatPrice(token.price)}`
                      })}
                    >
                      <span className="font-semibold">{token.symbol}</span>
                      <span className="text-xs text-muted-foreground">{formatPrice(token.price)}</span>
                      <Badge className={`text-xs ${token.change24h > 0 ? 'bg-green-500' : 'bg-red-500'}`}>
                        {token.change24h.toFixed(1)}%
                      </Badge>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Staking */}
        <TabsContent value="staking" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {stakingPools.map((pool) => (
              <Card key={pool.id} className="graffiti-container">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center">
                      <Target className="w-5 h-5 mr-2 text-turquoise-base" />
                      {pool.name}
                    </CardTitle>
                    <Badge className="bg-green-500 text-white font-bold">
                      {pool.apy}% APY
                    </Badge>
                  </div>
                  <CardDescription>
                    Lock period: {pool.lockPeriod} • Total staked: {pool.totalStaked.toLocaleString()} {pool.token}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Your Stake:</span>
                      <span className="font-semibold">{pool.userStaked} {pool.token}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Pending Rewards:</span>
                      <span className="font-semibold text-green-400">{pool.rewards} {pool.token}</span>
                    </div>
                    <Progress value={(pool.userStaked / pool.totalStaked) * 100} className="h-2" />
                  </div>

                  <div className="flex space-x-2">
                    <div className="flex-1">
                      <Input 
                        placeholder={`Amount in ${pool.token}`}
                        type="number"
                      />
                    </div>
                    <Button 
                      variant="outline"
                      onClick={() => handleStake(pool.id, '100')}
                    >
                      <Lock className="w-4 h-4 mr-1" />
                      Stake
                    </Button>
                  </div>

                  {pool.userStaked > 0 && (
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => handleUnstake(pool.id)}
                    >
                      <Unlock className="w-4 h-4 mr-2" />
                      Unstake & Claim Rewards
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* On/Off Ramp */}
        <TabsContent value="onramp" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Buy Crypto */}
            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <CreditCard className="w-5 h-5 mr-2 text-green-400" />
                  Buy Crypto
                </CardTitle>
                <CardDescription>Purchase crypto with fiat currency</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium">Amount (USD)</label>
                    <Input 
                      placeholder="100.00"
                      value={buyAmount}
                      onChange={(e) => setBuyAmount(e.target.value)}
                      type="number"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Buy</label>
                    <Select defaultValue="SPRAY">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {tokens.slice(0, 3).map(token => (
                          <SelectItem key={token.symbol} value={token.symbol}>
                            {token.name} ({token.symbol})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Payment Method</label>
                    <Select defaultValue="card">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="card">Credit/Debit Card</SelectItem>
                        <SelectItem value="bank">Bank Transfer</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="apple">Apple Pay</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button 
                  className="w-full bg-green-500 hover:bg-green-600 text-white font-semibold"
                  onClick={handleBuyCrypto}
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  Buy Crypto
                </Button>
              </CardContent>
            </Card>

            {/* Sell Crypto */}
            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="w-5 h-5 mr-2 text-red-400" />
                  Sell Crypto
                </CardTitle>
                <CardDescription>Convert crypto to fiat currency</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <label className="text-sm font-medium">Sell</label>
                    <Select defaultValue="SPRAY">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {tokens.slice(0, 3).map(token => (
                          <SelectItem key={token.symbol} value={token.symbol}>
                            {token.name} ({token.symbol})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Amount</label>
                    <Input 
                      placeholder="0.0"
                      type="number"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Withdraw To</label>
                    <Select defaultValue="bank">
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="bank">Bank Account</SelectItem>
                        <SelectItem value="paypal">PayPal</SelectItem>
                        <SelectItem value="card">Debit Card</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button 
                  variant="outline"
                  className="w-full border-red-400 text-red-400 hover:bg-red-400 hover:text-white font-semibold"
                  onClick={() => toast({
                    title: "Sell Order Placed",
                    description: "Your crypto will be converted to fiat"
                  })}
                >
                  <DollarSign className="w-4 h-4 mr-2" />
                  Sell Crypto
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* DeFi */}
        <TabsContent value="defi" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="text-lg">Liquidity Pools</CardTitle>
                <CardDescription>Provide liquidity and earn fees</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">SPRAY/ETH</span>
                    <span className="text-sm font-semibold text-green-400">24.5% APY</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">GRAFF/USDC</span>
                    <span className="text-sm font-semibold text-green-400">18.2% APY</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">PAINT/BTC</span>
                    <span className="text-sm font-semibold text-green-400">15.8% APY</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Coins className="w-4 h-4 mr-2" />
                  Add Liquidity
                </Button>
              </CardContent>
            </Card>

            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="text-lg">Yield Farming</CardTitle>
                <CardDescription>Stake LP tokens for additional rewards</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">SPRAY-ETH LP</span>
                    <span className="text-sm font-semibold text-yellow-400">67% APY</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Total Rewards</span>
                    <span className="text-sm">15,678 SPRAY</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Target className="w-4 h-4 mr-2" />
                  Start Farming
                </Button>
              </CardContent>
            </Card>

            <Card className="graffiti-container">
              <CardHeader>
                <CardTitle className="text-lg">NFT Collateral</CardTitle>
                <CardDescription>Borrow against your NFTs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm">Available to Borrow</span>
                    <span className="text-sm">2,340 SPRAY</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm">Interest Rate</span>
                    <span className="text-sm">8.5% APR</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Wallet className="w-4 h-4 mr-2" />
                  Borrow
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default CryptoTradingPlatform;