import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, RefreshCw, Zap, Coins, Star } from 'lucide-react';

interface TokenData {
  symbol: string;
  name: string;
  price: number;
  change24h: number;
  volume: number;
  supply: number;
}

const CryptoWidget = () => {
  const [tokens, setTokens] = useState<TokenData[]>([
    { symbol: 'SPRAY', name: 'LPFTS Spray', price: 0.125, change24h: 15.2, volume: 1250000, supply: 10000000 },
    { symbol: 'PAINT', name: 'LPFTS Paint', price: 0.85, change24h: -3.1, volume: 850000, supply: 5000000 },
    { symbol: 'GRAFF', name: 'LPFTS Graff', price: 2.45, change24h: 8.7, volume: 2100000, supply: 2000000 },
    { symbol: 'TAG', name: 'LPFTS Tag', price: 12.50, change24h: 22.1, volume: 750000, supply: 500000 }
  ]);

  const [refreshing, setRefreshing] = useState(false);

  const refreshPrices = async () => {
    setRefreshing(true);
    // Simulate price updates
    setTimeout(() => {
      setTokens(prev => prev.map(token => ({
        ...token,
        price: token.price * (0.95 + Math.random() * 0.1),
        change24h: (Math.random() - 0.5) * 40
      })));
      setRefreshing(false);
    }, 1000);
  };

  const formatPrice = (price: number) => `$${price.toFixed(4)}`;
  const formatVolume = (volume: number) => `$${(volume / 1000000).toFixed(2)}M`;
  const formatSupply = (supply: number) => `${(supply / 1000000).toFixed(1)}M`;

  return (
    <Card className="graffiti-container">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="turquoise-text">LPFTS Token Stats</CardTitle>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={refreshPrices}
            disabled={refreshing}
            className="border-turquoise-base/50"
          >
            <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="trading">Trading</TabsTrigger>
            <TabsTrigger value="staking">Staking</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {tokens.map((token) => (
              <div key={token.symbol} className="flex items-center justify-between p-3 rounded-lg bg-gradient-dark/50 border border-turquoise-base/20">
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-gradient-turquoise flex items-center justify-center">
                    {token.symbol === 'SPRAY' ? <Zap className="w-4 h-4 text-black" /> :
                     token.symbol === 'PAINT' ? <div className="w-4 h-4 rounded-full bg-pink-500" /> :
                     token.symbol === 'GRAFF' ? <Star className="w-4 h-4 text-black" /> :
                     <Coins className="w-4 h-4 text-black" />}
                  </div>
                  <div>
                    <div className="font-semibold">{token.symbol}</div>
                    <div className="text-xs text-muted-foreground">{token.name}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold">{formatPrice(token.price)}</div>
                  <div className={`text-xs flex items-center ${token.change24h >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {token.change24h >= 0 ? <TrendingUp className="w-3 h-3 mr-1" /> : <TrendingDown className="w-3 h-3 mr-1" />}
                    {Math.abs(token.change24h).toFixed(1)}%
                  </div>
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="trading" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Button className="bg-green-600 hover:bg-green-700">
                Buy Tokens
              </Button>
              <Button variant="outline" className="border-red-500 text-red-500 hover:bg-red-500/10">
                Sell Tokens
              </Button>
            </div>
            <div className="space-y-2">
              <h4 className="font-semibold">Quick Swap</h4>
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" size="sm">SPRAY → PAINT</Button>
                <Button variant="outline" size="sm">PAINT → GRAFF</Button>
                <Button variant="outline" size="sm">GRAFF → TAG</Button>
                <Button variant="outline" size="sm">TAG → SPRAY</Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="staking" className="space-y-4">
            <div className="p-4 rounded-lg bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/20">
              <h4 className="font-semibold text-purple-400 mb-2">Stake Your Tokens</h4>
              <p className="text-sm text-muted-foreground mb-3">Earn rewards by staking your LPFTS tokens</p>
              <div className="grid grid-cols-2 gap-2">
                {tokens.map((token) => (
                  <Button key={token.symbol} variant="outline" size="sm" className="border-purple-500/50">
                    Stake {token.symbol}
                  </Button>
                ))}
              </div>
            </div>
            <div className="space-y-2">
              <h5 className="font-semibold">Current APY Rates</h5>
              {tokens.map((token) => (
                <div key={token.symbol} className="flex justify-between text-sm">
                  <span>{token.symbol}</span>
                  <Badge variant="outline" className="border-green-500/50 text-green-400">
                    {(Math.random() * 20 + 5).toFixed(1)}% APY
                  </Badge>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default CryptoWidget;