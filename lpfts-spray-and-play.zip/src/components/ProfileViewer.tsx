import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { 
  User, 
  Trophy, 
  Coins, 
  Zap, 
  Settings, 
  MoreVertical,
  MapPin,
  Calendar,
  Palette,
  Star
} from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { getSafeProfileData } from '@/hooks/useSecureProfiles';

interface ProfileViewerProps {
  profile: any;
  isOwnProfile?: boolean;
  onEdit?: () => void;
  onFollow?: () => void;
  onMessage?: () => void;
}

const ProfileViewer = ({ profile, isOwnProfile = false, onEdit, onFollow, onMessage }: ProfileViewerProps) => {
  const [activeTab, setActiveTab] = useState('overview');
  const safeProfile = getSafeProfileData(profile);

  if (!safeProfile) {
    return (
      <Card className="w-full max-w-4xl mx-auto">
        <CardContent className="flex items-center justify-center py-12">
          <div className="text-center">
            <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground">Profile not found</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  // Mock data for demo - would come from actual profile data
  const profileStats = {
    followers: 1247,
    following: 89,
    posts: 156,
    nftsOwned: 23,
    achievements: 12
  };

  const recentAchievements = [
    { name: 'First Burner', description: 'Completed your first mission', date: '2024-01-15' },
    { name: 'Color Master', description: 'Used 15+ colors in a single piece', date: '2024-01-12' },
    { name: 'Community Favorite', description: 'Received 100+ likes on a post', date: '2024-01-10' }
  ];

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Profile Header */}
      <Card className="graffiti-container">
        <CardContent className="p-0">
          {/* Cover Photo */}
          <div className="h-48 bg-gradient-dark rounded-t-lg relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-br from-turquoise-base/20 to-purple-500/20" />
            <div className="absolute top-4 right-4">
              {isOwnProfile ? (
                <Button variant="outline" size="sm" onClick={onEdit}>
                  <Settings className="w-4 h-4 mr-2" />
                  Edit Profile
                </Button>
              ) : (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="outline" size="sm">
                      <MoreVertical className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    <DropdownMenuItem onClick={onFollow}>
                      Follow
                    </DropdownMenuItem>
                    <DropdownMenuItem onClick={onMessage}>
                      Message
                    </DropdownMenuItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem>
                      Report
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              )}
            </div>
          </div>

          {/* Profile Info */}
          <div className="px-6 pb-6">
            <div className="flex items-start space-x-4 -mt-16 relative z-10">
              <Avatar className="w-24 h-24 border-4 border-background">
                <AvatarImage src={safeProfile.avatarUrl || ''} />
                <AvatarFallback className="text-2xl bg-turquoise-base text-black">
                  {safeProfile.displayName?.charAt(0) || safeProfile.handle?.charAt(0) || 'U'}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 pt-4">
                <div className="flex items-center space-x-2 mb-2">
                  <h1 className="text-2xl font-bold">{safeProfile.displayName}</h1>
                  <Badge variant="secondary">@{safeProfile.handle}</Badge>
                </div>
                
                <p className="text-muted-foreground mb-4">
                  Digital street artist | LPFTS Wolf | Minting the future
                </p>

                <div className="flex items-center space-x-6 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-1">
                    <MapPin className="w-4 h-4" />
                    <span>Gold Coast, Australia</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>Joined {new Date(safeProfile.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
              <div className="text-center">
                <div className="text-2xl font-bold turquoise-text">{profileStats.posts}</div>
                <div className="text-sm text-muted-foreground">Posts</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold turquoise-text">{profileStats.followers}</div>
                <div className="text-sm text-muted-foreground">Followers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold turquoise-text">{profileStats.following}</div>
                <div className="text-sm text-muted-foreground">Following</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold turquoise-text">{safeProfile.missionsCompleted}</div>
                <div className="text-sm text-muted-foreground">Missions</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold turquoise-text">{safeProfile.tokensCollected}</div>
                <div className="text-sm text-muted-foreground">SPRAY</div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Profile Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid grid-cols-4 w-full">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="artworks">Artworks</TabsTrigger>
          <TabsTrigger value="nfts">NFTs</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Zap className="w-5 h-5 text-turquoise-base" />
                  <span>Recent Activity</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-turquoise-base rounded-full" />
                    <span className="text-sm">Completed "Neon Dreams" mission</span>
                    <span className="text-xs text-muted-foreground ml-auto">2h</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-pink-500 rounded-full" />
                    <span className="text-sm">Minted new NFT artwork</span>
                    <span className="text-xs text-muted-foreground ml-auto">1d</span>
                  </div>
                  <div className="flex items-center space-x-3">
                    <div className="w-2 h-2 bg-green-500 rounded-full" />
                    <span className="text-sm">Earned 150 SPRAY tokens</span>
                    <span className="text-xs text-muted-foreground ml-auto">3d</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Token Balance */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Coins className="w-5 h-5 text-yellow-500" />
                  <span>Token Balance</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Zap className="w-4 h-4 text-turquoise-base" />
                      <span>SPRAY</span>
                    </div>
                    <span className="font-bold">{safeProfile.tokensCollected}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Palette className="w-4 h-4 text-pink-500" />
                      <span>PAINT</span>
                    </div>
                    <span className="font-bold">847</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="artworks">
          <Card>
            <CardHeader>
              <CardTitle>Artwork Gallery</CardTitle>
              <CardDescription>Latest graffiti pieces and submissions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="aspect-square bg-gradient-dark rounded-lg p-4 flex items-center justify-center">
                    <div className="text-center">
                      <Palette className="w-8 h-8 mx-auto text-turquoise-base mb-2" />
                      <p className="text-sm text-muted-foreground">Artwork #{i}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="nfts">
          <Card>
            <CardHeader>
              <CardTitle>NFT Collection</CardTitle>
              <CardDescription>Owned NFTs and collectibles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="aspect-square bg-gradient-dark rounded-lg p-4 flex flex-col items-center justify-center">
                    <div className="text-4xl mb-2">🎨</div>
                    <p className="text-xs text-center">NFT #{i.toString().padStart(3, '0')}</p>
                    <Badge variant="outline" className="mt-1">Epic</Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="w-5 h-5 text-yellow-500" />
                <span>Achievements</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentAchievements.map((achievement, index) => (
                  <div key={index} className="flex items-center space-x-4 p-3 rounded-lg bg-muted/50">
                    <Star className="w-8 h-8 text-yellow-500" />
                    <div className="flex-1">
                      <h4 className="font-semibold">{achievement.name}</h4>
                      <p className="text-sm text-muted-foreground">{achievement.description}</p>
                    </div>
                    <span className="text-xs text-muted-foreground">
                      {new Date(achievement.date).toLocaleDateString()}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ProfileViewer;