import React from 'react';
import { Button } from '@/components/ui/button';

export const Footer = () => {
  return (
    <footer className="glass-panel border-t border-border/20 mt-auto">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Logo & Brand */}
          <div className="md:col-span-1">
            <div className="text-xl font-bold neon-text mb-4">LPFTS</div>
            <p className="text-muted-foreground text-sm">
              The ultimate Web3 graffiti gaming experience.
            </p>
          </div>

          {/* Quick Links */}
          <div className="md:col-span-1">
            <h3 className="text-sm font-semibold text-foreground mb-4">Game</h3>
            <div className="space-y-2">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-blue p-0 h-auto">
                Missions
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-blue p-0 h-auto">
                Faucet
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-blue p-0 h-auto">
                Leaderboard
              </Button>
            </div>
          </div>

          {/* Community */}
          <div className="md:col-span-1">
            <h3 className="text-sm font-semibold text-foreground mb-4">Community</h3>
            <div className="space-y-2">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-pink p-0 h-auto">
                Discord
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-pink p-0 h-auto">
                Gallery
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-pink p-0 h-auto">
                Market
              </Button>
            </div>
          </div>

          {/* Legal */}
          <div className="md:col-span-1">
            <h3 className="text-sm font-semibold text-foreground mb-4">Legal</h3>
            <div className="space-y-2">
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-green p-0 h-auto">
                Privacy Policy
              </Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-neon-green p-0 h-auto">
                Terms of Service
              </Button>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-border/20 pt-6 mt-8">
          <p className="text-center text-sm text-muted-foreground">
            © 2025 LPFTS World Wide™. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};