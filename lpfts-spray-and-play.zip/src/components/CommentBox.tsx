import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { Camera, Upload, X, Send, Heart, MoreHorizontal } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { validateContent, sanitizeInput } from '@/lib/validation';

interface Comment {
  id: string;
  user_id: string;
  content: string;
  image_url?: string;
  created_at: string;
  user?: {
    handle: string;
    display_name: string;
    avatar_url?: string;
  };
}

interface CommentBoxProps {
  postId: number;
  comments: Comment[];
  onCommentAdded?: () => void;
}

export const CommentBox: React.FC<CommentBoxProps> = ({ postId, comments, onCommentAdded }) => {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [newComment, setNewComment] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isPosting, setIsPosting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (file: File) => {
    if (file.size > 10 * 1024 * 1024) { // 10MB limit for comments
      toast({
        title: "File too large",
        description: "Please select a file smaller than 10MB",
        variant: "destructive",
      });
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `comments/${user!.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('feed-media')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('feed-media')
        .getPublicUrl(fileName);

      return data.publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      return null;
    }
  };

  const handleSubmitComment = async () => {
    if (!newComment.trim() && !selectedFile) {
      toast({
        title: "Empty comment",
        description: "Please add some content or an image",
        variant: "destructive",
      });
      return;
    }

    if (newComment.trim()) {
      const validation = validateContent(newComment);
      if (!validation.isValid) {
        toast({
          title: "Content not allowed",
          description: validation.errors[0],
          variant: "destructive",
        });
        return;
      }
    }

    setIsPosting(true);
    try {
      let imageUrl = null;
      
      if (selectedFile) {
        imageUrl = await uploadFile(selectedFile);
        if (!imageUrl) {
          throw new Error('Failed to upload image');
        }
      }

      const sanitizedContent = sanitizeInput(newComment);

      const { error } = await supabase
        .from('post_comments')
        .insert({
          post_id: postId,
          user_id: user!.id,
          content: sanitizedContent,
          image_url: imageUrl
        });

      if (error) throw error;

      toast({
        title: "Comment added!",
        description: "Your comment has been posted",
      });

      setNewComment('');
      removeFile();
      onCommentAdded?.();

    } catch (error: any) {
      toast({
        title: "Failed to post comment",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsPosting(false);
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <div className="space-y-4">
      {/* Comments List */}
      <div className="space-y-3">
        {comments.map((comment) => (
          <Card key={comment.id} className="graffiti-container bg-card/50">
            <CardContent className="p-4">
              <div className="flex space-x-3">
                <Avatar className="w-8 h-8">
                  <AvatarFallback className="bg-gradient-turquoise text-black text-xs">
                    {comment.user?.handle?.[0]?.toUpperCase() || 'A'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 space-y-2">
                  <div className="flex items-center space-x-2">
                    <span className="font-semibold text-sm text-turquoise-bright">
                      {comment.user?.handle || 'Anonymous'}
                    </span>
                    <span className="text-xs text-muted-foreground">
                      {formatTimeAgo(comment.created_at)}
                    </span>
                  </div>
                  {comment.content && (
                    <p className="text-sm text-foreground">{comment.content}</p>
                  )}
                  {comment.image_url && (
                    <img 
                      src={comment.image_url} 
                      alt="Comment image" 
                      className="max-w-full h-auto rounded-lg max-h-48 object-cover"
                    />
                  )}
                  <div className="flex items-center space-x-3 text-xs text-muted-foreground">
                    <button className="flex items-center space-x-1 hover:text-turquoise-bright transition-colors">
                      <Heart className="w-3 h-3" />
                      <span>Like</span>
                    </button>
                    <button className="hover:text-turquoise-bright transition-colors">
                      Reply
                    </button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Comment Input */}
      {isAuthenticated ? (
        <Card className="graffiti-container">
          <CardContent className="p-4 space-y-3">
            <div className="flex space-x-3">
              <Avatar className="w-8 h-8">
                <AvatarFallback className="bg-gradient-turquoise text-black text-xs">
                  {user?.email?.[0]?.toUpperCase() || 'U'}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 space-y-3">
                <Textarea
                  placeholder="Add a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(sanitizeInput(e.target.value))}
                  className="min-h-[60px] resize-none"
                  maxLength={500}
                />
                
                {previewUrl && (
                  <div className="relative inline-block">
                    <img 
                      src={previewUrl} 
                      alt="Preview" 
                      className="max-w-full h-auto rounded-lg max-h-32 object-cover"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute top-1 right-1 w-6 h-6 p-0"
                      onClick={removeFile}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                )}

                <div className="flex items-center justify-between">
                  <div className="flex space-x-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => cameraInputRef.current?.click()}
                      className="text-turquoise-base hover:text-turquoise-bright"
                    >
                      <Camera className="w-4 h-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => fileInputRef.current?.click()}
                      className="text-turquoise-base hover:text-turquoise-bright"
                    >
                      <Upload className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-muted-foreground">
                      {newComment.length}/500
                    </span>
                    <Button 
                      size="sm"
                      className="bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
                      onClick={handleSubmitComment}
                      disabled={isPosting || (!newComment.trim() && !selectedFile)}
                    >
                      <Send className="w-3 h-3 mr-1" />
                      {isPosting ? 'Posting...' : 'Post'}
                    </Button>
                  </div>
                </div>
              </div>
            </div>

            {/* Hidden file inputs */}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileInputChange}
              className="hidden"
            />
            <input
              ref={cameraInputRef}
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleFileInputChange}
              className="hidden"
            />
          </CardContent>
        </Card>
      ) : (
        <Card className="graffiti-container">
          <CardContent className="p-4 text-center">
            <p className="text-muted-foreground text-sm">
              Sign in to join the conversation
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default CommentBox;