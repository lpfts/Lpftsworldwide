import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Camera, Upload, X, Send, Image as ImageIcon, Shield } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { validateContent, sanitizeInput, RateLimiter } from '@/lib/validation';

interface FeedComposerProps {
  onPostCreated?: () => void;
}

const FeedComposer: React.FC<FeedComposerProps> = ({ onPostCreated }) => {
  const { isAuthenticated, user } = useAuth();
  const { toast } = useToast();
  const [content, setContent] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isPosting, setIsPosting] = useState(false);
  const [showPreview, setShowPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  if (!isAuthenticated) {
    return (
      <Card className="graffiti-container">
        <CardContent className="p-6 text-center">
          <p className="text-muted-foreground">
            Sign in to share your artwork with the community
          </p>
        </CardContent>
      </Card>
    );
  }

  const handleFileSelect = (file: File) => {
    if (file.size > 20 * 1024 * 1024) { // 20MB limit
      toast({
        title: "File too large",
        description: "Please select a file smaller than 20MB",
        variant: "destructive",
      });
      return;
    }

    if (!file.type.startsWith('image/')) {
      toast({
        title: "Invalid file type",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);
  };

  const handleFileInputChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const removeFile = () => {
    setSelectedFile(null);
    if (previewUrl) {
      URL.revokeObjectURL(previewUrl);
      setPreviewUrl(null);
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
    if (cameraInputRef.current) cameraInputRef.current.value = '';
  };

  const uploadFile = async (file: File): Promise<string | null> => {
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${user!.id}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('feed-media')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('feed-media')
        .getPublicUrl(fileName);

      return data.publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      return null;
    }
  };

  const handlePost = async () => {
    if (!content.trim() && !selectedFile) {
      toast({
        title: "Empty post",
        description: "Please add some content or an image",
        variant: "destructive",
      });
      return;
    }

    // Rate limiting check
    const rateLimiter = RateLimiter.getInstance();
    if (!rateLimiter.isAllowed('post_creation', 3, 300000)) { // 3 posts per 5 minutes
      const remainingTime = Math.ceil(rateLimiter.getRemainingTime('post_creation', 300000) / 1000 / 60);
      toast({
        title: "Rate limit exceeded",
        description: `Please wait ${remainingTime} minutes before posting again`,
        variant: "destructive",
      });
      return;
    }

    // Content validation
    if (content.trim()) {
      const validation = validateContent(content);
      if (!validation.isValid) {
        toast({
          title: "Content not allowed",
          description: validation.errors[0],
          variant: "destructive",
        });
        return;
      }
    }

    setIsPosting(true);
    try {
      let imageUrl = null;
      
      if (selectedFile) {
        imageUrl = await uploadFile(selectedFile);
        if (!imageUrl) {
          throw new Error('Failed to upload image');
        }
      }

      // Sanitize content before saving
      const sanitizedContent = sanitizeInput(content);

      const { error } = await supabase
        .from('posts')
        .insert({
          user_id: user!.id,
          author: user!.id,
          title: sanitizedContent.slice(0, 100) || 'Community Post',
          body: sanitizedContent,
          image_url: imageUrl,
          author_handle: user!.email?.split('@')[0] || 'Anonymous'
        });

      if (error) throw error;

      toast({
        title: "Post shared!",
        description: "Your post has been shared with the community",
      });

      // Reset form
      setContent('');
      removeFile();
      setShowPreview(false);
      onPostCreated?.();

    } catch (error: any) {
      toast({
        title: "Failed to post",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    } finally {
      setIsPosting(false);
    }
  };

  const handlePreview = () => {
    if (!content.trim() && !selectedFile) {
      toast({
        title: "Nothing to preview",
        description: "Add some content or an image first",
        variant: "destructive",
      });
      return;
    }
    setShowPreview(true);
  };

  if (showPreview) {
    return (
      <Card className="graffiti-container">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="turquoise-text">Preview Post</CardTitle>
            <div className="flex space-x-2">
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowPreview(false)}
              >
                Edit
              </Button>
              <Button 
                size="sm"
                className="bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
                onClick={handlePost}
                disabled={isPosting}
              >
                <Send className="w-4 h-4 mr-2" />
                {isPosting ? 'Posting...' : 'Post'}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="glass-panel p-4 rounded-lg border border-border/10">
            <div className="flex items-center space-x-3 mb-3">
              <div className="w-8 h-8 rounded-full bg-gradient-turquoise"></div>
              <div>
                <p className="font-semibold text-sm">{user?.email?.split('@')[0] || 'You'}</p>
                <p className="text-xs text-muted-foreground">Just now</p>
              </div>
            </div>
            {content && (
              <p className="text-sm text-foreground mb-3">{content}</p>
            )}
            {previewUrl && (
              <div className="mb-3">
                <img 
                  src={previewUrl} 
                  alt="Preview" 
                  className="max-w-full h-auto rounded-lg max-h-64 object-cover"
                />
              </div>
            )}
            <div className="flex items-center space-x-4 text-xs text-muted-foreground">
              <button className="hover:text-turquoise-bright transition-colors">
                ♥ 0
              </button>
              <button className="hover:text-turquoise-bright transition-colors">
                Comment
              </button>
              <button className="hover:text-turquoise-bright transition-colors">
                Share
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="graffiti-container">
      <CardHeader>
        <CardTitle className="turquoise-text flex items-center">
          <ImageIcon className="w-5 h-5 mr-2" />
          Share Your Art
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Textarea
          placeholder="Share your latest creation, mission progress, or thoughts with the community..."
          value={content}
          onChange={(e) => {
            const sanitized = sanitizeInput(e.target.value);
            setContent(sanitized);
          }}
          className="min-h-[100px] resize-none"
          maxLength={1000}
        />
        
        {content.length > 800 && (
          <div className="flex items-center gap-2 text-amber-600 text-sm">
            <Shield className="w-4 h-4" />
            Content approaching limit
          </div>
        )}

        {previewUrl && (
          <div className="relative">
            <img 
              src={previewUrl} 
              alt="Selected" 
              className="max-w-full h-auto rounded-lg max-h-64 object-cover"
            />
            <Button
              variant="destructive"
              size="sm"
              className="absolute top-2 right-2"
              onClick={removeFile}
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        )}

        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => cameraInputRef.current?.click()}
              className="border-turquoise-base text-turquoise-base hover:bg-turquoise-base hover:text-black"
            >
              <Camera className="w-4 h-4 mr-2" />
              Camera
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="border-turquoise-base text-turquoise-base hover:bg-turquoise-base hover:text-black"
            >
              <Upload className="w-4 h-4 mr-2" />
              Upload
            </Button>
          </div>
          
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={handlePreview}
              disabled={!content.trim() && !selectedFile}
            >
              Preview
            </Button>
            <Button 
              size="sm"
              className="bg-gradient-turquoise hover:shadow-turquoise text-black font-semibold"
              onClick={handlePost}
              disabled={isPosting || (!content.trim() && !selectedFile)}
            >
              <Send className="w-4 h-4 mr-2" />
              {isPosting ? 'Posting...' : 'Post'}
            </Button>
          </div>
        </div>

        <div className="text-xs text-muted-foreground">
          {content.length}/1000 characters
          {selectedFile && (
            <Badge variant="outline" className="ml-2">
              Image: {selectedFile.name}
            </Badge>
          )}
        </div>

        {/* Hidden file inputs */}
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileInputChange}
          className="hidden"
        />
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleFileInputChange}
          className="hidden"
        />
      </CardContent>
    </Card>
  );
};

export default FeedComposer;