import React from 'react';
import { AlertCircle } from 'lucide-react';

export const TestModeBanner = () => {
  return (
    <div className="bg-neon-orange/20 border-l-4 border-neon-orange p-4 mb-6">
      <div className="flex items-center">
        <AlertCircle className="w-5 h-5 text-neon-orange mr-3" />
        <div>
          <p className="text-sm font-medium text-neon-orange">
            Test Mode Active
          </p>
          <p className="text-sm text-neon-orange/80">
            You're running in mock mode. All transactions and data are simulated for testing purposes.
          </p>
        </div>
      </div>
    </div>
  );
};