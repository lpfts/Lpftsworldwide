import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle } from 'lucide-react';

interface AgeGateProps {
  onConfirm: () => void;
}

export const AgeGate: React.FC<AgeGateProps> = ({ onConfirm }) => {
  const [isVisible, setIsVisible] = useState(true);

  const handleConfirm = () => {
    localStorage.setItem('ageVerified', 'true');
    setIsVisible(false);
    onConfirm();
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-background/80 backdrop-blur-md">
      <Card className="graffiti-container max-w-md mx-4 shadow-dark border-turquoise-base">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 w-12 h-12 rounded-full bg-turquoise-base/20 flex items-center justify-center">
            <AlertTriangle className="w-6 h-6 text-turquoise-base" />
          </div>
          <CardTitle className="text-2xl font-bold turquoise-text">Age Verification</CardTitle>
          <CardDescription className="text-muted-foreground">
            You must be 18+ to enter LPFTS World Wide
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center text-sm text-muted-foreground">
            <p>This platform contains mature content and requires users to be at least 18 years old.</p>
            <p className="mt-2">By entering, you confirm that you meet this age requirement.</p>
          </div>
          <div className="flex space-x-3">
            <Button 
              variant="destructive"
              className="flex-1"
              onClick={() => { localStorage.removeItem('ageVerified'); window.location.href = 'https://google.com'; }}
            >
              Under 18
            </Button>
            <Button 
              variant="default"
              className="flex-1 bg-gradient-turquoise hover:shadow-turquoise font-semibold"
              onClick={handleConfirm}
            >
              I'm 18+
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};