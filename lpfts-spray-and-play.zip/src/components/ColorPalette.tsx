import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Palette, Sparkles } from 'lucide-react';

interface ColorPaletteProps {
  difficulty: 'Beginner' | 'Intermediate' | 'Advanced';
  onSelectPalette?: (palette: any) => void;
}

const ColorPalette: React.FC<ColorPaletteProps> = ({ difficulty, onSelectPalette }) => {
  const palettes = {
    Beginner: [
      {
        name: 'Ocean Breeze',
        colors: ['#00CED1', '#20B2AA', '#4682B4', '#87CEEB', '#B0E0E6', '#E0F6FF'],
        theme: 'Cool aquatic tones perfect for beginners'
      },
      {
        name: 'Sunset Glow',
        colors: ['#FF6B35', '#F7931E', '#FFD23F', '#EE4B2B', '#FF69B4', '#FFA07A'],
        theme: 'Warm sunset hues for vibrant pieces'
      }
    ],
    Intermediate: [
      {
        name: 'Urban Night',
        colors: ['#1C1C1C', '#4A4A4A', '#00FFFF', '#FF00FF', '#FFFF00', '#00FF00', '#FF4500', '#8A2BE2'],
        theme: 'City nightlife with neon accents'
      },
      {
        name: 'Forest Mystery',
        colors: ['#013220', '#228B22', '#32CD32', '#90EE90', '#8FBC8F', '#F0FFF0', '#FFD700', '#FF6347'],
        theme: 'Deep forest greens with natural highlights'
      }
    ],
    Advanced: [
      {
        name: 'Cyberpunk Dreams',
        colors: [
          '#0D1B2A', '#1B263B', '#415A77', '#778DA9', '#E0E1DD',
          '#00FFFF', '#FF00FF', '#FFFF00', '#FF6B35', '#7209B7',
          '#A663CC', '#4EA5D9', '#006BA6', '#003F5C', '#2F1B69',
          '#8E44AD', '#E74C3C', '#F39C12', '#27AE60', '#3498DB'
        ],
        theme: 'Complex cyberpunk aesthetic with multiple accent colors'
      },
      {
        name: 'Rainbow Riot',
        colors: [
          '#FF0000', '#FF4500', '#FF8C00', '#FFD700', '#FFFF00', '#ADFF2F',
          '#00FF00', '#00FA9A', '#00FFFF', '#0080FF', '#0000FF', '#4169E1',
          '#8A2BE2', '#9400D3', '#FF00FF', '#FF1493', '#FF69B4', '#FFB6C1',
          '#FFFFFF', '#000000'
        ],
        theme: 'Full spectrum rainbow with professional gradients'
      }
    ]
  };

  const getColorCount = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return '6 colors';
      case 'Intermediate': return '8 colors';
      case 'Advanced': return '20+ colors';
      default: return '';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Beginner': return 'bg-turquoise-base text-black';
      case 'Intermediate': return 'bg-turquoise-light text-black';
      case 'Advanced': return 'bg-turquoise-bright text-black';
      default: return 'bg-muted';
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="flex items-center justify-center mb-4">
          <Palette className="w-8 h-8 text-turquoise-base mr-3" />
          <h2 className="text-2xl font-bold turquoise-text">Mission Palettes</h2>
        </div>
        <Badge className={`${getDifficultyColor(difficulty)} font-semibold mb-2`}>
          {difficulty} - {getColorCount(difficulty)}
        </Badge>
        <p className="text-muted-foreground">
          Choose your color palette to match the mission difficulty
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {palettes[difficulty]?.map((palette, index) => (
          <Card key={index} className="graffiti-container hover:shadow-turquoise transition-all duration-300">
            <CardHeader>
              <CardTitle className="text-lg flex items-center">
                <Sparkles className="w-5 h-5 mr-2 text-turquoise-base" />
                {palette.name}
              </CardTitle>
              <CardDescription>{palette.theme}</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Color Grid */}
              <div className={`grid ${difficulty === 'Advanced' ? 'grid-cols-10' : difficulty === 'Intermediate' ? 'grid-cols-4' : 'grid-cols-3'} gap-1`}>
                {palette.colors.map((color, colorIndex) => (
                  <div
                    key={colorIndex}
                    className="aspect-square rounded border border-border/20"
                    style={{ backgroundColor: color }}
                    title={color}
                  />
                ))}
              </div>

              <Button 
                onClick={() => onSelectPalette?.(palette)}
                variant="outline"
                className="w-full border-turquoise-base text-turquoise-base hover:bg-turquoise-base hover:text-black"
              >
                Select Palette
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};

export default ColorPalette;