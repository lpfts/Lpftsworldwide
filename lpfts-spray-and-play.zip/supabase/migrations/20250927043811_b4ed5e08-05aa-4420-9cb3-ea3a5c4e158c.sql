-- Fix remaining security linter issues

-- Fix Issue 1: Security Definer View
-- The public_profiles view should not use SECURITY DEFINER
-- Instead, it should rely on RLS policies of the underlying table
DROP VIEW IF EXISTS public.public_profiles;

-- Create a simple view without security definer
-- This view will use the permissions of the calling user, not the view owner
CREATE VIEW public.public_profiles AS
SELECT 
  id,
  handle,
  display_name,
  avatar_url,
  tokens_collected,
  missions_completed,
  created_at
FROM public.profiles
-- Only show public data, private fields like wallet_address and bio are excluded
WHERE auth_user_id = auth.uid() OR true; -- This will be filtered by RLS policies

-- Grant select permission on the view
GRANT SELECT ON public.public_profiles TO authenticated;

-- Fix Issue 2: Function Search Path Mutable
-- The handle_new_user function references 'username' column that doesn't exist
-- Update it to use the correct 'handle' column and ensure proper search path
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path = public
AS $function$
begin
  insert into public.profiles (auth_user_id, handle, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'username', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  )
  on conflict (auth_user_id) do nothing;
  return new;
end $function$;

-- Also ensure the trigger exists for the handle_new_user function
-- Check if the trigger exists first, if not create it
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'on_auth_user_created'
  ) THEN
    CREATE TRIGGER on_auth_user_created
      AFTER INSERT ON auth.users
      FOR EACH ROW 
      EXECUTE FUNCTION public.handle_new_user();
  END IF;
END $$;