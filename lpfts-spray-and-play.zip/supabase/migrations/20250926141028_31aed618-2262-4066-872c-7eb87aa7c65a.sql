-- Create mission_submissions table for recording mission starts/completions
CREATE TABLE IF NOT EXISTS public.mission_submissions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  mission_title text NOT NULL,
  difficulty text NOT NULL,
  palette jsonb NOT NULL,
  legal_wall_location text,
  status text NOT NULL DEFAULT 'submitted',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.mission_submissions ENABLE ROW LEVEL SECURITY;

-- RLS: users can manage their own submissions
CREATE POLICY "mission_submissions_select_own"
  ON public.mission_submissions
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "mission_submissions_insert_own"
  ON public.mission_submissions
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "mission_submissions_update_own"
  ON public.mission_submissions
  FOR UPDATE
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "mission_submissions_delete_own"
  ON public.mission_submissions
  FOR DELETE
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_mission_submissions_user_id ON public.mission_submissions(user_id);

-- Legal walls reference data (publicly readable)
CREATE TABLE IF NOT EXISTS public.legal_walls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  country text NOT NULL DEFAULT 'Australia',
  state text,
  city text,
  name text NOT NULL,
  address text,
  latitude double precision,
  longitude double precision,
  source_url text,
  approved boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.legal_walls ENABLE ROW LEVEL SECURITY;

-- Public can read legal walls
CREATE POLICY "legal_walls_public_read"
  ON public.legal_walls
  FOR SELECT
  USING (true);