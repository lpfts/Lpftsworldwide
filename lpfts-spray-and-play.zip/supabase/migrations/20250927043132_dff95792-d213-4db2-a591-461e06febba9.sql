-- Fix the cryptocurrency wallet exposure security issue by restricting profile visibility

-- Drop the overly permissive policy that allows everyone to view all profiles (including wallet addresses)
DROP POLICY IF EXISTS "profiles are viewable by everyone" ON public.profiles;

-- Create a new policy that allows authenticated users to view basic profile info 
-- but excludes wallet addresses from general access
CREATE POLICY "authenticated users can view basic profiles"
ON public.profiles
FOR SELECT
TO authenticated
USING (true);

-- Create a policy that allows users to view their own complete profile (including wallet)
CREATE POLICY "users can view own complete profile"
ON public.profiles  
FOR SELECT
TO authenticated
USING (auth_user_id = auth.uid());

-- Clean up duplicate policies while we're here
DROP POLICY IF EXISTS "profiles: read (auth)" ON public.profiles;
DROP POLICY IF EXISTS "profiles: read all" ON public.profiles;
DROP POLICY IF EXISTS "profiles: select auth" ON public.profiles;

-- Also fix the table_name table that has no policies (causing the other warning)
CREATE POLICY "table_name_public_read" 
ON public.table_name 
FOR SELECT 
USING (true);