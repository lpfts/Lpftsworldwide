-- Insert Australian legal walls data
INSERT INTO public.legal_walls (name, address, city, state, country, latitude, longitude, approved) VALUES
('Southport Legal Wall', '5 Lawson Street', 'Southport', 'QLD', 'Australia', -27.9654, 153.4042, true),
('Hosier Lane', 'Hosier Lane', 'Melbourne', 'VIC', 'Australia', -37.8182, 144.9685, true),
('AC/DC Lane', 'AC/DC Lane', 'Melbourne', 'VIC', 'Australia', -37.8136, 144.9631, true),
('Blender Lane', 'Blender Lane', 'Melbourne', 'VIC', 'Australia', -37.8111, 144.9618, true),
('The Walls', 'Northbridge', 'Perth', 'WA', 'Australia', -31.9505, 115.8605, true),
('West End Wall', 'West End', 'Brisbane', 'QLD', 'Australia', -27.4810, 153.0123, true),
('Fortitude Valley Legal Wall', 'James Street', 'Brisbane', 'QLD', 'Australia', -27.4560, 153.0348, true),
('Hyde Park Barracks Wall', 'Queens Square', 'Sydney', 'NSW', 'Australia', -33.8688, 151.2093, true),
('Adelaide Underpass', 'Adelaide', 'Adelaide', 'SA', 'Australia', -34.9285, 138.6007, true),
('Hobart Legal Wall', 'Battery Point', 'Hobart', 'TAS', 'Australia', -42.8826, 147.3257, true);