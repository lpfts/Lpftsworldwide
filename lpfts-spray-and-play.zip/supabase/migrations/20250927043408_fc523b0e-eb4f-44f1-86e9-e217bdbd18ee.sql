-- Fix the authentication data exposure security issue in "User accounts" table

-- Drop the TTL policy that allows public read access for 24 hours
DROP POLICY IF EXISTS "Policy to implement Time To Live (TTL)" ON public."User accounts";

-- Create a new policy that only allows users to access their own account data
-- This assumes auth_user_id contains the actual user ID as JSON
CREATE POLICY "users can only access own account data"
ON public."User accounts"
FOR SELECT
TO authenticated
USING (auth_user_id::text::uuid = auth.uid());

-- Add policies for other operations - only allow users to manage their own data
CREATE POLICY "users can insert own account data"
ON public."User accounts"
FOR INSERT
TO authenticated
WITH CHECK (auth_user_id::text::uuid = auth.uid());

CREATE POLICY "users can update own account data"
ON public."User accounts"
FOR UPDATE
TO authenticated
USING (auth_user_id::text::uuid = auth.uid())
WITH CHECK (auth_user_id::text::uuid = auth.uid());

CREATE POLICY "users can delete own account data"
ON public."User accounts"
FOR DELETE
TO authenticated
USING (auth_user_id::text::uuid = auth.uid());