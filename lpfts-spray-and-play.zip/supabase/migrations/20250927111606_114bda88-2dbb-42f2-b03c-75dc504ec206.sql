-- Fix signup failure by ensuring profiles row is created with required fields
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'pg_catalog', 'public'
AS $$
DECLARE
  v_uid uuid := NEW.id;
  v_username text := coalesce(NEW.raw_user_meta_data ->> 'username', split_part(NEW.email, '@', 1));
  v_handle text;
  v_display text;
BEGIN
  -- Normalize handle (lowercase, only a-z0-9_)
  v_handle := lower(regexp_replace(coalesce(v_username, ''), '[^a-z0-9_]', '', 'g'));
  IF v_handle IS NULL OR length(v_handle) < 3 THEN
    v_handle := 'wolf_' || substr(v_uid::text, 1, 6);
  END IF;
  v_display := initcap(replace(v_handle, '_', ' '));

  -- Ensure both id and auth_user_id equal auth uid to satisfy existing RLS policies
  -- Try to insert; if handle collides, append random suffix and retry
  FOR i IN 0..5 LOOP
    BEGIN
      INSERT INTO public.profiles (id, auth_user_id, handle, display_name, created_at)
      VALUES (v_uid, v_uid, v_handle, v_display, now());
      RETURN NEW;
    EXCEPTION WHEN unique_violation THEN
      v_handle := v_handle || '_' || substr(gen_random_uuid()::text, 1, 4);
      v_display := initcap(replace(v_handle, '_', ' '));
    END;
  END LOOP;

  -- Final fallback (shouldn't normally reach)
  INSERT INTO public.profiles (id, auth_user_id, handle, display_name, created_at)
  VALUES (v_uid, v_uid, 'wolf_' || substr(gen_random_uuid()::text, 1, 8), 'Wolf ' || substr(v_uid::text, 1, 4), now())
  ON CONFLICT (id) DO NOTHING;

  RETURN NEW;
END;
$$;

-- Social features: add image URL to posts and create comments table
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_schema='public' AND table_name='posts' AND column_name='image_url'
  ) THEN
    ALTER TABLE public.posts ADD COLUMN image_url text;
  END IF;
END $$;

-- Create comments table if not exists
CREATE TABLE IF NOT EXISTS public.post_comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  post_id bigint NOT NULL REFERENCES public.posts(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  content text NOT NULL,
  image_url text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.post_comments ENABLE ROW LEVEL SECURITY;

-- RLS policies for comments
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='post_comments' AND policyname='post_comments_select_public'
  ) THEN
    CREATE POLICY post_comments_select_public ON public.post_comments FOR SELECT USING (true);
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='post_comments' AND policyname='post_comments_insert_own'
  ) THEN
    CREATE POLICY post_comments_insert_own ON public.post_comments FOR INSERT WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='post_comments' AND policyname='post_comments_update_own'
  ) THEN
    CREATE POLICY post_comments_update_own ON public.post_comments FOR UPDATE USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname='public' AND tablename='post_comments' AND policyname='post_comments_delete_own'
  ) THEN
    CREATE POLICY post_comments_delete_own ON public.post_comments FOR DELETE USING (auth.uid() = user_id);
  END IF;
END $$;

-- Index for faster lookups
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace 
    WHERE c.relname='idx_post_comments_post_id' AND n.nspname='public'
  ) THEN
    CREATE INDEX idx_post_comments_post_id ON public.post_comments (post_id);
  END IF;
END $$;