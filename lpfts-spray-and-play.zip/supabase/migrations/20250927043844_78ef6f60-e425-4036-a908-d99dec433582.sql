-- Final security fix - remove the view and remaining issues

-- Remove the public_profiles view entirely 
-- Applications should query the profiles table directly with RLS
DROP VIEW IF EXISTS public.public_profiles;

-- Check for any other potential issues
-- Look for functions without proper search_path
SELECT 
  p.proname as function_name,
  p.prosecdef as is_security_definer,
  CASE 
    WHEN p.proconfig IS NULL THEN 'NO_CONFIG'
    WHEN 'search_path=public' = ANY(p.proconfig) THEN 'HAS_SEARCH_PATH'
    ELSE 'MISSING_SEARCH_PATH'
  END as search_path_status
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
AND p.prosecdef = true;