-- Create public bucket for feed media if it doesn't exist
insert into storage.buckets (id, name, public)
values ('feed-media', 'feed-media', true)
on conflict (id) do nothing;

-- Drop existing policies if they exist
drop policy if exists "feed-media public read" on storage.objects;
drop policy if exists "feed-media user can upload" on storage.objects;
drop policy if exists "feed-media user can update own" on storage.objects;
drop policy if exists "feed-media user can delete own" on storage.objects;

-- Allow public read access to feed-media bucket
create policy "feed-media public read"
on storage.objects
for select
using (bucket_id = 'feed-media');

-- Allow authenticated users to upload to their own folder in feed-media
create policy "feed-media user can upload"
on storage.objects
for insert
to authenticated
with check (
  bucket_id = 'feed-media'
  and auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow authenticated users to update their own files
create policy "feed-media user can update own"
on storage.objects
for update
to authenticated
using (
  bucket_id = 'feed-media'
  and auth.uid()::text = (storage.foldername(name))[1]
)
with check (
  bucket_id = 'feed-media'
  and auth.uid()::text = (storage.foldername(name))[1]
);

-- Allow authenticated users to delete their own files
create policy "feed-media user can delete own"
on storage.objects
for delete
to authenticated
using (
  bucket_id = 'feed-media'
  and auth.uid()::text = (storage.foldername(name))[1]
);