-- Add explicit RLS policies for profile_audit_log to prevent manipulation
-- Only system triggers (SECURITY DEFINER) can INSERT
-- Users can only SELECT their own logs
-- All UPDATE and DELETE operations are explicitly denied

-- Drop existing policies if they exist to recreate them
DROP POLICY IF EXISTS "users_own_audit_logs" ON public.profile_audit_log;

-- Allow users to view only their own audit logs
CREATE POLICY "users_can_view_own_audit_logs" ON public.profile_audit_log
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- Explicitly deny all INSERT attempts from users
-- The SECURITY DEFINER trigger will bypass RLS and can still insert
CREATE POLICY "deny_user_inserts_audit_logs" ON public.profile_audit_log
  FOR INSERT
  TO authenticated
  WITH CHECK (false);

-- Explicitly deny all UPDATE attempts
CREATE POLICY "deny_all_updates_audit_logs" ON public.profile_audit_log
  FOR UPDATE
  TO authenticated
  USING (false)
  WITH CHECK (false);

-- Explicitly deny all DELETE attempts  
CREATE POLICY "deny_all_deletes_audit_logs" ON public.profile_audit_log
  FOR DELETE
  TO authenticated
  USING (false);