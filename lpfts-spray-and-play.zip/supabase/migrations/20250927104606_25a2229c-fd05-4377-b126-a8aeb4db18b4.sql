-- Security fixes for LPFTS profiles and database hardening (checking existing constraints)

-- 1. Drop the overly permissive RLS policy that exposes private data
DROP POLICY IF EXISTS "authenticated users can view non-sensitive profile data" ON public.profiles;

-- 2. Create proper granular RLS policies for profiles
-- Public profile data policy (only non-sensitive fields)
DROP POLICY IF EXISTS "public_profile_data_access" ON public.profiles;
CREATE POLICY "public_profile_data_access" 
ON public.profiles 
FOR SELECT 
USING (true);

-- 3. Add database constraints for security and data integrity (only if they don't exist)
-- Check and add constraints one by one

-- Unique handle constraint
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_handle_unique') THEN
        ALTER TABLE public.profiles ADD CONSTRAINT profiles_handle_unique UNIQUE (handle);
    END IF;
END $$;

-- Handle not empty constraint
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_handle_not_empty') THEN
        ALTER TABLE public.profiles ADD CONSTRAINT profiles_handle_not_empty CHECK (length(trim(handle)) > 0);
    END IF;
END $$;

-- Display name not empty constraint
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_display_name_not_empty') THEN
        ALTER TABLE public.profiles ADD CONSTRAINT profiles_display_name_not_empty CHECK (length(trim(display_name)) > 0);
    END IF;
END $$;

-- Handle safe characters constraint
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_handle_safe_chars') THEN
        ALTER TABLE public.profiles ADD CONSTRAINT profiles_handle_safe_chars CHECK (handle ~ '^[a-zA-Z0-9_-]+$');
    END IF;
END $$;

-- Handle length constraint
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_handle_length') THEN
        ALTER TABLE public.profiles ADD CONSTRAINT profiles_handle_length CHECK (length(handle) BETWEEN 3 AND 30);
    END IF;
END $$;

-- Display name length constraint
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname = 'profiles_display_name_length') THEN
        ALTER TABLE public.profiles ADD CONSTRAINT profiles_display_name_length CHECK (length(display_name) BETWEEN 1 AND 50);
    END IF;
END $$;

-- 4. Create a secure function to get public profile data
CREATE OR REPLACE FUNCTION public.get_public_profile(profile_id uuid)
RETURNS TABLE (
  id uuid,
  handle text,
  display_name text,
  avatar_url text,
  missions_completed integer,
  tokens_collected bigint,
  created_at timestamptz
)
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    p.id,
    p.handle,
    p.display_name,
    p.avatar_url,
    p.missions_completed,
    p.tokens_collected,
    p.created_at
  FROM public.profiles p
  WHERE p.id = profile_id;
$$;

-- 5. Create audit logging for sensitive profile changes
CREATE TABLE IF NOT EXISTS public.profile_audit_log (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  action text NOT NULL,
  old_values jsonb,
  new_values jsonb,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on audit log
ALTER TABLE public.profile_audit_log ENABLE ROW LEVEL SECURITY;

-- Only allow users to view their own audit logs
DROP POLICY IF EXISTS "users_own_audit_logs" ON public.profile_audit_log;
CREATE POLICY "users_own_audit_logs" 
ON public.profile_audit_log 
FOR SELECT 
USING (user_id = auth.uid());

-- 6. Create trigger function for profile change auditing
CREATE OR REPLACE FUNCTION public.audit_profile_changes()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only log changes to sensitive fields
  IF (OLD.wallet_address IS DISTINCT FROM NEW.wallet_address) OR 
     (OLD.bio IS DISTINCT FROM NEW.bio) OR
     (OLD.handle IS DISTINCT FROM NEW.handle) OR
     (OLD.display_name IS DISTINCT FROM NEW.display_name) THEN
    
    INSERT INTO public.profile_audit_log (
      user_id,
      action,
      old_values,
      new_values
    ) VALUES (
      NEW.auth_user_id,
      'profile_update',
      jsonb_build_object(
        'wallet_address', OLD.wallet_address,
        'bio', OLD.bio,
        'handle', OLD.handle,
        'display_name', OLD.display_name
      ),
      jsonb_build_object(
        'wallet_address', NEW.wallet_address,
        'bio', NEW.bio,
        'handle', NEW.handle,
        'display_name', NEW.display_name
      )
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Create the audit trigger
DROP TRIGGER IF EXISTS profile_changes_audit ON public.profiles;
CREATE TRIGGER profile_changes_audit
  AFTER UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.audit_profile_changes();